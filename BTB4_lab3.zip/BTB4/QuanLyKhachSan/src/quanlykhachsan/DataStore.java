package quanlykhachsan;

import quanlykhachsan.model.*;

import java.io.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Lưu trữ dữ liệu toàn bộ hệ thống (singleton).
 * Dữ liệu được ghi/đọc ra file data/khachsan.dat bằng Java Serialization,
 * không cần cài đặt CSDL. Nếu chưa có file sẽ tự sinh dữ liệu mẫu.
 */
public class DataStore implements Serializable {
    private static final long serialVersionUID = 1L;
    private static final File FILE = new File("data", "khachsan.dat");

    private static DataStore instance;

    public final List<KhachHang> khachHangs = new ArrayList<>();
    public final List<NhanVien> nhanViens = new ArrayList<>();
    public final List<LoaiPhong> loaiPhongs = new ArrayList<>();
    public final List<Phong> phongs = new ArrayList<>();
    public final List<DichVu> dichVus = new ArrayList<>();
    public final List<DatPhong> datPhongs = new ArrayList<>();
    public final List<HoaDon> hoaDons = new ArrayList<>();

    public static synchronized DataStore get() {
        if (instance == null) instance = load();
        return instance;
    }

    private static DataStore load() {
        try (ObjectInputStream in = new ObjectInputStream(new BufferedInputStream(new FileInputStream(FILE)))) {
            return (DataStore) in.readObject();
        } catch (Exception e) {
            DataStore d = new DataStore();
            d.seed();
            return d;
        }
    }

    public synchronized void save() {
        try {
            if (FILE.getParentFile() != null && !FILE.getParentFile().exists()) FILE.getParentFile().mkdirs();
            try (ObjectOutputStream out = new ObjectOutputStream(new BufferedOutputStream(new FileOutputStream(FILE)))) {
                out.writeObject(this);
            }
        } catch (Exception e) {
            System.err.println("Không lưu được dữ liệu: " + e);
        }
    }

    // ==================== Sinh mã tự động ====================
    private static String nextId(String prefix, Collection<String> ids) {
        int max = 0;
        for (String id : ids) {
            if (id != null && id.startsWith(prefix)) {
                try {
                    max = Math.max(max, Integer.parseInt(id.substring(prefix.length())));
                } catch (NumberFormatException ignored) {
                }
            }
        }
        return String.format("%s%03d", prefix, max + 1);
    }

    public String nextMaKH() {
        return nextId("KH", khachHangs.stream().map(k -> k.maKH).collect(Collectors.toList()));
    }

    public String nextMaNV() {
        return nextId("NV", nhanViens.stream().map(k -> k.maNV).collect(Collectors.toList()));
    }

    public String nextMaLoai() {
        return nextId("LP", loaiPhongs.stream().map(k -> k.maLoai).collect(Collectors.toList()));
    }

    public String nextMaDV() {
        return nextId("DV", dichVus.stream().map(k -> k.maDV).collect(Collectors.toList()));
    }

    public String nextMaDP() {
        return nextId("DP", datPhongs.stream().map(k -> k.maDP).collect(Collectors.toList()));
    }

    public String nextMaHD() {
        return nextId("HD", hoaDons.stream().map(k -> k.maHD).collect(Collectors.toList()));
    }

    // ==================== Tra cứu ====================
    public KhachHang findKH(String ma) {
        return khachHangs.stream().filter(k -> k.maKH.equals(ma)).findFirst().orElse(null);
    }

    public NhanVien findNV(String ma) {
        return nhanViens.stream().filter(k -> k.maNV.equals(ma)).findFirst().orElse(null);
    }

    public LoaiPhong findLoai(String ma) {
        return loaiPhongs.stream().filter(k -> k.maLoai.equals(ma)).findFirst().orElse(null);
    }

    public Phong findPhong(String ma) {
        return phongs.stream().filter(k -> k.maPhong.equals(ma)).findFirst().orElse(null);
    }

    public DichVu findDV(String ma) {
        return dichVus.stream().filter(k -> k.maDV.equals(ma)).findFirst().orElse(null);
    }

    public double donGiaPhong(String maPhong) {
        Phong p = findPhong(maPhong);
        if (p == null) return 0;
        LoaiPhong lp = findLoai(p.maLoai);
        return lp == null ? 0 : lp.donGia;
    }

    public String tenKH(String ma) {
        KhachHang k = findKH(ma);
        return k == null ? ma : k.hoTen;
    }

    public String tenLoai(String ma) {
        LoaiPhong l = findLoai(ma);
        return l == null ? ma : l.tenLoai;
    }

    public String tenLoaiCuaPhong(String maPhong) {
        Phong p = findPhong(maPhong);
        return p == null ? "" : tenLoai(p.maLoai);
    }

    public double tienDichVu(DatPhong dp) {
        double t = 0;
        for (ChiTietDichVu c : dp.dichVus) {
            DichVu dv = findDV(c.maDV);
            if (dv != null) t += dv.donGia * c.soLuong;
        }
        return t;
    }

    // ==================== Dữ liệu mẫu ====================
    private void seed() {
        loaiPhongs.add(new LoaiPhong("LP001", "Standard", 500000, "Điều hòa", "TV", "Wi-Fi", "Tủ lạnh"));
        loaiPhongs.add(new LoaiPhong("LP002", "Superior", 750000, "Điều hòa", "TV màn hình phẳng", "Wi-Fi", "Bồn tắm"));
        loaiPhongs.add(new LoaiPhong("LP003", "Deluxe", 1200000, "Điều hòa", "Smart TV", "Wi-Fi", "Ban công", "Két sắt"));
        loaiPhongs.add(new LoaiPhong("LP004", "Suite", 2000000, "Điều hòa", "Smart TV 65 inch", "Wi-Fi", "Phòng khách riêng", "Bếp nhỏ"));

        for (int i = 1; i <= 4; i++) phongs.add(new Phong("P10" + i, "LP001", 1, Phong.TRONG));
        for (int i = 1; i <= 3; i++) phongs.add(new Phong("P20" + i, "LP002", 2, Phong.TRONG));
        for (int i = 1; i <= 2; i++) phongs.add(new Phong("P30" + i, "LP003", 3, Phong.TRONG));
        phongs.add(new Phong("P401", "LP004", 4, Phong.TRONG));

        dichVus.add(new DichVu("DV001", "Đưa đón sân bay", 300000, "lượt"));
        dichVus.add(new DichVu("DV002", "Giặt ủi", 50000, "kg"));
        dichVus.add(new DichVu("DV003", "Spa - Massage", 250000, "lượt"));
        dichVus.add(new DichVu("DV004", "Buffet sáng", 120000, "lượt"));
        dichVus.add(new DichVu("DV005", "Đồ uống", 30000, "chai"));
        dichVus.add(new DichVu("DV006", "Thuê xe máy", 150000, "ngày"));

        khachHangs.add(new KhachHang("KH001", "Nguyễn Văn An", "012345678901", "0901234567", "Nam", LocalDate.of(1990, 5, 12), "12 Lê Lợi, Q.1, TP.HCM"));
        khachHangs.add(new KhachHang("KH002", "Trần Thị Bích", "079123456789", "0912345678", "Nữ", LocalDate.of(1995, 8, 3), "45 Nguyễn Huệ, Q.1, TP.HCM"));
        khachHangs.add(new KhachHang("KH003", "Lê Minh Cường", "085987654321", "0938765432", "Nam", LocalDate.of(1988, 1, 25), "78 Trần Hưng Đạo, Hà Đông, Hà Nội"));
        khachHangs.add(new KhachHang("KH004", "Phạm Thu Dung", "036456789123", "0978123456", "Nữ", LocalDate.of(1992, 11, 9), "210 Hùng Vương, Hải Châu, Đà Nẵng"));
        khachHangs.add(new KhachHang("KH005", "Hoàng Văn Em", "091234567890", "0356789123", "Nam", LocalDate.of(2000, 3, 30), "5 nguyễn Chí Thanh, TP. Huế"));

        nhanViens.add(new NhanVien("NV001", "Trịnh Thị Hoa", "Nữ", "0987654321", "Quản lý"));
        nhanViens.add(new NhanVien("NV002", "Vũ Đức Thịnh", "Nam", "0905551234", "Lễ tân"));
        nhanViens.add(new NhanVien("NV003", "Ngô Thị Hạnh", "Nữ", "0933221144", "Buồng phòng"));

        LocalDate homNay = LocalDate.now();
        LocalDateTime gio = LocalDateTime.now();

        // Hai phiếu đang hoạt động để dùng thử chức năng dịch vụ / thanh toán
        DatPhong dp1 = new DatPhong("DP001", "KH001", "P101", homNay.minusDays(1), homNay, DatPhong.DANG_SU_DUNG, "Khách đặt qua điện thoại");
        dp1.ngayCheckIn = gio;
        dp1.dichVus.add(new ChiTietDichVu("DV004", 2, homNay));
        datPhongs.add(dp1);
        findPhong("P101").trangThai = Phong.CO_KHACH;

        DatPhong dp2 = new DatPhong("DP002", "KH002", "P201", homNay.minusDays(2), homNay.plusDays(3), DatPhong.DAT_TRUOC, "");
        datPhongs.add(dp2);
        findPhong("P201").trangThai = Phong.DA_DAT;

        // Một số phiếu đã trả để có dữ liệu thống kê doanh thu
        themPhieuDaTra("KH003", "P201", homNay.minusDays(45), 2, "Chuyển khoản");
        themPhieuDaTra("KH004", "P301", homNay.minusDays(20), 3, "Tiền mặt");
        themPhieuDaTra("KH005", "P101", homNay.minusDays(10), 1, "Tiền mặt");
        themPhieuDaTra("KH001", "P202", homNay.minusDays(4), 2, "Thẻ ngân hàng");
        save();
    }

    private void themPhieuDaTra(String maKH, String maPhong, LocalDate checkIn, long soNgay, String pttt) {
        DatPhong dp = new DatPhong(nextMaDP(), maKH, maPhong, checkIn.minusDays(1), checkIn, DatPhong.DA_TRA, "");
        dp.ngayCheckIn = checkIn.atTime(14, 0);
        dp.ngayCheckOut = checkIn.plusDays(soNgay).atTime(12, 0);
        datPhongs.add(dp);

        HoaDon hd = new HoaDon();
        hd.maHD = nextMaHD();
        hd.maDP = dp.maDP;
        hd.maKH = maKH;
        hd.tenKH = tenKH(maKH);
        hd.maPhong = maPhong;
        hd.tenLoai = tenLoaiCuaPhong(maPhong);
        hd.ngayCheckIn = dp.ngayCheckIn;
        hd.ngayCheckOut = dp.ngayCheckOut;
        hd.ngayLap = dp.ngayCheckOut;
        hd.soNgay = soNgay;
        hd.tienPhong = soNgay * donGiaPhong(maPhong);
        hd.tienDichVu = 0;
        hd.giamGia = 0;
        hd.tongTien = hd.tienPhong;
        hd.phuongThuc = pttt;
        hoaDons.add(hd);
    }
}
