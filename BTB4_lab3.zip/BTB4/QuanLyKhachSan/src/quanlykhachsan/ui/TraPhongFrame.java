package quanlykhachsan.ui;

import quanlykhachsan.DataStore;
import quanlykhachsan.model.ChiTietDichVu;
import quanlykhachsan.model.DatPhong;
import quanlykhachsan.model.DichVu;
import quanlykhachsan.model.HoaDon;
import quanlykhachsan.model.Phong;
import quanlykhachsan.util.UiUtil;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;

public class TraPhongFrame extends JFrame {

    private final JComboBox<String> cbPhieu = new JComboBox<>();
    private final JLabel lbKH = new JLabel();
    private final JLabel lbPhong = new JLabel();
    private final JLabel lbNhan = new JLabel();
    private final JLabel lbTra = new JLabel();
    private final JLabel lbSoNgay = new JLabel();
    private final JLabel lbTienPhong = new JLabel();
    private final JLabel lbTienDV = new JLabel();
    private final JLabel lbTong = new JLabel();
    private final JLabel lbConLai = new JLabel();
    private final JLabel lbThua = new JLabel();
    private final JTextField tfGiamGia = new JTextField("0", 10);
    private final JTextField tfKhachTra = new JTextField(10);
    private final JComboBox<String> cbPTTT = new JComboBox<>(new String[]{"Tiền mặt", "Chuyển khoản", "Thẻ ngân hàng"});
    private final JTable table = new JTable(UiUtil.model(new String[]{"Dịch vụ đã sử dụng", "Số lượng", "Thành tiền"}));
    private final JButton btnThanhToan = UiUtil.btn("Thanh toán & Trả phòng");

    public TraPhongFrame() {
        super("Trả phòng - Thanh toán");
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setSize(1080, 680);
        setLocationRelativeTo(null);

        JPanel root = new JPanel(new BorderLayout(10, 10));
        root.setBorder(new EmptyBorder(12, 12, 12, 12));

        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT));
        top.add(new JLabel("Phiếu đang sử dụng:"));
        top.add(cbPhieu);
        JButton btnLamMoi = UiUtil.btn("Làm mới");
        top.add(btnLamMoi);

        // ----- Thông tin phiếu -----
        JPanel info = new JPanel(new GridLayout(0, 1, 4, 4));
        info.setBorder(BorderFactory.createTitledBorder("Thông tin lượt thuê"));
        for (JLabel lb : new JLabel[]{lbKH, lbPhong, lbNhan, lbTra, lbSoNgay}) {
            lb.setFont(new Font("Segoe UI", Font.PLAIN, 14));
            info.add(lb);
        }

        // ----- Bảng dịch vụ -----
        table.setRowHeight(26);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 14));
        UiUtil.widths(table, 280, 100, 160);
        JScrollPane spTable = new JScrollPane(table);
        spTable.setBorder(BorderFactory.createTitledBorder("Dịch vụ đã sử dụng"));

        JPanel center = new JPanel(new GridLayout(1, 2, 12, 0));
        center.add(info);
        center.add(spTable);

        // ----- Khung thanh toán -----
        JPanel thanhToan = new JPanel(new GridBagLayout());
        thanhToan.setBorder(BorderFactory.createTitledBorder("Thanh toán"));
        GridBagConstraints f = new GridBagConstraints();
        f.insets = new Insets(4, 8, 4, 8);
        f.anchor = GridBagConstraints.WEST;

        Font lbFont = new Font("Segoe UI", Font.PLAIN, 14);
        for (JLabel lb : new JLabel[]{lbTienPhong, lbTienDV, lbTong, lbConLai, lbThua}) lb.setFont(lbFont);
        lbTong.setFont(new Font("Segoe UI", Font.BOLD, 16));
        lbTong.setForeground(new Color(0xC00000));

        f.gridx = 0;
        f.gridy = 0;
        thanhToan.add(lbTienPhong, f);
        f.gridy = 1;
        thanhToan.add(lbTienDV, f);
        f.gridy = 2;
        thanhToan.add(lbTong, f);
        f.gridy = 3;
        thanhToan.add(lbConLai, f);

        f.gridx = 0;
        f.gridy = 4;
        thanhToan.add(new JLabel("Giảm giá (đ):"), f);
        f.gridx = 1;
        thanhToan.add(tfGiamGia, f);
        f.gridx = 0;
        f.gridy = 5;
        thanhToan.add(new JLabel("Phương thức:"), f);
        f.gridx = 1;
        thanhToan.add(cbPTTT, f);
        f.gridx = 0;
        f.gridy = 6;
        thanhToan.add(new JLabel("Tiền khách trả (đ):"), f);
        f.gridx = 1;
        thanhToan.add(tfKhachTra, f);
        f.gridx = 0;
        f.gridy = 7;
        thanhToan.add(lbThua, f);
        f.gridx = 0;
        f.gridy = 8;
        f.gridwidth = 2;
        JButton btnTinh = UiUtil.btn("Tính tiền");
        btnThanhToan.setBackground(new Color(0xDFF0DF));
        f.fill = GridBagConstraints.HORIZONTAL;
        thanhToan.add(btnTinh, f);
        f.gridy = 9;
        thanhToan.add(btnThanhToan, f);
        f.gridy = 10;
        thanhToan.add(MainFrame.nutQuayLai(this), f);

        JPanel south = new JPanel(new BorderLayout());
        south.add(thanhToan, BorderLayout.EAST);

        root.add(top, BorderLayout.NORTH);
        root.add(center, BorderLayout.CENTER);
        root.add(south, BorderLayout.SOUTH);
        setContentPane(root);

        refresh();
        cbPhieu.addActionListener(e -> hienThiPhieu());

        btnLamMoi.addActionListener(e -> refresh());

        btnTinh.addActionListener(e -> capNhatTien());

        btnThanhToan.addActionListener(e -> thanhToan());
    }

    private DatPhong selectedPhieu() {
        Object it = cbPhieu.getSelectedItem();
        if (it == null) return null;
        String ma = it.toString().split(" - ")[0].trim();
        return DataStore.get().datPhongs.stream().filter(d -> d.maDP.equals(ma)).findFirst().orElse(null);
    }

    /** {soNgay, tienPhong, tienDichVu, tongTien} */
    private double[] tinhTien(DatPhong dp) {
        LocalDateTime out = LocalDateTime.now();
        long phut = Math.max(0, ChronoUnit.MINUTES.between(dp.ngayCheckIn, out));
        long soNgay = Math.max(1, (long) Math.ceil(phut / 1440.0));
        double tienPhong = soNgay * DataStore.get().donGiaPhong(dp.maPhong);
        double tienDV = DataStore.get().tienDichVu(dp);
        return new double[]{soNgay, tienPhong, tienDV, tienPhong + tienDV};
    }

    private double giamGia(double tong) {
        double g = 0;
        try {
            g = UiUtil.parseMoney(tfGiamGia.getText().trim().isEmpty() ? "0" : tfGiamGia.getText(), "Giảm giá");
        } catch (Exception ex) {
            UiUtil.err(this, ex.getMessage());
            tfGiamGia.requestFocus();
            return -1;
        }
        if (g < 0 || g > tong) {
            UiUtil.err(this, "Giảm giá phải từ 0 đến " + UiUtil.money(tong) + ".");
            return -1;
        }
        return g;
    }

    private void capNhatTien() {
        DatPhong dp = selectedPhieu();
        if (dp == null) return;
        double[] t = tinhTien(dp);
        double g = giamGia(t[3]);
        if (g < 0) return;
        double conLai = t[3] - g;
        lbConLai.setText("Còn phải thu: " + UiUtil.money(conLai));
        if (!tfKhachTra.getText().trim().isEmpty()) {
            try {
                double khach = UiUtil.parseMoney(tfKhachTra.getText(), "Tiền khách trả");
                lbThua.setText(khach >= conLai
                        ? "Tiền thừa trả khách: " + UiUtil.money(khach - conLai)
                        : "Còn thiếu: " + UiUtil.money(conLai - khach));
                lbThua.setForeground(khach >= conLai ? new Color(0x1F7A1F) : Color.RED);
            } catch (Exception ignored) {
            }
        } else {
            lbThua.setText(" ");
        }
    }

    private void hienThiPhieu() {
        DataStore ds = DataStore.get();
        DatPhong dp = selectedPhieu();
        List<Object[]> rows = new ArrayList<>();
        if (dp == null) {
            lbKH.setText("Khách hàng: -");
            lbPhong.setText("Phòng: -");
            lbNhan.setText("Ngày nhận phòng: -");
            lbTra.setText("Ngày trả phòng: -");
            lbSoNgay.setText(" ");
            lbTienPhong.setText(" ");
            lbTienDV.setText(" ");
            lbTong.setText(" ");
            lbConLai.setText(" ");
            lbThua.setText(" ");
        } else {
            double[] t = tinhTien(dp);
            String maLoai = ds.findPhong(dp.maPhong) == null ? "" : ds.findPhong(dp.maPhong).maLoai;
            lbKH.setText("Khách hàng: " + ds.tenKH(dp.maKH) + " (" + dp.maKH + ")");
            lbPhong.setText("Phòng: " + dp.maPhong + " - " + ds.tenLoai(maLoai));
            lbNhan.setText("Ngày nhận phòng: " + UiUtil.dateTime(dp.ngayCheckIn));
            lbTra.setText("Ngày trả phòng: " + UiUtil.dateTime(LocalDateTime.now()) + " (hiện tại)");
            lbSoNgay.setText("Số ngày ở: " + (long) t[0] + " ngày");
            lbTienPhong.setText("Tiền phòng: " + UiUtil.money(t[1]) + "  (" + (long) t[0] + " x "
                    + UiUtil.money(ds.donGiaPhong(dp.maPhong)) + ")");
            lbTienDV.setText("Tiền dịch vụ: " + UiUtil.money(t[2]));
            lbTong.setText("TỔNG CỘNG: " + UiUtil.money(t[3]));
            lbConLai.setText("Còn phải thu: " + UiUtil.money(t[3]));
            for (ChiTietDichVu c : dp.dichVus) {
                DichVu dv = ds.findDV(c.maDV);
                if (dv == null) continue;
                rows.add(new Object[]{dv.tenDV + " (" + dv.donVi + " x " + UiUtil.money(dv.donGia) + ")",
                        c.soLuong, UiUtil.money(dv.donGia * c.soLuong)});
            }
        }
        UiUtil.fill(table, rows);
        btnThanhToan.setEnabled(dp != null);
    }

    private void refresh() {
        DataStore ds = DataStore.get();
        String sel = null;
        Object it = cbPhieu.getSelectedItem();
        if (it != null) sel = it.toString().split(" - ")[0].trim();

        cbPhieu.removeAllItems();
        for (DatPhong dp : ds.datPhongs)
            if (dp.trangThai.equals(DatPhong.DANG_SU_DUNG))
                cbPhieu.addItem(dp.maDP + " - " + ds.tenKH(dp.maKH) + " - phòng " + dp.maPhong);
        if (sel != null) {
            for (int i = 0; i < cbPhieu.getItemCount(); i++)
                if (cbPhieu.getItemAt(i).startsWith(sel + " - ")) {
                    cbPhieu.setSelectedIndex(i);
                    break;
                }
        }
        tfGiamGia.setText("0");
        tfKhachTra.setText("");
        lbThua.setText(" ");
        hienThiPhieu();
    }

    private void thanhToan() {
        DataStore ds = DataStore.get();
        DatPhong dp = selectedPhieu();
        if (dp == null) {
            UiUtil.err(this, "Không có phiếu nào để thanh toán.");
            return;
        }
        double[] t = tinhTien(dp);
        double g = giamGia(t[3]);
        if (g < 0) return;
        double conLai = t[3] - g;

        double khach;
        try {
            khach = UiUtil.parseMoney(tfKhachTra.getText(), "Tiền khách trả");
        } catch (Exception ex) {
            UiUtil.err(this, ex.getMessage() + "\n(Ví dụ: 1500000)");
            tfKhachTra.requestFocus();
            return;
        }
        if (khach < conLai) {
            UiUtil.err(this, "Khách trả chưa đủ. Còn phải thu: " + UiUtil.money(conLai));
            return;
        }

        if (!UiUtil.confirm(this, "Xác nhận thanh toán phiếu " + dp.maDP + "?\n"
                + "Khách hàng: " + ds.tenKH(dp.maKH) + " - Phòng: " + dp.maPhong
                + " - " + (long) t[0] + " ngày\n"
                + "Tổng cộng: " + UiUtil.money(t[3]) + "  (giảm " + UiUtil.money(g) + ")\n"
                + "Còn phải thu: " + UiUtil.money(conLai)
                + "\nPhòng " + dp.maPhong + " sẽ chuyển về trạng thái \"Trống\".")) return;

        LocalDateTime now = LocalDateTime.now();
        HoaDon hd = new HoaDon();
        hd.maHD = ds.nextMaHD();
        hd.maDP = dp.maDP;
        hd.maKH = dp.maKH;
        hd.tenKH = ds.tenKH(dp.maKH);
        hd.maPhong = dp.maPhong;
        hd.tenLoai = ds.tenLoaiCuaPhong(dp.maPhong);
        hd.ngayCheckIn = dp.ngayCheckIn;
        hd.ngayCheckOut = now;
        hd.ngayLap = now;
        hd.soNgay = (long) t[0];
        hd.tienPhong = t[1];
        hd.tienDichVu = t[2];
        hd.giamGia = g;
        hd.tongTien = conLai;
        hd.phuongThuc = (String) cbPTTT.getSelectedItem();
        ds.hoaDons.add(hd);

        dp.ngayCheckOut = now;
        dp.trangThai = DatPhong.DA_TRA;
        Phong p = ds.findPhong(dp.maPhong);
        if (p != null) p.trangThai = Phong.TRONG;

        String path;
        try {
            path = ghiHoaDon(hd, dp);
        } catch (Exception ex) {
            path = "(không ghi được file: " + ex.getMessage() + ")";
        }
        ds.save();
        refresh();

        UiUtil.msg(this, "THANH TOÁN THÀNH CÔNG\n\n"
                + "Hóa đơn: " + hd.maHD + "\n"
                + "Khách hàng: " + hd.tenKH + " - Phòng: " + hd.maPhong + "\n"
                + "Tổng thu: " + UiUtil.money(hd.tongTien) + "\n"
                + "Tiền thừa trả khách: " + UiUtil.money(khach - conLai) + "\n\n"
                + "Hóa đơn đã lưu tại: " + path);
    }

    /** Xuất hóa đơn ra file text trong thư mục hoadon/, trả về đường dẫn. */
    private String ghiHoaDon(HoaDon hd, DatPhong dp) throws Exception {
        DataStore ds = DataStore.get();
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
        DateTimeFormatter df = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        StringBuilder sb = new StringBuilder();
        sb.append("==============================================\n");
        sb.append("            KHÁCH SẠN HỆ THỐNG QUẢN LÝ\n");
        sb.append("             HÓA ĐƠN THANH TOÁN\n");
        sb.append("==============================================\n");
        sb.append(String.format("Mã hóa đơn : %s        Ngày lập: %s%n", hd.maHD, hd.ngayLap.format(dtf)));
        sb.append(String.format("Số phiếu   : %s%n", hd.maDP));
        sb.append("----------------------------------------------\n");
        sb.append(String.format("Khách hàng       : %s (%s)%n", hd.tenKH, hd.maKH));
        sb.append(String.format("Phòng            : %s - %s%n", hd.maPhong, hd.tenLoai));
        sb.append(String.format("Ngày nhận phòng  : %s%n", hd.ngayCheckIn.format(dtf)));
        sb.append(String.format("Ngày trả phòng   : %s%n", hd.ngayCheckOut.format(dtf)));
        sb.append(String.format("Số ngày ở        : %d ngày%n", hd.soNgay));
        sb.append("----------------------------------------------\n");
        sb.append(String.format("Tiền phòng       : %-28s%s%n", hd.soNgay + " x " + UiUtil.money(ds.donGiaPhong(hd.maPhong)), UiUtil.money(hd.tienPhong)));
        for (ChiTietDichVu c : dp.dichVus) {
            DichVu dv = ds.findDV(c.maDV);
            if (dv == null) continue;
            sb.append(String.format("   - %-26s %-8s%s%n", dv.tenDV, "x" + c.soLuong, UiUtil.money(dv.donGia * c.soLuong)));
        }
        sb.append(String.format("Tiền dịch vụ     : %-28s%s%n", "", UiUtil.money(hd.tienDichVu)));
        if (hd.giamGia > 0)
            sb.append(String.format("Giảm giá         : %-28s-%s%n", "", UiUtil.money(hd.giamGia)));
        sb.append("----------------------------------------------\n");
        sb.append(String.format("TỔNG CỘNG        : %-28s%s%n", "", UiUtil.money(hd.tongTien)));
        sb.append(String.format("Phương thức      : %s%n", hd.phuongThuc));
        sb.append("==============================================\n");
        sb.append("        Cảm ơn quý khách. Hẹn gặp lại!\n");
        sb.append("Hóa đơn lập ngày ").append(LocalDateTime.now().format(df)).append("\n");

        File dir = new File("hoadon");
        if (!dir.exists()) dir.mkdirs();
        File file = new File(dir, hd.maHD + ".txt");
        Files.writeString(file.toPath(), sb.toString(), StandardCharsets.UTF_8);
        return file.getAbsolutePath();
    }
}
