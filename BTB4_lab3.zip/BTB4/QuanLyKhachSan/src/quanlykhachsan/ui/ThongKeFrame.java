package quanlykhachsan.ui;

import quanlykhachsan.DataStore;
import quanlykhachsan.model.ChiTietDichVu;
import quanlykhachsan.model.DatPhong;
import quanlykhachsan.model.DichVu;
import quanlykhachsan.model.HoaDon;
import quanlykhachsan.model.Phong;
import quanlykhachsan.util.UiUtil;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class ThongKeFrame extends JFrame {

    private final JComboBox<String> cbLoai = new JComboBox<>(new String[]{
            "Doanh thu theo tháng", "Tỷ lệ sử dụng phòng", "Top dịch vụ được dùng nhiều", "Top khách hàng chi tiêu"});
    private final JSpinner spNam = new JSpinner(new SpinnerNumberModel(LocalDate.now().getYear(), 2000, 2100, 1));
    private final JTable table = new JTable();
    private final JLabel lbSummary = new JLabel(" ");
    private final BarChart chart = new BarChart();

    public ThongKeFrame() {
        super("Thống kê - Báo cáo");
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setSize(1150, 680);
        setLocationRelativeTo(null);

        JPanel root = new JPanel(new BorderLayout(10, 10));
        root.setBorder(new EmptyBorder(12, 12, 12, 12));

        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 4));
        top.add(new JLabel("Loại thống kê:"));
        top.add(cbLoai);
        top.add(new JLabel("Năm:"));
        top.add(spNam);
        JButton btnXem = UiUtil.btn("Xem báo cáo");
        top.add(btnXem);

        table.setRowHeight(26);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 14));
        JScrollPane spTable = new JScrollPane(table);
        spTable.setBorder(BorderFactory.createTitledBorder("Bảng số liệu"));

        chart.setBorder(BorderFactory.createTitledBorder("Biểu đồ"));
        JSplitPane split = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, spTable, chart);
        split.setDividerLocation(560);
        split.setResizeWeight(0.55);

        lbSummary.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lbSummary.setForeground(new Color(0x1F3864));
        JPanel south = new JPanel(new FlowLayout(FlowLayout.LEFT));
        south.add(lbSummary);

        JPanel northWrap = new JPanel(new BorderLayout());
        northWrap.add(top, BorderLayout.CENTER);
        JPanel backBar = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 4));
        backBar.add(MainFrame.nutQuayLai(this));
        northWrap.add(backBar, BorderLayout.EAST);

        root.add(northWrap, BorderLayout.NORTH);
        root.add(split, BorderLayout.CENTER);
        root.add(south, BorderLayout.SOUTH);
        setContentPane(root);

        btnXem.addActionListener(e -> xem());
        xem();
    }

    private void xem() {
        int loai = cbLoai.getSelectedIndex();
        switch (loai) {
            case 0 -> doanhThuTheoThang();
            case 1 -> tyLePhong();
            case 2 -> topDichVu();
            default -> topKhachHang();
        }
    }

    // 1. Doanh thu theo tháng
    private void doanhThuTheoThang() {
        DataStore ds = DataStore.get();
        int nam = (Integer) spNam.getValue();
        double[] doanhThu = new double[13];
        long[] soHD = new long[13];
        for (HoaDon hd : ds.hoaDons)
            if (hd.ngayLap.getYear() == nam) {
                int th = hd.ngayLap.getMonthValue();
                doanhThu[th] += hd.tongTien;
                soHD[th]++;
            }
        List<Object[]> rows = new ArrayList<>();
        List<String> labels = new ArrayList<>();
        double tong = 0;
        long tongHD = 0;
        for (int th = 1; th <= 12; th++) {
            rows.add(new Object[]{"Tháng " + th, soHD[th], UiUtil.money(doanhThu[th])});
            labels.add("T" + th);
            tong += doanhThu[th];
            tongHD += soHD[th];
        }
        setBang(new String[]{"Tháng", "Số hóa đơn", "Doanh thu"}, rows, new int[]{120, 120, 180});
        chart.setData(labels, java.util.Arrays.copyOfRange(doanhThu, 1, 13), "DOANH THU THEO THÁNG - NĂM " + nam);
        lbSummary.setText("Tổng doanh thu năm " + nam + ": " + UiUtil.money(tong)
                + "  |  Tổng số hóa đơn: " + tongHD
                + "  |  Trung bình/tháng: " + UiUtil.money(Math.round(tong / 12.0)));
    }

    // 2. Tỷ lệ sử dụng phòng (hiện tại)
    private void tyLePhong() {
        DataStore ds = DataStore.get();
        String[] trangThai = {Phong.TRONG, Phong.DA_DAT, Phong.CO_KHACH, Phong.BAO_TRI};
        long[] dem = new long[trangThai.length];
        for (Phong p : ds.phongs)
            for (int i = 0; i < trangThai.length; i++)
                if (p.trangThai.equals(trangThai[i])) dem[i]++;
        int tongPhong = ds.phongs.size();
        List<Object[]> rows = new ArrayList<>();
        List<String> labels = new ArrayList<>();
        double[] values = new double[trangThai.length];
        for (int i = 0; i < trangThai.length; i++) {
            double tyLe = tongPhong == 0 ? 0 : dem[i] * 100.0 / tongPhong;
            rows.add(new Object[]{trangThai[i], dem[i], String.format("%.1f %%", tyLe)});
            labels.add(trangThai[i]);
            values[i] = dem[i];
        }
        setBang(new String[]{"Trạng thái", "Số phòng", "Tỷ lệ"}, rows, new int[]{140, 100, 100});
        chart.setData(labels, values, "TÌNH TRẠNG PHÒNG HIỆN TẠI");
        long dangSuDung = dem[1] + dem[2];
        lbSummary.setText("Tổng " + tongPhong + " phòng  |  Đang kinh doanh (đã đặt + có khách): "
                + dangSuDung + " phòng (" + (tongPhong == 0 ? 0 : String.format("%.1f", dangSuDung * 100.0 / tongPhong)) + "%)");
    }

    // 3. Top dịch vụ
    private void topDichVu() {
        DataStore ds = DataStore.get();
        Map<String, long[]> theoMa = new LinkedHashMap<>(); // {soLuong, thanhTien}
        for (DatPhong dp : ds.datPhongs)
            for (ChiTietDichVu c : dp.dichVus) {
                long[] v = theoMa.computeIfAbsent(c.maDV, k -> new long[2]);
                v[0] += c.soLuong;
                if (ds.findDV(c.maDV) != null) v[1] += (long) (ds.findDV(c.maDV).donGia * c.soLuong);
            }
        List<Map.Entry<String, long[]>> sapXep = new ArrayList<>(theoMa.entrySet());
        sapXep.sort((a, b) -> Long.compare(b.getValue()[0], a.getValue()[0]));

        List<Object[]> rows = new ArrayList<>();
        List<String> labels = new ArrayList<>();
        List<Double> values = new ArrayList<>();
        double tongDT = 0;
        int stt = 1;
        for (Map.Entry<String, long[]> e : sapXep) {
            if (stt > 5) break;
            DichVu dv = ds.findDV(e.getKey());
            String ten = dv == null ? e.getKey() : dv.tenDV;
            rows.add(new Object[]{stt++, ten, e.getValue()[0], UiUtil.money(e.getValue()[1])});
            labels.add(ten);
            values.add((double) e.getValue()[0]);
            tongDT += e.getValue()[1];
        }
        if (rows.isEmpty()) rows.add(new Object[]{"-", "(chưa có dữ liệu)", 0, UiUtil.money(0)});
        setBang(new String[]{"#", "Dịch vụ", "Số lượng dùng", "Doanh thu"}, rows, new int[]{40, 200, 120, 140});
        chart.setData(labels, values.stream().mapToDouble(Double::doubleValue).toArray(), "TOP 5 DỊCH VỤ (SỐ LƯỢNG)");
        lbSummary.setText("Tổng doanh thu từ dịch vụ (tất cả thời gian): " + UiUtil.money(tongDT));
    }

    // 4. Top khách hàng
    private void topKhachHang() {
        DataStore ds = DataStore.get();
        Map<String, Double> theoKH = new LinkedHashMap<>();
        Map<String, Integer> soLan = new LinkedHashMap<>();
        for (HoaDon hd : ds.hoaDons) {
            theoKH.merge(hd.maKH, hd.tongTien, Double::sum);
            soLan.merge(hd.maKH, 1, Integer::sum);
        }
        List<Map.Entry<String, Double>> sapXep = new ArrayList<>(theoKH.entrySet());
        sapXep.sort((a, b) -> Double.compare(b.getValue(), a.getValue()));

        List<Object[]> rows = new ArrayList<>();
        List<String> labels = new ArrayList<>();
        List<Double> values = new ArrayList<>();
        int stt = 1;
        for (Map.Entry<String, Double> e : sapXep) {
            if (stt > 5) break;
            String ten = ds.tenKH(e.getKey());
            rows.add(new Object[]{stt++, ten + " (" + e.getKey() + ")", soLan.get(e.getKey()), UiUtil.money(e.getValue())});
            labels.add(ten);
            values.add(e.getValue());
        }
        if (rows.isEmpty()) rows.add(new Object[]{"-", "(chưa có dữ liệu)", 0, UiUtil.money(0)});
        setBang(new String[]{"#", "Khách hàng", "Số lượt thuê", "Tổng chi tiêu"}, rows, new int[]{40, 220, 110, 150});
        chart.setData(labels, values.stream().mapToDouble(Double::doubleValue).toArray(), "TOP 5 KHÁCH HÀNG (CHI TIÊU)");
        double tong = theoKH.values().stream().mapToDouble(Double::doubleValue).sum();
        lbSummary.setText("Tổng doanh thu tất cả hóa đơn: " + UiUtil.money(tong));
    }

    private void setBang(String[] cols, List<Object[]> rows, int[] widths) {
        table.setModel(UiUtil.model(cols));
        UiUtil.widths(table, widths);
        UiUtil.fill(table, rows);
    }

    /** Biểu đồ cột đơn giản vẽ bằng Graphics2D. */
    static class BarChart extends JPanel {
        private List<String> labels = new ArrayList<>();
        private double[] values = new double[0];
        private String title = "";

        void setData(List<String> labels, double[] values, String title) {
            this.labels = labels;
            this.values = values;
            this.title = title;
            repaint();
        }

        @Override
        protected void paintComponent(Graphics g0) {
            super.paintComponent(g0);
            Graphics2D g = (Graphics2D) g0;
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            int w = getWidth(), h = getHeight();
            g.setColor(Color.WHITE);
            g.fillRect(0, 0, w, h);
            if (values.length == 0) return;

            g.setColor(new Color(0x1F3864));
            g.setFont(new Font("Segoe UI", Font.BOLD, 14));
            FontMetrics fm = g.getFontMetrics();
            g.drawString(title, Math.max(8, (w - fm.stringWidth(title)) / 2), 24);

            int padL = 16, padR = 16, padT = 40, padB = 46;
            int cw = w - padL - padR, ch = h - padT - padB;
            if (cw <= 0 || ch <= 0) return;
            g.setColor(new Color(0xDDDDDD));
            g.drawLine(padL, padT + ch, w - padR, padT + ch);

            double max = 1;
            for (double v : values) max = Math.max(max, v);
            double slot = (double) cw / values.length;
            int bw = Math.max(10, (int) (slot * 0.6));
            g.setFont(new Font("Segoe UI", Font.PLAIN, 11));
            int n = Math.min(values.length, labels.size());
            for (int i = 0; i < n; i++) {
                int x = padL + (int) (slot * i + (slot - bw) / 2);
                int bh = (int) (values[i] / max * (ch - 12));
                int y = padT + ch - bh;
                g.setColor(new Color(0x2E75B6));
                g.fillRect(x, y, bw, bh);
                FontMetrics small = g.getFontMetrics();
                g.setColor(Color.DARK_GRAY);
                if (values[i] > 0) {
                    String val = UiUtil.shortVal(values[i]);
                    g.drawString(val, x + bw / 2 - small.stringWidth(val) / 2, Math.max(small.getHeight(), y - 4));
                }
                String lb = labels.get(i);
                // cắt ngắn nhãn quá dài
                while (!lb.isEmpty() && small.stringWidth(lb) > Math.max(30, slot - 4)) {
                    lb = lb.substring(0, lb.length() - 2) + "…";
                }
                g.setColor(Color.BLACK);
                g.drawString(lb, x + bw / 2 - small.stringWidth(lb) / 2, padT + ch + 16);
            }
        }
    }
}
