package quanlykhachsan.ui;

import quanlykhachsan.DataStore;
import quanlykhachsan.model.DatPhong;
import quanlykhachsan.model.KhachHang;
import quanlykhachsan.model.Phong;
import quanlykhachsan.util.UiUtil;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class DatNhanPhongFrame extends JFrame {

    private final JComboBox<String> cbKH = new JComboBox<>();
    private final JComboBox<String> cbPhong = new JComboBox<>();
    private final JTextField tfNgay = new JTextField(12);
    private final JTextField tfGhiChu = new JTextField(16);
    private final JComboBox<String> cbFilter = new JComboBox<>(new String[]{"Tất cả",
            DatPhong.DAT_TRUOC, DatPhong.DANG_SU_DUNG, DatPhong.DA_TRA, DatPhong.DA_HUY});
    private final JTable table = new JTable(UiUtil.model(new String[]{
            "Mã phiếu", "Khách hàng", "Phòng", "Loại phòng", "Ngày đặt", "Nhận dự kiến", "Check-in", "Check-out", "Trạng thái"}));

    public DatNhanPhongFrame() {
        super("Đặt phòng / Nhận phòng");
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setSize(1250, 680);
        setLocationRelativeTo(null);

        JPanel root = new JPanel(new BorderLayout(10, 10));
        root.setBorder(new EmptyBorder(12, 12, 12, 12));

        // ----- Form bên trái -----
        JPanel form = new JPanel(new GridBagLayout());
        form.setBorder(BorderFactory.createTitledBorder("Tạo phiếu mới"));
        GridBagConstraints f = new GridBagConstraints();
        f.insets = new Insets(4, 6, 4, 6);
        f.anchor = GridBagConstraints.WEST;
        f.gridx = 0;
        f.gridy = 0;
        form.add(new JLabel("Khách hàng (*):"), f);
        f.gridx = 1;
        f.fill = GridBagConstraints.HORIZONTAL;
        form.add(cbKH, f);
        f.gridx = 0;
        f.gridy = 1;
        f.fill = GridBagConstraints.NONE;
        form.add(new JLabel("Phòng trống (*):"), f);
        f.gridx = 1;
        f.fill = GridBagConstraints.HORIZONTAL;
        form.add(cbPhong, f);
        f.gridx = 0;
        f.gridy = 2;
        f.fill = GridBagConstraints.NONE;
        form.add(new JLabel("Nhận dự kiến:"), f);
        f.gridx = 1;
        f.fill = GridBagConstraints.HORIZONTAL;
        form.add(tfNgay, f);
        f.gridx = 0;
        f.gridy = 3;
        f.fill = GridBagConstraints.NONE;
        form.add(new JLabel("Ghi chú:"), f);
        f.gridx = 1;
        f.fill = GridBagConstraints.HORIZONTAL;
        form.add(tfGhiChu, f);
        JLabel lbHint = new JLabel("(ngày dd/MM/yyyy, mặc định là hôm nay)");
        lbHint.setFont(new Font("Segoe UI", Font.ITALIC, 11));
        lbHint.setForeground(Color.GRAY);
        f.gridx = 0;
        f.gridy = 4;
        f.gridwidth = 2;
        form.add(lbHint, f);
        f.gridwidth = 1;

        JButton btnDat = UiUtil.btn("Đặt phòng trước");
        JButton btnNhan = UiUtil.btn("Nhận phòng ngay");
        JPanel formButtons = new JPanel(new GridLayout(1, 2, 8, 0));
        formButtons.add(btnDat);
        formButtons.add(btnNhan);
        f.gridx = 0;
        f.gridy = 5;
        f.gridwidth = 2;
        f.fill = GridBagConstraints.HORIZONTAL;
        form.add(formButtons, f);

        // ----- Bảng phiếu -----
        table.setRowHeight(26);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 13));
        UiUtil.widths(table, 80, 170, 70, 100, 100, 100, 140, 140, 110);

        JPanel center = new JPanel(new BorderLayout(8, 8));
        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 4));
        top.add(new JLabel("Lọc trạng thái:"));
        top.add(cbFilter);
        JButton btnNhanDaDat = UiUtil.btn("Nhận phòng (đã đặt trước)");
        JButton btnHuy = UiUtil.btn("Hủy đặt phòng");
        JButton btnLamMoi = UiUtil.btn("Làm mới");
        top.add(btnNhanDaDat);
        top.add(btnHuy);
        top.add(btnLamMoi);
        center.add(top, BorderLayout.NORTH);
        center.add(new JScrollPane(table), BorderLayout.CENTER);

        root.add(form, BorderLayout.WEST);
        root.add(center, BorderLayout.CENTER);
        JPanel backBar = new JPanel(new FlowLayout(FlowLayout.RIGHT, 12, 6));
        backBar.add(MainFrame.nutQuayLai(this));
        root.add(backBar, BorderLayout.SOUTH);
        setContentPane(root);

        refresh();
        cbFilter.addActionListener(e -> refresh());

        btnDat.addActionListener(e -> taoPhieu(true));
        btnNhan.addActionListener(e -> taoPhieu(false));

        btnNhanDaDat.addActionListener(e -> {
            DatPhong dp = selectedPhieu();
            if (dp == null) return;
            if (!dp.trangThai.equals(DatPhong.DAT_TRUOC)) {
                UiUtil.err(this, "Chỉ có thể nhận phòng với phiếu ở trạng thái \"Đặt trước\".");
                return;
            }
            Phong p = DataStore.get().findPhong(dp.maPhong);
            if (p == null || p.trangThai.equals(Phong.CO_KHACH)) {
                UiUtil.err(this, "Phòng " + dp.maPhong + " hiện không nhận được khách.");
                return;
            }
            if (!UiUtil.confirm(this, "Nhận phòng cho phiếu " + dp.maDP + " (khách " + DataStore.get().tenKH(dp.maKH)
                    + ", phòng " + dp.maPhong + ") ngay bây giờ?")) return;
            dp.ngayCheckIn = LocalDateTime.now();
            dp.trangThai = DatPhong.DANG_SU_DUNG;
            p.trangThai = Phong.CO_KHACH;
            DataStore.get().save();
            refresh();
            UiUtil.msg(this, "Đã nhận phòng " + dp.maPhong + " cho phiếu " + dp.maDP + ".");
        });

        btnHuy.addActionListener(e -> {
            DatPhong dp = selectedPhieu();
            if (dp == null) return;
            if (!dp.trangThai.equals(DatPhong.DAT_TRUOC)) {
                UiUtil.err(this, "Chỉ có thể hủy phiếu ở trạng thái \"Đặt trước\".");
                return;
            }
            if (!UiUtil.confirm(this, "Hủy phiếu đặt phòng " + dp.maDP + "?")) return;
            dp.trangThai = DatPhong.DA_HUY;
            Phong p = DataStore.get().findPhong(dp.maPhong);
            if (p != null && p.trangThai.equals(Phong.DA_DAT)) p.trangThai = Phong.TRONG;
            DataStore.get().save();
            refresh();
        });

        btnLamMoi.addActionListener(e -> {
            tfNgay.setText("");
            tfGhiChu.setText("");
            table.clearSelection();
            refresh();
        });
    }

    private String maFromCombo(JComboBox<String> cb) {
        Object it = cb.getSelectedItem();
        return it == null ? null : it.toString().split(" - ")[0].trim();
    }

    private DatPhong selectedPhieu() {
        int row = table.getSelectedRow();
        if (row < 0) {
            UiUtil.err(this, "Hãy chọn một phiếu trong bảng.");
            return null;
        }
        String ma = (String) table.getModel().getValueAt(row, 0);
        return DataStore.get().datPhongs.stream().filter(d -> d.maDP.equals(ma)).findFirst().orElse(null);
    }

    private void taoPhieu(boolean datTruoc) {
        DataStore ds = DataStore.get();
        String maKH = maFromCombo(cbKH);
        String maPhong = maFromCombo(cbPhong);
        if (maKH == null) {
            UiUtil.err(this, "Vui lòng chọn khách hàng (thêm khách ở mục Danh mục nếu chưa có).");
            return;
        }
        if (maPhong == null) {
            UiUtil.err(this, "Vui lòng chọn phòng (chỉ hiển thị phòng đang trống).");
            return;
        }
        LocalDate nhanDuKien;
        try {
            nhanDuKien = tfNgay.getText().trim().isEmpty() ? LocalDate.now() : UiUtil.parseDate(tfNgay.getText());
        } catch (Exception ex) {
            UiUtil.err(this, ex.getMessage());
            return;
        }
        if (datTruoc && nhanDuKien.isBefore(LocalDate.now())) {
            UiUtil.err(this, "Ngày nhận dự kiến không thể ở trong quá khứ.");
            return;
        }

        DatPhong dp = new DatPhong(ds.nextMaDP(), maKH, maPhong, LocalDate.now(), nhanDuKien,
                datTruoc ? DatPhong.DAT_TRUOC : DatPhong.DANG_SU_DUNG, tfGhiChu.getText().trim());
        Phong p = ds.findPhong(maPhong);
        if (datTruoc) {
            p.trangThai = Phong.DA_DAT;
        } else {
            dp.ngayCheckIn = LocalDateTime.now();
            p.trangThai = Phong.CO_KHACH;
        }
        ds.datPhongs.add(dp);
        ds.save();
        refresh();
        UiUtil.msg(this, (datTruoc ? "Đã đặt phòng trước" : "Đã nhận phòng") + ". Mã phiếu: " + dp.maDP
                + "\nKhách: " + ds.tenKH(maKH) + "  -  Phòng: " + maPhong);
    }

    private void refresh() {
        DataStore ds = DataStore.get();

        String selKH = maFromCombo(cbKH);
        cbKH.removeAllItems();
        for (KhachHang k : ds.khachHangs) cbKH.addItem(k.maKH + " - " + k.hoTen);
        if (selKH != null) {
            for (int i = 0; i < cbKH.getItemCount(); i++)
                if (cbKH.getItemAt(i).startsWith(selKH + " - ")) {
                    cbKH.setSelectedIndex(i);
                    break;
                }
        }

        String selPhong = maFromCombo(cbPhong);
        cbPhong.removeAllItems();
        for (Phong p : ds.phongs)
            if (p.trangThai.equals(Phong.TRONG))
                cbPhong.addItem(p.maPhong + " - " + ds.tenLoai(p.maLoai) + " - " + UiUtil.money(ds.donGiaPhong(p.maPhong)));
        if (selPhong != null) {
            for (int i = 0; i < cbPhong.getItemCount(); i++)
                if (cbPhong.getItemAt(i).startsWith(selPhong + " - ")) {
                    cbPhong.setSelectedIndex(i);
                    break;
                }
        }

        String filter = (String) cbFilter.getSelectedItem();
        List<Object[]> rows = new ArrayList<>();
        for (DatPhong dp : ds.datPhongs) {
            if (!filter.equals("Tất cả") && !dp.trangThai.equals(filter)) continue;
            rows.add(new Object[]{dp.maDP, ds.tenKH(dp.maKH), dp.maPhong, ds.tenLoaiCuaPhong(dp.maPhong),
                    UiUtil.date(dp.ngayDat), UiUtil.date(dp.ngayNhanDuKien),
                    UiUtil.dateTime(dp.ngayCheckIn), UiUtil.dateTime(dp.ngayCheckOut), dp.trangThai});
        }
        UiUtil.fill(table, rows);
    }
}
