package quanlykhachsan.util;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumnModel;
import java.awt.*;
import java.text.NumberFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.List;
import java.util.Locale;

public class UiUtil {
    private static final NumberFormat VND = NumberFormat.getNumberInstance(Locale.of("vi", "VN"));
    private static final DateTimeFormatter DF = DateTimeFormatter.ofPattern("dd/MM/yyyy");
    private static final DateTimeFormatter DTF = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");

    public static String money(double v) {
        return VND.format(v) + " đ";
    }

    public static String shortVal(double v) {
        if (v >= 1_000_000_000) return String.format("%.1f tỷ", v / 1_000_000_000);
        if (v >= 1_000_000) return String.format("%.1f tr", v / 1_000_000);
        if (v >= 1_000) return String.format("%.0fK", v / 1_000);
        return String.format("%.0f", v);
    }

    public static String date(LocalDate d) {
        return d == null ? "" : d.format(DF);
    }

    public static String dateTime(LocalDateTime t) {
        return t == null ? "" : t.format(DTF);
    }

    public static LocalDate parseDate(String s) {
        try {
            return LocalDate.parse(s.trim(), DF);
        } catch (DateTimeParseException e) {
            throw new IllegalArgumentException("Ngày \"" + s + "\" không hợp lệ, phải theo mẫu dd/MM/yyyy.");
        }
    }

    public static double parseMoney(String s, String tenTruong) {
        try {
            return Double.parseDouble(s.trim().replace(",", ""));
        } catch (Exception e) {
            throw new IllegalArgumentException(tenTruong + " phải là số.");
        }
    }

    public static void msg(Component p, String m) {
        JOptionPane.showMessageDialog(p, m);
    }

    public static void err(Component p, String m) {
        JOptionPane.showMessageDialog(p, m, "Lỗi", JOptionPane.ERROR_MESSAGE);
    }

    public static boolean confirm(Component p, String m) {
        return JOptionPane.showConfirmDialog(p, m, "Xác nhận", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION;
    }

    public static JButton btn(String text) {
        JButton b = new JButton(text);
        b.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        return b;
    }

    public static DefaultTableModel model(String[] cols) {
        return new DefaultTableModel(cols, 0) {
            @Override
            public boolean isCellEditable(int r, int c) {
                return false;
            }
        };
    }

    public static void fill(JTable t, List<Object[]> rows) {
        DefaultTableModel m = (DefaultTableModel) t.getModel();
        m.setRowCount(0);
        for (Object[] r : rows) m.addRow(r);
    }

    public static void widths(JTable t, int... ws) {
        TableColumnModel cm = t.getColumnModel();
        for (int i = 0; i < Math.min(ws.length, cm.getColumnCount()); i++) cm.getColumn(i).setPreferredWidth(ws[i]);
    }

    /** Gọi runnable mỗi khi nội dung ô tìm kiếm thay đổi. */
    public static void onChanged(JTextField tf, Runnable r) {
        tf.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
            public void insertUpdate(javax.swing.event.DocumentEvent e) {
                r.run();
            }

            public void removeUpdate(javax.swing.event.DocumentEvent e) {
                r.run();
            }

            public void changedUpdate(javax.swing.event.DocumentEvent e) {
                r.run();
            }
        });
    }
}
