package quanlykhachsan.model;

import java.io.Serializable;
import java.time.LocalDate;

public class KhachHang implements Serializable {
    public String maKH, hoTen, cmnd, sdt, gioiTinh, diaChi;
    public LocalDate ngaySinh;

    public KhachHang() {
    }

    public KhachHang(String maKH, String hoTen, String cmnd, String sdt, String gioiTinh, LocalDate ngaySinh, String diaChi) {
        this.maKH = maKH;
        this.hoTen = hoTen;
        this.cmnd = cmnd;
        this.sdt = sdt;
        this.gioiTinh = gioiTinh;
        this.ngaySinh = ngaySinh;
        this.diaChi = diaChi;
    }

    @Override
    public String toString() {
        return maKH + " - " + hoTen;
    }
}
