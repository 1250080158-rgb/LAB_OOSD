package quanlykhachsan.model;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class DatPhong implements Serializable {
    public static final String DAT_TRUOC = "Đặt trước";
    public static final String DANG_SU_DUNG = "Đang sử dụng";
    public static final String DA_TRA = "Đã trả";
    public static final String DA_HUY = "Đã hủy";

    public String maDP, maKH, maPhong, trangThai, ghiChu;
    public LocalDate ngayDat, ngayNhanDuKien;
    public LocalDateTime ngayCheckIn, ngayCheckOut;
    public List<ChiTietDichVu> dichVus = new ArrayList<>();

    public DatPhong() {
    }

    public DatPhong(String maDP, String maKH, String maPhong, LocalDate ngayDat, LocalDate ngayNhanDuKien, String trangThai, String ghiChu) {
        this.maDP = maDP;
        this.maKH = maKH;
        this.maPhong = maPhong;
        this.ngayDat = ngayDat;
        this.ngayNhanDuKien = ngayNhanDuKien;
        this.trangThai = trangThai;
        this.ghiChu = ghiChu;
    }
}
