package quanlykhachsan.model;

import java.io.Serializable;

public class NhanVien implements Serializable {
    public String maNV, hoTen, gioiTinh, sdt, chucVu;

    public NhanVien() {
    }

    public NhanVien(String maNV, String hoTen, String gioiTinh, String sdt, String chucVu) {
        this.maNV = maNV;
        this.hoTen = hoTen;
        this.gioiTinh = gioiTinh;
        this.sdt = sdt;
        this.chucVu = chucVu;
    }

    @Override
    public String toString() {
        return maNV + " - " + hoTen;
    }
}
