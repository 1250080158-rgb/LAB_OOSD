# Quản lý khách sạn — Java Swing (chạy trong IntelliJ IDEA)

Ứng dụng desktop Java Swing quản lý khách sạn, giao diện và bố cục giống hệt màn hình
"HỆ THỐNG QUẢN LÝ KHÁCH SẠN". **Không cần cài CSDL** — dữ liệu tự lưu vào file
`data/khachsan.dat` (Java Serialization) sau mỗi thao tác.

## Cách chạy trong IntelliJ IDEA

1. **File → Open…** → chọn thư mục `QuanLyKhachSan` → OK.
2. IDEA nhận diện module qua file `QuanLyKhachSan.iml` (JDK 17 trở lên, đã test với JDK 25).
   Nếu được hỏi Trust project / JDK: chọn **Trust** và chọn JDK đã cài.
3. Mở file `src/quanlykhachsan/Main.java` → nhấn mũi tên **Run ▶** (hoặc Shift+F10).
4. Nếu tiếng Việt hiển thị lỗi font (hiếm): **File → Settings → Editor → File Encodings**
   đặt cả 3 mục = **UTF-8**.

> Chạy nhanh bằng dòng lệnh (không cần IDEA):
> `javac -encoding UTF-8 -d out $(find src -name "*.java") && java -cp out quanlykhachsan.Main`

## Các chức năng

### Màn hình chính
Sáu nút chức năng + Thoát (có hộp xác nhận), đúng bố cục ảnh gốc.
Mọi cửa sổ chức năng đều có nút **Quay lại** (hoặc nhấn **ESC**) để đóng và trở về
màn hình chính — nếu màn hình chính đã bị đóng thì tự mở lại.

### 1. Danh mục — 4 tab
- **Khách hàng**: thêm / sửa / xóa, tìm kiếm theo tên–CMND–SĐT–mã, kiểm tra trùng CMND,
  chặn xóa khách đang có phiếu chưa trả, sinh mã tự động (KH…).
- **Nhân viên**: đầy đủ CRUD + tìm kiếm, chọn chức vụ.
- **Loại phòng**: đơn giá/đêm, danh sách tiện nghi, chặn xóa khi còn phòng thuộc loại.
- **Dịch vụ**: đơn giá + đơn vị tính, chặn xóa khi dịch vụ đã được sử dụng.

### 2. Phòng - Tiện nghi
CRUD phòng, lọc theo trạng thái (Trống / Đã đặt / Có khách / Bảo trì), tìm kiếm,
hiện tiện nghi theo loại phòng, thanh tổng quan số phòng theo từng trạng thái.
Trạng thái phòng được cập nhật **tự động** khi đặt / nhận / trả phòng.

### 3. Đặt / Nhận phòng
- **Đặt phòng trước**: chọn khách + phòng trống + ngày nhận dự kiến → phòng chuyển "Đã đặt".
- **Nhận phòng ngay**: check-in tại chỗ → phòng chuyển "Có khách".
- **Nhận phòng đã đặt trước** / **Hủy đặt phòng** từ bảng phiếu, lọc theo trạng thái,
  kiểm tra ngày nhận không được ở quá khứ.

### 4. Sử dụng dịch vụ
Chọn phiếu "Đang sử dụng" → ghi nhận dịch vụ kèm số lượng, cập nhật/xóa mục,
tự tính thành tiền và tổng tiền dịch vụ theo thời gian thực.

### 5. Trả phòng - Thanh toán
- Tự tính số ngày ở (tối thiểu 1 ngày), tiền phòng = số ngày × đơn giá loại phòng.
- Cộng tiền dịch vụ, hỗ trợ **giảm giá**, 3 phương thức thanh toán,
  tính **tiền thừa trả khách** (chặn nếu khách trả chưa đủ).
- Thanh toán xong: phiếu → "Đã trả", phòng → "Trống", lập hóa đơn **HD…**
  và xuất file văn bản vào thư mục `hoadon/HDxxx.txt`.

### 6. Thống kê (có biểu đồ cột vẽ bằng Graphics2D)
- Doanh thu theo tháng của năm (số hóa đơn + doanh thu từng tháng).
- Tỷ lệ sử dụng phòng hiện tại.
- Top 5 dịch vụ được dùng nhiều nhất (số lượng + doanh thu).
- Top 5 khách hàng chi tiêu cao nhất.

## Dữ liệu mẫu
Lần chạy đầu tự sinh: 4 loại phòng, 10 phòng, 6 dịch vụ, 5 khách hàng, 3 nhân viên,
2 phiếu đang hoạt động (1 đang sử dụng tại P101, 1 đặt trước tại P201) và vài hóa đơn
cũ để thử thống kê.

**Reset dữ liệu**: xóa file `data/khachsan.dat` (hoặc thư mục `data`) rồi chạy lại.

## Cấu trúc mã nguồn
```
src/quanlykhachsan/
├── Main.java                  # điểm khởi chạy
├── DataStore.java             # lưu trữ + sinh mã + dữ liệu mẫu
├── model/                     # KhachHang, NhanVien, LoaiPhong, Phong,
│                              # DichVu, ChiTietDichVu, DatPhong, HoaDon
├── util/UiUtil.java           # tiện ích Swing: tiền tệ, ngày, bảng, dialog
└── ui/
    ├── MainFrame.java         # màn hình chính (ảnh gốc)
    ├── DanhMucFrame.java      # 4 tab danh mục
    ├── PhongFrame.java        # phòng - tiện nghi
    ├── DatNhanPhongFrame.java # đặt / nhận phòng
    ├── SuDungDichVuFrame.java # sử dụng dịch vụ
    ├── TraPhongFrame.java     # trả phòng - thanh toán + xuất hóa đơn
    └── ThongKeFrame.java      # thống kê + biểu đồ
```
