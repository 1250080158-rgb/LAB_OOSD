
IF DB_ID(N'QuanLyKhachSan') IS NULL
    CREATE DATABASE QuanLyKhachSan;
GO
USE QuanLyKhachSan;
GO
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
GO
IF OBJECT_ID('ThanhToan','U')          IS NOT NULL DROP TABLE ThanhToan;
IF OBJECT_ID('HoaDon','U')             IS NOT NULL DROP TABLE HoaDon;
IF OBJECT_ID('ChiTietPhieuDenBu','U')  IS NOT NULL DROP TABLE ChiTietPhieuDenBu;
IF OBJECT_ID('PhieuDenBu','U')         IS NOT NULL DROP TABLE PhieuDenBu;
IF OBJECT_ID('QuyDinhDenBu','U')       IS NOT NULL DROP TABLE QuyDinhDenBu;
IF OBJECT_ID('SuDungDichVu','U')       IS NOT NULL DROP TABLE SuDungDichVu;
IF OBJECT_ID('NguoiLuuTru','U')        IS NOT NULL DROP TABLE NguoiLuuTru;
IF OBJECT_ID('PhieuDatPhong','U')      IS NOT NULL DROP TABLE PhieuDatPhong;
IF OBJECT_ID('PhieuLapDat','U')        IS NOT NULL DROP TABLE PhieuLapDat;
IF OBJECT_ID('TienNghi','U')           IS NOT NULL DROP TABLE TienNghi;
IF OBJECT_ID('DichVu','U')             IS NOT NULL DROP TABLE DichVu;
IF OBJECT_ID('KhachHang','U')          IS NOT NULL DROP TABLE KhachHang;
IF OBJECT_ID('LoaiTienNghi','U')       IS NOT NULL DROP TABLE LoaiTienNghi;
IF OBJECT_ID('Phong','U')              IS NOT NULL DROP TABLE Phong;
IF OBJECT_ID('LoaiPhong','U')          IS NOT NULL DROP TABLE LoaiPhong;
IF OBJECT_ID('KhuVuc','U')             IS NOT NULL DROP TABLE KhuVuc;
IF OBJECT_ID('NhanVien','U')           IS NOT NULL DROP TABLE NhanVien;
GO

CREATE TABLE NhanVien(
    MaNV         varchar(20)     NOT NULL,
    HoTen        nvarchar(120)   NOT NULL,
    GioiTinh     nvarchar(10)    NOT NULL DEFAULT N'Nam'
                 CONSTRAINT CK_NhanVien_GioiTinh CHECK (GioiTinh IN (N'Nam', N'Nữ')),
    SoDienThoai  varchar(20)     NULL,
    ChucVu       nvarchar(50)    NOT NULL
                 CONSTRAINT CK_NhanVien_ChucVu
                 CHECK (ChucVu IN (N'Quản lý', N'Lễ tân', N'Buồng phòng', N'Kỹ thuật')),
    CONSTRAINT PK_NhanVien PRIMARY KEY (MaNV)
);
GO

CREATE TABLE KhuVuc(
    MaKhuVuc    varchar(20)     NOT NULL,
    TenKhuVuc   nvarchar(100)   NOT NULL,
    CONSTRAINT PK_KhuVuc PRIMARY KEY (MaKhuVuc),
    CONSTRAINT UQ_KhuVuc_Ten UNIQUE (TenKhuVuc)
);
GO


CREATE TABLE LoaiPhong(
    MaLoai      varchar(20)     NOT NULL,
    TenLoai     nvarchar(100)   NOT NULL,
    DonGiaNgay  decimal(18,2)   NOT NULL
                CONSTRAINT CK_LoaiPhong_DonGia CHECK (DonGiaNgay >= 0),
    TienIch     nvarchar(250)   NULL,   -- "Điều hòa, TV, Wi-Fi, Tủ lạnh"
    CONSTRAINT PK_LoaiPhong PRIMARY KEY (MaLoai),
    CONSTRAINT UQ_LoaiPhong_Ten UNIQUE (TenLoai)
);
GO

CREATE TABLE Phong(
    SoPhong       varchar(20)   NOT NULL,
    MaLoai        varchar(20)   NOT NULL,
    MaKhuVuc      varchar(20)   NOT NULL,
    Tang          int           NOT NULL DEFAULT 1
                  CONSTRAINT CK_Phong_Tang CHECK (Tang >= 1),
    SoNguoiToiDa  int           NOT NULL DEFAULT 2
                  CONSTRAINT CK_Phong_SucChua CHECK (SoNguoiToiDa > 0),
    TrangThai     nvarchar(20)  NOT NULL DEFAULT N'Trống'
                  CONSTRAINT CK_Phong_TrangThai
                  CHECK (TrangThai IN (N'Trống', N'Đã đặt', N'Có khách', N'Bảo trì')),
    CONSTRAINT PK_Phong PRIMARY KEY (SoPhong),
    CONSTRAINT FK_Phong_Loai   FOREIGN KEY (MaLoai)   REFERENCES LoaiPhong (MaLoai),
    CONSTRAINT FK_Phong_KhuVuc FOREIGN KEY (MaKhuVuc) REFERENCES KhuVuc (MaKhuVuc)
);
GO


CREATE TABLE LoaiTienNghi(
    MaLoaiTN    varchar(20)     NOT NULL,
    TenLoaiTN   nvarchar(100)   NOT NULL,
    CONSTRAINT PK_LoaiTienNghi PRIMARY KEY (MaLoaiTN),
    CONSTRAINT UQ_LoaiTienNghi_Ten UNIQUE (TenLoaiTN)
);
GO

CREATE TABLE TienNghi(
    MaTienNghi        varchar(30)   NOT NULL,
    MaLoaiTN          varchar(20)   NOT NULL,
    SoThuTu           int           NOT NULL
                      CONSTRAINT CK_TienNghi_STT CHECK (SoThuTu > 0),
    TinhTrangHienTai  nvarchar(100) NULL,
    CONSTRAINT PK_TienNghi PRIMARY KEY (MaTienNghi),
    CONSTRAINT UQ_TienNghi_Loai_STT UNIQUE (MaLoaiTN, SoThuTu),
    CONSTRAINT FK_TienNghi_Loai FOREIGN KEY (MaLoaiTN) REFERENCES LoaiTienNghi (MaLoaiTN)
);
GO

CREATE TABLE PhieuLapDat(
    SoPhieuLapDat  varchar(30)    NOT NULL,
    MaTienNghi     varchar(30)    NOT NULL,
    SoPhong        varchar(20)    NOT NULL,
    NgayLap        date           NOT NULL,
    TinhTrang      nvarchar(100)  NOT NULL,
    MaNV           varchar(20)    NOT NULL,
    GhiChu         nvarchar(250)  NULL,
    CONSTRAINT PK_PhieuLapDat PRIMARY KEY (SoPhieuLapDat),
    CONSTRAINT UQ_PhieuLapDat_ThietBi_Ngay UNIQUE (MaTienNghi, NgayLap),
    CONSTRAINT FK_PhieuLapDat_TienNghi FOREIGN KEY (MaTienNghi) REFERENCES TienNghi (MaTienNghi),
    CONSTRAINT FK_PhieuLapDat_Phong    FOREIGN KEY (SoPhong)    REFERENCES Phong (SoPhong),
    CONSTRAINT FK_PhieuLapDat_NV       FOREIGN KEY (MaNV)       REFERENCES NhanVien (MaNV)
);
GO

CREATE TABLE KhachHang(
    MaKhach       varchar(20)    NOT NULL,
    HoTen         nvarchar(120)  NOT NULL,
    SoCMND        varchar(30)    NOT NULL,
    QuocTich      nvarchar(80)   NOT NULL DEFAULT N'Việt Nam',
    GioiTinh      nvarchar(10)   NOT NULL DEFAULT N'Nam'
                  CONSTRAINT CK_KhachHang_GioiTinh CHECK (GioiTinh IN (N'Nam', N'Nữ')),
    NgaySinh      date           NULL
                  CONSTRAINT CK_KhachHang_NgaySinh CHECK (NgaySinh <= CAST(GETDATE() AS date)),
    DiaChi        nvarchar(200)  NULL,
    SoDienThoai   varchar(20)    NULL,
    CONSTRAINT PK_KhachHang PRIMARY KEY (MaKhach),
    CONSTRAINT UQ_KhachHang_CMND UNIQUE (SoCMND)
);
GO

CREATE TABLE PhieuDatPhong(
    SoPhieuDat        varchar(30)    NOT NULL,
    MaKhach           varchar(20)    NOT NULL,
    MaNVLeTan         varchar(20)    NOT NULL,
    SoPhong           varchar(20)    NOT NULL,
    NgayLap           datetime       NOT NULL DEFAULT GETDATE(),
    NgayNhan          date           NOT NULL,
    NgayTraDuKien     date           NOT NULL,
    TienCoc           decimal(18,2)  NOT NULL DEFAULT 0
                      CONSTRAINT CK_PhieuDat_Coc CHECK (TienCoc >= 0),
    KenhDat           nvarchar(20)   NOT NULL DEFAULT N'Trực tiếp'
                      CONSTRAINT CK_PhieuDat_Kenh
                      CHECK (KenhDat IN (N'Điện thoại', N'Website', N'Trực tiếp')),
    TrangThai         nvarchar(20)   NOT NULL DEFAULT N'Đặt trước'
                      CONSTRAINT CK_PhieuDat_TrangThai
                      CHECK (TrangThai IN (N'Đặt trước', N'Đang sử dụng', N'Đã trả', N'Đã hủy')),
    NgayNhanThucTe    datetime       NULL,
    NgayTraThucTe     datetime       NULL,
    GhiChu            nvarchar(250)  NULL,
    CONSTRAINT PK_PhieuDatPhong PRIMARY KEY (SoPhieuDat),
    CONSTRAINT CK_PhieuDat_Ngay CHECK (NgayTraDuKien >= NgayNhan),
    CONSTRAINT FK_PhieuDat_Khach FOREIGN KEY (MaKhach)   REFERENCES KhachHang (MaKhach),
    CONSTRAINT FK_PhieuDat_NV    FOREIGN KEY (MaNVLeTan) REFERENCES NhanVien (MaNV),
    CONSTRAINT FK_PhieuDat_Phong FOREIGN KEY (SoPhong)   REFERENCES Phong (SoPhong)
);
GO


CREATE TABLE NguoiLuuTru(
    MaNguoiLT   int             IDENTITY(1,1) NOT NULL,
    SoPhieuDat  varchar(30)     NOT NULL,
    HoTen       nvarchar(120)   NOT NULL,
    SoCMND      varchar(30)     NOT NULL,
    QuocTich    nvarchar(80)    NOT NULL DEFAULT N'Việt Nam',
    CONSTRAINT PK_NguoiLuuTru PRIMARY KEY (MaNguoiLT),
    CONSTRAINT FK_NguoiLT_Phieu FOREIGN KEY (SoPhieuDat) REFERENCES PhieuDatPhong (SoPhieuDat)
);
GO

CREATE TABLE DichVu(
    MaDV        varchar(20)     NOT NULL,
    TenDV       nvarchar(120)   NOT NULL,
    DonViTinh   nvarchar(40)    NOT NULL,
    DonGia      decimal(18,2)   NOT NULL
                CONSTRAINT CK_DichVu_DonGia CHECK (DonGia >= 0),
    CONSTRAINT PK_DichVu PRIMARY KEY (MaDV)
);
GO

CREATE TABLE SuDungDichVu(
    SoPhieuDat   varchar(30)    NOT NULL,
    MaDV         varchar(20)    NOT NULL,
    NgaySuDung   date           NOT NULL,
    SoLuong      int            NOT NULL
                 CONSTRAINT CK_SDDV_SoLuong CHECK (SoLuong > 0),
    DonGia       decimal(18,2)  NOT NULL
                 CONSTRAINT CK_SDDV_DonGia CHECK (DonGia >= 0),
    ThanhTien    AS (CONVERT(decimal(18,2), SoLuong * DonGia)) PERSISTED,
    MaNV         varchar(20)    NULL,   -- NV ghi nhận (UI chưa bắt bắt buộc)
    CONSTRAINT PK_SuDungDichVu PRIMARY KEY (SoPhieuDat, MaDV, NgaySuDung),
    CONSTRAINT FK_SDDV_Phieu   FOREIGN KEY (SoPhieuDat) REFERENCES PhieuDatPhong (SoPhieuDat),
    CONSTRAINT FK_SDDV_DichVu  FOREIGN KEY (MaDV)       REFERENCES DichVu (MaDV),
    CONSTRAINT FK_SDDV_NV      FOREIGN KEY (MaNV)       REFERENCES NhanVien (MaNV)
);
GO

CREATE TABLE QuyDinhDenBu(
    MaQuyDinh       varchar(30)    NOT NULL,
    MaLoaiTN        varchar(20)    NOT NULL,
    MucDoThietHai   nvarchar(80)   NOT NULL,
    MucDenBu        decimal(18,2)  NOT NULL
                    CONSTRAINT CK_QDDB_Muc CHECK (MucDenBu >= 0),
    CONSTRAINT PK_QuyDinhDenBu PRIMARY KEY (MaQuyDinh),
    CONSTRAINT UQ_QDDB_Loai_MucDo UNIQUE (MaLoaiTN, MucDoThietHai),
    CONSTRAINT FK_QDDB_Loai FOREIGN KEY (MaLoaiTN) REFERENCES LoaiTienNghi (MaLoaiTN)
);
GO
CREATE TABLE PhieuDenBu(
    SoPhieuDenBu  varchar(30)    NOT NULL,
    SoPhieuDat    varchar(30)    NOT NULL,
    NgayLap       datetime       NOT NULL DEFAULT GETDATE(),
    MaNV          varchar(20)    NOT NULL,
    TongTien      decimal(18,2)  NOT NULL DEFAULT 0
                  CONSTRAINT CK_PhieuDB_Tong CHECK (TongTien >= 0),
    CONSTRAINT PK_PhieuDenBu PRIMARY KEY (SoPhieuDenBu),
    CONSTRAINT FK_PhieuDB_Phieu FOREIGN KEY (SoPhieuDat) REFERENCES PhieuDatPhong (SoPhieuDat),
    CONSTRAINT FK_PhieuDB_NV    FOREIGN KEY (MaNV)       REFERENCES NhanVien (MaNV)
);
GO

CREATE TABLE ChiTietPhieuDenBu(
    SoPhieuDenBu    varchar(30)    NOT NULL,
    MaTienNghi      varchar(30)    NOT NULL,
    MucDoThietHai   nvarchar(80)   NOT NULL,
    SoTien          decimal(18,2)  NOT NULL
                    CONSTRAINT CK_CTDB_SoTien CHECK (SoTien >= 0),
    CONSTRAINT PK_ChiTietPhieuDenBu PRIMARY KEY (SoPhieuDenBu, MaTienNghi),
    CONSTRAINT FK_CTDB_Phieu    FOREIGN KEY (SoPhieuDenBu) REFERENCES PhieuDenBu (SoPhieuDenBu),
    CONSTRAINT FK_CTDB_TienNghi FOREIGN KEY (MaTienNghi)   REFERENCES TienNghi (MaTienNghi)
);
GO

CREATE TABLE HoaDon(
    SoHoaDon        varchar(30)    NOT NULL,
    SoPhieuDat      varchar(30)    NOT NULL,
    NgayLap         datetime       NOT NULL DEFAULT GETDATE(),
    MaNV            varchar(20)    NOT NULL,
    SoNgayTinhTien  int            NOT NULL
                    CONSTRAINT CK_HoaDon_SoNgay CHECK (SoNgayTinhTien > 0),
    TienPhong       decimal(18,2)  NOT NULL DEFAULT 0
                    CONSTRAINT CK_HoaDon_TienPhong CHECK (TienPhong >= 0),
    TienDichVu      decimal(18,2)  NOT NULL DEFAULT 0
                    CONSTRAINT CK_HoaDon_TienDV CHECK (TienDichVu >= 0),
    GiamGia         decimal(18,2)  NOT NULL DEFAULT 0
                    CONSTRAINT CK_HoaDon_GiamGia CHECK (GiamGia >= 0),
    TongTien        AS (CONVERT(decimal(18,2), TienPhong + TienDichVu - GiamGia)) PERSISTED,
    TrangThai       nvarchar(20)   NOT NULL DEFAULT N'Chưa thanh toán'
                    CONSTRAINT CK_HoaDon_TrangThai
                    CHECK (TrangThai IN (N'Chưa thanh toán', N'Đã thanh toán')),
    CONSTRAINT PK_HoaDon PRIMARY KEY (SoHoaDon),
    CONSTRAINT UQ_HoaDon_Phieu UNIQUE (SoPhieuDat),
    CONSTRAINT CK_HoaDon_GiamGia_KhongVuot
        CHECK (GiamGia <= TienPhong + TienDichVu),
    CONSTRAINT FK_HoaDon_Phieu FOREIGN KEY (SoPhieuDat) REFERENCES PhieuDatPhong (SoPhieuDat),
    CONSTRAINT FK_HoaDon_NV    FOREIGN KEY (MaNV)       REFERENCES NhanVien (MaNV)
);
GO

CREATE TABLE ThanhToan(
    MaThanhToan      varchar(30)    NOT NULL,
    SoHoaDon         varchar(30)    NOT NULL,
    NgayThanhToan    datetime       NOT NULL DEFAULT GETDATE(),
    HinhThuc         nvarchar(20)   NOT NULL
                     CONSTRAINT CK_ThanhToan_HinhThuc
                     CHECK (HinhThuc IN (N'Tiền mặt', N'Chuyển khoản', N'Thẻ ngân hàng', N'Ví điện tử')),
    SoTien           decimal(18,2)  NOT NULL
                     CONSTRAINT CK_ThanhToan_SoTien CHECK (SoTien > 0),
    CONSTRAINT PK_ThanhToan PRIMARY KEY (MaThanhToan),
    CONSTRAINT FK_ThanhToan_HoaDon FOREIGN KEY (SoHoaDon) REFERENCES HoaDon (SoHoaDon)
);
GO

CREATE INDEX IX_PhieuDat_Ngay      ON PhieuDatPhong (NgayNhan, NgayTraDuKien, TrangThai);
CREATE INDEX IX_PhieuDat_TrangThai ON PhieuDatPhong (TrangThai);
CREATE INDEX IX_SDDV_Phieu         ON SuDungDichVu (SoPhieuDat, NgaySuDung);
CREATE INDEX IX_HoaDon_NgayLap     ON HoaDon (NgayLap);
CREATE INDEX IX_ThanhToan_HoaDon   ON ThanhToan (SoHoaDon);
GO

DECLARE @homNay date = CAST(GETDATE() AS date);
DECLARE @gio    datetime = GETDATE();

INSERT INTO NhanVien (MaNV, HoTen, GioiTinh, SoDienThoai, ChucVu) VALUES
(N'NV001', N'Trịnh Thị Hoa', N'Nữ', N'0987654321', N'Quản lý'),
(N'NV002', N'Vũ Đức Thịnh', N'Nam', N'0905551234', N'Lễ tân'),
(N'NV003', N'Ngô Thị Hạnh', N'Nữ', N'0933221144', N'Buồng phòng');

INSERT INTO KhuVuc (MaKhuVuc, TenKhuVuc) VALUES
(N'KV01', N'Tầng 1'), (N'KV02', N'Tầng 2'), (N'KV03', N'Tầng 3'), (N'KV04', N'Tầng 4');

INSERT INTO LoaiPhong (MaLoai, TenLoai, DonGiaNgay, TienIch) VALUES
(N'LP001', N'Standard', 500000, N'Điều hòa, TV, Wi-Fi, Tủ lạnh'),
(N'LP002', N'Superior', 750000, N'Điều hòa, TV màn hình phẳng, Wi-Fi, Bồn tắm'),
(N'LP003', N'Deluxe', 1200000, N'Điều hòa, Smart TV, Wi-Fi, Ban công, Két sắt'),
(N'LP004', N'Suite', 2000000, N'Điều hòa, Smart TV 65 inch, Wi-Fi, Phòng khách riêng, Bếp nhỏ');

INSERT INTO Phong (SoPhong, MaLoai, MaKhuVuc, Tang, SoNguoiToiDa, TrangThai) VALUES
(N'P101', N'LP001', N'KV01', 1, 2, N'Có khách'),
(N'P102', N'LP001', N'KV01', 1, 2, N'Trống'),
(N'P103', N'LP001', N'KV01', 1, 2, N'Trống'),
(N'P104', N'LP001', N'KV01', 1, 2, N'Trống'),
(N'P201', N'LP002', N'KV02', 2, 3, N'Đã đặt'),
(N'P202', N'LP002', N'KV02', 2, 3, N'Trống'),
(N'P203', N'LP002', N'KV02', 2, 3, N'Trống'),
(N'P301', N'LP003', N'KV03', 3, 3, N'Trống'),
(N'P302', N'LP003', N'KV03', 3, 3, N'Trống'),
(N'P401', N'LP004', N'KV04', 4, 4, N'Trống');


INSERT INTO LoaiTienNghi (MaLoaiTN, TenLoaiTN) VALUES
(N'TN01', N'Ti vi'), (N'TN02', N'Tủ lạnh'), (N'TN03', N'Điện thoại'), (N'TN04', N'Máy lạnh');

INSERT INTO TienNghi (MaTienNghi, MaLoaiTN, SoThuTu, TinhTrangHienTai) VALUES
(N'TV01', N'TN01', 1, N'Tốt'), (N'TV02', N'TN01', 2, N'Tốt'),
(N'TL01', N'TN02', 1, N'Tốt'), (N'DT01', N'TN03', 1, N'Tốt'),
(N'ML01', N'TN04', 1, N'Tốt');

INSERT INTO PhieuLapDat (SoPhieuLapDat, MaTienNghi, SoPhong, NgayLap, TinhTrang, MaNV, GhiChu) VALUES
(N'LD001', N'TV01', N'P101', DATEADD(DAY, -30, @homNay), N'Đang lắp đặt', N'NV003', NULL),
(N'LD002', N'TL01', N'P101', DATEADD(DAY, -30, @homNay), N'Đang lắp đặt', N'NV003', NULL),
(N'LD003', N'ML01', N'P201', DATEADD(DAY, -25, @homNay), N'Đang lắp đặt', N'NV003', NULL);
INSERT INTO KhachHang (MaKhach, HoTen, SoCMND, QuocTich, GioiTinh, NgaySinh, DiaChi, SoDienThoai) VALUES
(N'KH001', N'Nguyễn Văn An', N'012345678901', N'Việt Nam', N'Nam', '1990-05-12', N'12 Lê Lợi, Q.1, TP.HCM', N'0901234567'),
(N'KH002', N'Trần Thị Bích', N'079123456789', N'Việt Nam', N'Nữ', '1995-08-03', N'45 Nguyễn Huệ, Q.1, TP.HCM', N'0912345678'),
(N'KH003', N'Lê Minh Cường', N'085987654321', N'Việt Nam', N'Nam', '1988-01-25', N'78 Trần Hưng Đạo, Hà Đông, Hà Nội', N'0938765432'),
(N'KH004', N'Phạm Thu Dung', N'036456789123', N'Việt Nam', N'Nữ', '1992-11-09', N'210 Hùng Vương, Hải Châu, Đà Nẵng', N'0978123456'),
(N'KH005', N'Hoàng Văn Em', N'091234567890', N'Việt Nam', N'Nam', '2000-03-30', N'5 Nguyễn Chí Thanh, TP. Huế', N'0356789123');
INSERT INTO DichVu (MaDV, TenDV, DonViTinh, DonGia) VALUES
(N'DV001', N'Đưa đón sân bay', N'lượt', 300000),
(N'DV002', N'Giặt ủi', N'kg', 50000),
(N'DV003', N'Spa - Massage', N'lượt', 250000),
(N'DV004', N'Buffet sáng', N'lượt', 120000),
(N'DV005', N'Đồ uống', N'chai', 30000),
(N'DV006', N'Thuê xe máy', N'ngày', 150000);

INSERT INTO QuyDinhDenBu (MaQuyDinh, MaLoaiTN, MucDoThietHai, MucDenBu) VALUES
(N'QD01', N'TN01', N'Hư hỏng nhẹ', 500000),
(N'QD02', N'TN01', N'Mất', 5000000),
(N'QD03', N'TN02', N'Hư hỏng nhẹ', 400000),
(N'QD04', N'TN02', N'Mất', 4000000),
(N'QD05', N'TN04', N'Hư hỏng nhẹ', 300000);
INSERT INTO PhieuDatPhong
    (SoPhieuDat, MaKhach, MaNVLeTan, SoPhong, NgayLap, NgayNhan, NgayTraDuKien,
     TienCoc, KenhDat, TrangThai, NgayNhanThucTe, NgayTraThucTe, GhiChu) VALUES
(N'DP003', N'KH003', N'NV002', N'P201', DATEADD(DAY, -46, @gio), DATEADD(DAY, -45, @homNay), DATEADD(DAY, -43, @homNay),
 0, N'Website', N'Đã trả', DATEADD(DAY, -45, @gio), DATEADD(DAY, -43, @gio), NULL),
(N'DP004', N'KH004', N'NV002', N'P301', DATEADD(DAY, -21, @gio), DATEADD(DAY, -20, @homNay), DATEADD(DAY, -17, @homNay),
 0, N'Trực tiếp', N'Đã trả', DATEADD(DAY, -20, @gio), DATEADD(DAY, -17, @gio), NULL),
(N'DP005', N'KH005', N'NV002', N'P101', DATEADD(DAY, -11, @gio), DATEADD(DAY, -10, @homNay), DATEADD(DAY, -9, @homNay),
 0, N'Điện thoại', N'Đã trả', DATEADD(DAY, -10, @gio), DATEADD(DAY, -9, @gio), NULL),
(N'DP006', N'KH001', N'NV002', N'P202', DATEADD(DAY, -5, @gio), DATEADD(DAY, -4, @homNay), DATEADD(DAY, -2, @homNay),
 0, N'Trực tiếp', N'Đã trả', DATEADD(DAY, -4, @gio), DATEADD(DAY, -2, @gio), NULL);

INSERT INTO NguoiLuuTru (SoPhieuDat, HoTen, SoCMND, QuocTich) VALUES
(N'DP003', N'Lê Minh Cường', N'085987654321', N'Việt Nam');

INSERT INTO PhieuDatPhong
    (SoPhieuDat, MaKhach, MaNVLeTan, SoPhong, NgayLap, NgayNhan, NgayTraDuKien,
     TienCoc, KenhDat, TrangThai, NgayNhanThucTe, GhiChu) VALUES
(N'DP001', N'KH001', N'NV002', N'P101', DATEADD(DAY, -1, @gio), @homNay, DATEADD(DAY, 2, @homNay),
 0, N'Điện thoại', N'Đang sử dụng', @gio, N'Khách đặt qua điện thoại'),
(N'DP002', N'KH002', N'NV002', N'P201', DATEADD(DAY, -2, @gio), DATEADD(DAY, 3, @homNay), DATEADD(DAY, 6, @homNay),
 500000, N'Website', N'Đặt trước', NULL, NULL);

INSERT INTO SuDungDichVu (SoPhieuDat, MaDV, NgaySuDung, SoLuong, DonGia, MaNV) VALUES
(N'DP001', N'DV004', @homNay, 2, 120000, N'NV002'),
(N'DP001', N'DV005', @homNay, 3, 30000, N'NV002');

INSERT INTO HoaDon (SoHoaDon, SoPhieuDat, NgayLap, MaNV, SoNgayTinhTien, TienPhong, TienDichVu, GiamGia, TrangThai) VALUES
(N'HD001', N'DP003', DATEADD(DAY, -43, @gio), N'NV002', 2, 1500000, 0, 0, N'Đã thanh toán'),
(N'HD002', N'DP004', DATEADD(DAY, -17, @gio), N'NV002', 3, 3600000, 0, 0, N'Đã thanh toán'),
(N'HD003', N'DP005', DATEADD(DAY, -9, @gio), N'NV002', 1, 500000, 0, 0, N'Đã thanh toán'),
(N'HD004', N'DP006', DATEADD(DAY, -2, @gio), N'NV002', 2, 1500000, 0, 0, N'Đã thanh toán');

INSERT INTO ThanhToan (MaThanhToan, SoHoaDon, NgayThanhToan, HinhThuc, SoTien) VALUES
(N'TT001', N'HD001', DATEADD(DAY, -43, @gio), N'Chuyển khoản', 1500000),
(N'TT002', N'HD002', DATEADD(DAY, -17, @gio), N'Tiền mặt', 3600000),
(N'TT003', N'HD003', DATEADD(DAY, -9, @gio), N'Tiền mặt', 500000),
(N'TT004', N'HD004', DATEADD(DAY, -2, @gio), N'Thẻ ngân hàng', 1500000);
GO

PRINT N'===== KHÓA CHÍNH (PRIMARY KEY) =====';
SELECT  OBJECT_NAME(kc.parent_object_id)                          AS Bang,
        kc.name                                                   AS TenKhoaChinh,
        c.name                                                    AS Cot,
        ic.key_ordinal                                            AS ThuTuCot
FROM    sys.key_constraints kc
JOIN    sys.index_columns ic ON ic.object_id = kc.parent_object_id
                            AND ic.index_id   = kc.unique_index_id
JOIN    sys.columns c       ON c.object_id  = ic.object_id
                            AND c.column_id = ic.column_id
WHERE   kc.type = 'PK'
ORDER BY Bang, ic.key_ordinal;

PRINT N'===== KHÓA NGOẠI (FOREIGN KEY) =====';
SELECT  fk.name                                                            AS TenKhoaNgoai,
        OBJECT_NAME(fkc.parent_object_id)                                  AS BangCon,
        pc.name                                                            AS CotCon,
        OBJECT_NAME(fkc.referenced_object_id)                              AS BangCha,
        rc.name                                                            AS CotCha
FROM    sys.foreign_keys fk
JOIN    sys.foreign_key_columns fkc ON fkc.constraint_object_id = fk.object_id
JOIN    sys.columns pc ON pc.object_id = fkc.parent_object_id
                      AND pc.column_id = fkc.parent_column_id
JOIN    sys.columns rc ON rc.object_id = fkc.referenced_object_id
                      AND rc.column_id = fkc.referenced_column_id
ORDER BY BangCon, TenKhoaNgoai;
PRINT N'===== RÀNG BUỘC UNIQUE / CHECK =====';
SELECT  OBJECT_NAME(cc.parent_object_id) AS Bang,
        cc.name                          AS TenRangBuoc,
        cc.type_desc                     AS Loai,
        cc.definition                    AS BieuThuc
FROM    sys.check_constraints cc
WHERE   cc.parent_object_id IN (SELECT object_id FROM sys.tables)
UNION ALL
SELECT  OBJECT_NAME(kc.parent_object_id), kc.name, N'UNIQUE_CONSTRAINT', NULL
FROM    sys.key_constraints kc
WHERE   kc.type = 'UQ'
ORDER BY Bang, TenRangBuoc;
PRINT N'===== TỔNG QUAN =====';
SELECT (SELECT COUNT(*) FROM sys.tables WHERE object_id IN (SELECT object_id FROM sys.tables)) AS SoBang,
       (SELECT COUNT(*) FROM sys.key_constraints WHERE type = 'PK') AS SoKhoaChinh,
       (SELECT COUNT(*) FROM sys.foreign_keys)                      AS SoKhoaNgoai,
       (SELECT COUNT(*) FROM sys.key_constraints WHERE type = 'UQ') AS SoUniq,
       (SELECT COUNT(*) FROM sys.check_constraints)                 AS SoCheck;
GO

