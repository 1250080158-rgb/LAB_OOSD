-- ============================================================
-- CSDL POSTGRESQL - QUAN LY CONG TY DU LICH
-- Tuong duong voi sqlserver_schema.sql (BIT->BOOLEAN, NTEXT->TEXT)
-- ============================================================

CREATE TABLE TOUR (
    MaTour      CHAR(10)      PRIMARY KEY,
    TenTour     VARCHAR(100)  NOT NULL,
    SoNgay      INT           NOT NULL CHECK (SoNgay > 0),
    SoDem       INT           NOT NULL CHECK (SoDem >= 0),
    DonGia      DECIMAL(18,0) NOT NULL CHECK (DonGia >= 0)
);

CREATE TABLE KHACH_HANG (
    MaKhachHang CHAR(10)      PRIMARY KEY,
    HoTen       VARCHAR(100)  NOT NULL,
    CMND        CHAR(12)      UNIQUE,
    SoDienThoai CHAR(15),
    DiaChi      VARCHAR(200),
    Email       VARCHAR(100)
);

CREATE TABLE NHAN_VIEN (
    MaNhanVien  CHAR(10)      PRIMARY KEY,
    HoTen       VARCHAR(100)  NOT NULL,
    CMND        CHAR(12)      UNIQUE,
    SoDienThoai CHAR(15),
    DiaChi      VARCHAR(200),
    LuongCanBan DECIMAL(18,0) NOT NULL
);

CREATE TABLE DIEM_THAM_QUAN (
    MaDiem   CHAR(10)      PRIMARY KEY,
    TenDiem  VARCHAR(100)  NOT NULL,
    DiaDiem  VARCHAR(100),
    NoiDung  TEXT,
    YNghia   TEXT
);

CREATE TABLE PHUONG_TIEN (
    MaPhuongTien  CHAR(10)     PRIMARY KEY,
    LoaiPhuongTien VARCHAR(50) NOT NULL,
    BienSo        VARCHAR(20),
    HangSanXuat   VARCHAR(50),
    SoCho         INT          NOT NULL CHECK (SoCho > 0)
);

CREATE TABLE NOI_DUNG_CHAN (
    MaNoiDungChan CHAR(10)      PRIMARY KEY,
    TenNoi        VARCHAR(100)  NOT NULL,
    DiaDiem       VARCHAR(100),
    DoiPhuongTien BOOLEAN       NOT NULL DEFAULT FALSE,
    CoNaiAn       BOOLEAN       NOT NULL DEFAULT FALSE,
    CoKhachSan    BOOLEAN       NOT NULL DEFAULT FALSE,
    LoaiKhachSan  INT           CHECK (LoaiKhachSan IN (2, 3, 4, 5) OR LoaiKhachSan IS NULL)
);

CREATE TABLE CHUYEN_DU_LICH (
    MaChuyen        CHAR(10)     PRIMARY KEY,
    MaTour          CHAR(10)     NOT NULL REFERENCES TOUR(MaTour),
    NgayDi          DATE         NOT NULL,
    NgayVe          DATE         NOT NULL,
    SoNguoiMax      INT          NOT NULL CHECK (SoNguoiMax > 0),
    SoNguoiDaDangKy INT          NOT NULL DEFAULT 0,
    TrangThai       VARCHAR(20)  NOT NULL DEFAULT 'Chua di',
    CONSTRAINT CHK_CHUYEN_NGAY CHECK (NgayVe >= NgayDi),
    CONSTRAINT CHK_CHUYEN_SOCHO CHECK (SoNguoiDaDangKy <= SoNguoiMax)
);

CREATE TABLE DANG_KY_DOAN (
    MaPhieuDoan   CHAR(10)      PRIMARY KEY,
    TenCoQuan     VARCHAR(100)  NOT NULL,
    DiaChiCoQuan  VARCHAR(200),
    DienThoaiCoQuan CHAR(15),
    NguoiDaiDien  VARCHAR(100)  NOT NULL,
    SoNguoiDi     INT           NOT NULL CHECK (SoNguoiDi > 12),
    MuaBaoHiem    BOOLEAN       NOT NULL DEFAULT FALSE,
    DiaDiemDon    VARCHAR(200),
    TienCoc       DECIMAL(18,0) NOT NULL DEFAULT 0,
    MaTour        CHAR(10)      NOT NULL REFERENCES TOUR(MaTour),
    NgayDi        DATE          NOT NULL,
    TrangThai     VARCHAR(20)   NOT NULL DEFAULT 'Chua di'
);

CREATE TABLE DANH_SACH_NGUOI_DI (
    MaPhieuDoan CHAR(10)      NOT NULL REFERENCES DANG_KY_DOAN(MaPhieuDoan) ON DELETE CASCADE,
    HoTen       VARCHAR(100)  NOT NULL,
    PRIMARY KEY (MaPhieuDoan, HoTen)
);

CREATE TABLE DANG_KY_CHUYEN (
    MaPhieuChuyen CHAR(10)      PRIMARY KEY,
    MaKhachHang   CHAR(10)      NOT NULL REFERENCES KHACH_HANG(MaKhachHang),
    MaChuyen      CHAR(10)      NOT NULL REFERENCES CHUYEN_DU_LICH(MaChuyen),
    NgayDangKy    DATE          NOT NULL,
    DiemBanVe     VARCHAR(100),
    DiaDiemDon    VARCHAR(200),
    ThanhTien     DECIMAL(18,0) NOT NULL,
    TrangThai     VARCHAR(20)   NOT NULL DEFAULT 'Chua thanh toan'
);

CREATE TABLE PHAN_CONG_NHAN_VIEN (
    MaPhanCong     CHAR(10)     PRIMARY KEY,
    MaNhanVien     CHAR(10)     NOT NULL REFERENCES NHAN_VIEN(MaNhanVien),
    LoaiPhanCong   VARCHAR(10)  NOT NULL CHECK (LoaiPhanCong IN ('Doan', 'Chuyen')),
    MaDoanHoacChuyen CHAR(10)   NOT NULL,
    NgayBatDau     DATE         NOT NULL,
    NgayKetThuc    DATE         NOT NULL,
    LuongTour      DECIMAL(18,0) NOT NULL DEFAULT 0,
    CONSTRAINT CHK_PHANCONG_NGAY CHECK (NgayKetThuc >= NgayBatDau)
);

CREATE TABLE KHAO_SAT (
    MaKhaoSat       CHAR(10)     PRIMARY KEY,
    MaDoanHoacChuyen CHAR(10)    NOT NULL,
    LoaiKhaoSat     VARCHAR(10)  NOT NULL CHECK (LoaiKhaoSat IN ('Doan', 'Chuyen')),
    NgayKhaoSat     DATE         NOT NULL,
    PhanHoi         TEXT         NOT NULL,
    DanhGia         INT          NOT NULL CHECK (DanhGia BETWEEN 1 AND 5)
);

CREATE TABLE TOUR_NOI_DUNG_CHAN (
    MaTour        CHAR(10) NOT NULL REFERENCES TOUR(MaTour) ON DELETE CASCADE,
    MaNoiDungChan CHAR(10) NOT NULL REFERENCES NOI_DUNG_CHAN(MaNoiDungChan) ON DELETE CASCADE,
    ThuTu         INT      NOT NULL DEFAULT 0,
    PRIMARY KEY (MaTour, MaNoiDungChan)
);

CREATE TABLE TOUR_PHUONG_TIEN (
    MaTour       CHAR(10) NOT NULL REFERENCES TOUR(MaTour) ON DELETE CASCADE,
    MaPhuongTien CHAR(10) NOT NULL REFERENCES PHUONG_TIEN(MaPhuongTien) ON DELETE CASCADE,
    ThuTu        INT      NOT NULL DEFAULT 0,
    PRIMARY KEY (MaTour, MaPhuongTien)
);

CREATE TABLE TOUR_DIEM_THAM_QUAN (
    MaTour CHAR(10) NOT NULL REFERENCES TOUR(MaTour) ON DELETE CASCADE,
    MaDiem CHAR(10) NOT NULL REFERENCES DIEM_THAM_QUAN(MaDiem) ON DELETE CASCADE,
    ThuTu  INT      NOT NULL DEFAULT 0,
    PRIMARY KEY (MaTour, MaDiem)
);

CREATE INDEX IX_DANG_KY_CHUYEN_MACHUYEN ON DANG_KY_CHUYEN(MaChuyen);
CREATE INDEX IX_DANG_KY_CHUYEN_MAKHACHHANG ON DANG_KY_CHUYEN(MaKhachHang);
CREATE INDEX IX_PHAN_CONG_MANHANVIEN ON PHAN_CONG_NHAN_VIEN(MaNhanVien);
CREATE INDEX IX_DANG_KY_DOAN_MATOUR ON DANG_KY_DOAN(MaTour);
