-- ============================================================
-- THIET KE CSDL SQL SERVER - QUAN LY CONG TY DU LICH
-- Van Hoa Viet TP.HCM
-- Nhat quan voi mo hinh lop (model goi com.travel.company.model)
-- Kien truc: UI -> Service -> Data
-- ============================================================

CREATE DATABASE QuanLyCongTyDuLich;
GO

USE QuanLyCongTyDuLich;
GO

-- ------------------------------------------------------------
-- BANG TOUR (model: Tour)
-- ------------------------------------------------------------
CREATE TABLE TOUR (
    MaTour      CHAR(10)     PRIMARY KEY,
    TenTour     NVARCHAR(100) NOT NULL,
    SoNgay      INT          NOT NULL CHECK (SoNgay > 0),
    SoDem       INT          NOT NULL CHECK (SoDem >= 0),
    DonGia      DECIMAL(18,0) NOT NULL CHECK (DonGia >= 0)
);
GO

-- ------------------------------------------------------------
-- BANG KHACH_HANG (model: KhachHang)
-- ------------------------------------------------------------
CREATE TABLE KHACH_HANG (
    MaKhachHang CHAR(10)      PRIMARY KEY,
    HoTen       NVARCHAR(100) NOT NULL,
    CMND        CHAR(12)      UNIQUE,
    SoDienThoai CHAR(15),
    DiaChi      NVARCHAR(200),
    Email       NVARCHAR(100)
);
GO

-- ------------------------------------------------------------
-- BANG NHAN_VIEN (model: NhanVien)
-- ------------------------------------------------------------
CREATE TABLE NHAN_VIEN (
    MaNhanVien  CHAR(10)      PRIMARY KEY,
    HoTen       NVARCHAR(100) NOT NULL,
    CMND        CHAR(12)      UNIQUE,
    SoDienThoai CHAR(15),
    DiaChi      NVARCHAR(200),
    LuongCanBan DECIMAL(18,0) NOT NULL
);
GO

-- ------------------------------------------------------------
-- BANG DIEM_THAM_QUAN (model: DiemThamQuan)
-- ------------------------------------------------------------
CREATE TABLE DIEM_THAM_QUAN (
    MaDiem   CHAR(10)      PRIMARY KEY,
    TenDiem  NVARCHAR(100) NOT NULL,
    DiaDiem  NVARCHAR(100),
    NoiDung  NTEXT,
    YNghia   NTEXT
);
GO

-- ------------------------------------------------------------
-- BANG PHUONG_TIEN (model: PhuongTien)
-- ------------------------------------------------------------
CREATE TABLE PHUONG_TIEN (
    MaPhuongTien  CHAR(10)      PRIMARY KEY,
    LoaiPhuongTien NVARCHAR(50) NOT NULL,
    BienSo        NVARCHAR(20),
    HangSanXuat   NVARCHAR(50),
    SoCho         INT          NOT NULL CHECK (SoCho > 0)
);
GO

-- ------------------------------------------------------------
-- BANG NOI_DUNG_CHAN (model: NoiDungChan)
-- ------------------------------------------------------------
CREATE TABLE NOI_DUNG_CHAN (
    MaNoiDungChan CHAR(10)      PRIMARY KEY,
    TenNoi        NVARCHAR(100) NOT NULL,
    DiaDiem       NVARCHAR(100),
    DoiPhuongTien BIT          NOT NULL DEFAULT 0,
    CoNaiAn       BIT          NOT NULL DEFAULT 0,
    CoKhachSan    BIT          NOT NULL DEFAULT 0,
    LoaiKhachSan  INT          CHECK (LoaiKhachSan IN (2, 3, 4, 5) OR LoaiKhachSan IS NULL)
);
GO

-- ------------------------------------------------------------
-- BANG CHUYEN_DU_LICH (model: ChuyenDuLich) - lich chuyen cua 1 tour
-- ------------------------------------------------------------
CREATE TABLE CHUYEN_DU_LICH (
    MaChuyen        CHAR(10)      PRIMARY KEY,
    MaTour          CHAR(10)      NOT NULL FOREIGN KEY REFERENCES TOUR(MaTour),
    NgayDi          DATE          NOT NULL,
    NgayVe          DATE          NOT NULL,
    SoNguoiMax      INT           NOT NULL CHECK (SoNguoiMax > 0),
    SoNguoiDaDangKy INT           NOT NULL DEFAULT 0,
    TrangThai       NVARCHAR(20)  NOT NULL DEFAULT N'Chua di',
    CONSTRAINT CHK_CHUYEN_NGAY CHECK (NgayVe >= NgayDi),
    CONSTRAINT CHK_CHUYEN_SOCHO CHECK (SoNguoiDaDangKy <= SoNguoiMax)
);
GO

-- ------------------------------------------------------------
-- BANG DANG_KY_DOAN (model: DangKyDoan) - dang ky theo doan (>12 nguoi)
-- ------------------------------------------------------------
CREATE TABLE DANG_KY_DOAN (
    MaPhieuDoan   CHAR(10)      PRIMARY KEY,
    TenCoQuan     NVARCHAR(100) NOT NULL,
    DiaChiCoQuan  NVARCHAR(200),
    DienThoaiCoQuan CHAR(15),
    NguoiDaiDien  NVARCHAR(100) NOT NULL,
    SoNguoiDi     INT           NOT NULL CHECK (SoNguoiDi > 12),
    MuaBaoHiem    BIT           NOT NULL DEFAULT 0,
    DiaDiemDon    NVARCHAR(200),
    TienCoc       DECIMAL(18,0) NOT NULL DEFAULT 0,
    MaTour        CHAR(10)      NOT NULL FOREIGN KEY REFERENCES TOUR(MaTour),
    NgayDi        DATE          NOT NULL,
    TrangThai     NVARCHAR(20)  NOT NULL DEFAULT N'Chua di'
);
GO

-- ------------------------------------------------------------
-- BANG DANH_SACH_NGUOI_DI - danh sach nguoi di kem (khi mua bao hiem)
-- ------------------------------------------------------------
CREATE TABLE DANH_SACH_NGUOI_DI (
    MaPhieuDoan CHAR(10)      NOT NULL FOREIGN KEY REFERENCES DANG_KY_DOAN(MaPhieuDoan) ON DELETE CASCADE,
    HoTen       NVARCHAR(100) NOT NULL,
    PRIMARY KEY (MaPhieuDoan, HoTen)
);
GO

-- ------------------------------------------------------------
-- BANG DANG_KY_CHUYEN (model: DangKyChuyen) - dang ky khach le (<12 nguoi)
-- ------------------------------------------------------------
CREATE TABLE DANG_KY_CHUYEN (
    MaPhieuChuyen CHAR(10)      PRIMARY KEY,
    MaKhachHang   CHAR(10)      NOT NULL FOREIGN KEY REFERENCES KHACH_HANG(MaKhachHang),
    MaChuyen      CHAR(10)      NOT NULL FOREIGN KEY REFERENCES CHUYEN_DU_LICH(MaChuyen),
    NgayDangKy    DATE          NOT NULL,
    DiemBanVe     NVARCHAR(100),
    DiaDiemDon    NVARCHAR(200),
    ThanhTien     DECIMAL(18,0) NOT NULL,
    TrangThai     NVARCHAR(20)  NOT NULL DEFAULT N'Chua thanh toan'
);
GO

-- ------------------------------------------------------------
-- BANG PHAN_CONG_NHAN_VIEN (model: PhanCongNhanVien)
-- ------------------------------------------------------------
CREATE TABLE PHAN_CONG_NHAN_VIEN (
    MaPhanCong     CHAR(10)     PRIMARY KEY,
    MaNhanVien     CHAR(10)     NOT NULL FOREIGN KEY REFERENCES NHAN_VIEN(MaNhanVien),
    LoaiPhanCong   NVARCHAR(10) NOT NULL CHECK (LoaiPhanCong IN (N'Doan', N'Chuyen')),
    MaDoanHoacChuyen CHAR(10)   NOT NULL,
    NgayBatDau     DATE         NOT NULL,
    NgayKetThuc    DATE         NOT NULL,
    LuongTour      DECIMAL(18,0) NOT NULL DEFAULT 0,
    CONSTRAINT CHK_PHANCONG_NGAY CHECK (NgayKetThuc >= NgayBatDau)
);
GO

-- ------------------------------------------------------------
-- BANG KHAO_SAT (model: KhaoSat)
-- ------------------------------------------------------------
CREATE TABLE KHAO_SAT (
    MaKhaoSat       CHAR(10)      PRIMARY KEY,
    MaDoanHoacChuyen CHAR(10)     NOT NULL,
    LoaiKhaoSat     NVARCHAR(10)  NOT NULL CHECK (LoaiKhaoSat IN (N'Doan', N'Chuyen')),
    NgayKhaoSat     DATE          NOT NULL,
    PhanHoi         NTEXT         NOT NULL,
    DanhGia         INT           NOT NULL CHECK (DanhGia BETWEEN 1 AND 5)
);
GO

-- ------------------------------------------------------------
-- BANG LIEN KET NHIEU-NHIEU: TOUR <-> NOI_DUNG_CHAN
-- ------------------------------------------------------------
CREATE TABLE TOUR_NOI_DUNG_CHAN (
    MaTour        CHAR(10) NOT NULL FOREIGN KEY REFERENCES TOUR(MaTour) ON DELETE CASCADE,
    MaNoiDungChan CHAR(10) NOT NULL FOREIGN KEY REFERENCES NOI_DUNG_CHAN(MaNoiDungChan) ON DELETE CASCADE,
    ThuTu         INT      NOT NULL DEFAULT 0,
    PRIMARY KEY (MaTour, MaNoiDungChan)
);
GO

-- ------------------------------------------------------------
-- BANG LIEN KET NHIEU-NHIEU: TOUR <-> PHUONG_TIEN
-- ------------------------------------------------------------
CREATE TABLE TOUR_PHUONG_TIEN (
    MaTour        CHAR(10) NOT NULL FOREIGN KEY REFERENCES TOUR(MaTour) ON DELETE CASCADE,
    MaPhuongTien  CHAR(10) NOT NULL FOREIGN KEY REFERENCES PHUONG_TIEN(MaPhuongTien) ON DELETE CASCADE,
    ThuTu         INT      NOT NULL DEFAULT 0,
    PRIMARY KEY (MaTour, MaPhuongTien)
);
GO

-- ------------------------------------------------------------
-- BANG LIEN KET NHIEU-NHIEU: TOUR <-> DIEM_THAM_QUAN
-- ------------------------------------------------------------
CREATE TABLE TOUR_DIEM_THAM_QUAN (
    MaTour CHAR(10) NOT NULL FOREIGN KEY REFERENCES TOUR(MaTour) ON DELETE CASCADE,
    MaDiem CHAR(10) NOT NULL FOREIGN KEY REFERENCES DIEM_THAM_QUAN(MaDiem) ON DELETE CASCADE,
    ThuTu  INT      NOT NULL DEFAULT 0,
    PRIMARY KEY (MaTour, MaDiem)
);
GO

-- ------------------------------------------------------------
-- INDEX ho tro truy van thong ke
-- ------------------------------------------------------------
CREATE INDEX IX_DANG_KY_CHUYEN_MACHUYEN ON DANG_KY_CHUYEN(MaChuyen);
CREATE INDEX IX_DANG_KY_CHUYEN_MAKHACHHANG ON DANG_KY_CHUYEN(MaKhachHang);
CREATE INDEX IX_PHAN_CONG_MANHANVIEN ON PHAN_CONG_NHAN_VIEN(MaNhanVien);
CREATE INDEX IX_DANG_KY_DOAN_MATOUR ON DANG_KY_DOAN(MaTour);
GO

PRINT 'Tao CSDL SQL Server thanh cong!'
