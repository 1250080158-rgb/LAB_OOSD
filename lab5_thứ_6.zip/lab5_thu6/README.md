# Quản lý Công ty Du lịch Văn Hóa Việt TP.HCM

Ứng dụng JavaFX quản lý công ty du lịch theo kiến trúc **UI → Service → Data**, kết nối CSDL **PostgreSQL** (thiết kế tương thích SQL Server).

## Cấu trúc dự án

```
src/main/java/com/travel/company/
├── Main.java                          # Điểm khởi chạy (khoi tao CSDL)
├── config/
│   └── DatabaseConfig.java            # Cau hinh ket noi CSDL
├── model/                             # 11 lop model (Tour, KhachHang, NhanVien, ...)
├── data/                              # LAYER DATA
│   ├── DatabaseConnection.java        # Ket noi JDBC (PostgreSQL)
│   ├── JdbcUtil.java                  # Xu ly SQL + sinh ma tu dong
│   ├── RowMapper.java                 # Map ResultSet -> model
│   ├── SchemaInitializer.java         # Tao bang + du lieu mau
│   └── *Dao.java                      # 11 DAO (CRUD + truy van)
├── service/                           # LAYER SERVICE (business logic)
│   ├── TourService.java               # CRUD tour + quan ly noi dung chan/phuong tien/diem tham quan
│   ├── KhachHangService.java          # CRUD khach hang
│   ├── NhanVienService.java           # CRUD nhan vien
│   ├── DiemThamQuanService.java       # CRUD diem tham quan
│   ├── PhuongTienService.java         # CRUD phuong tien
│   ├── NoiDungChanService.java        # CRUD noi dung chan
│   ├── ChuyenDuLichService.java       # CRUD chuyen + lich chuyen cua tour
│   ├── DangKyDoanService.java         # Dang ky doan (>12 nguoi) + validation
│   ├── DangKyChuyenService.java       # Dang ky chuyen (<12 nguoi) + quan ly ghe + thanh toan/huy
│   ├── PhanCongNhanVienService.java   # Phan cong + kiem tra xung dot lich + tinh luong thang
│   ├── KhaoSatService.java            # Luu khao sat khach hang
│   └── ThongKeService.java            # Thong ke bang SQL (doanh thu, tham gia, KH, NV, DTQ, tong quan)
├── util/
│   ├── UiUtil.java                    # Hop thoai alert/confirm/error
│   └── FormDialogUtil.java            # Dialog nhap lieu nhieu truong
└── ui/                                # LAYER UI (JavaFX)
    ├── MainFrame.java                 # Màn hình chính
    ├── DanhMucFrame.java              # Quản lý danh mục (6 tab) - dialog đầy đủ trường
    ├── QuanLyTourFrame.java           # Quản lý Tour + Nơi dừng chân/Phương tiện/Điểm tham quan/Chuyến
    ├── DangKyDoanFrame.java           # Đăng ký đoàn (>12 người)
    ├── DangKyChuyenFrame.java         # Đăng ký chuyến (<12 người) - điểm bán vé, địa điểm đón
    ├── PhanCongFrame.java             # Phân công nhân viên + tính lương tháng
    ├── KhaoSatFrame.java              # Khảo sát khách hàng
    └── ThongKeFrame.java              # Thống kê (6 báo cáo)
database/
├── sqlserver_schema.sql               # Thiết kế CSDL SQL Server (15 bảng)
└── postgresql_schema.sql              # CSDL PostgreSQL (tương đương)
lib/
└── postgresql-42.7.4.jar              # PostgreSQL JDBC Driver
```

## CSDL (15 bảng)

TOUR, KHACH_HANG, NHAN_VIEN, DIEM_THAM_QUAN, PHUONG_TIEN, NOI_DUNG_CHAN, CHUYEN_DU_LICH, DANG_KY_DOAN, DANH_SACH_NGUOI_DI, DANG_KY_CHUYEN, PHAN_CONG_NHAN_VIEN, KHAO_SAT, TOUR_NOI_DUNG_CHAN, TOUR_PHUONG_TIEN, TOUR_DIEM_THAM_QUAN

Quan hệ: CHUYEN_DU_LICH, DANG_KY_DOAN → TOUR; DANG_KY_CHUYEN → KHACH_HANG + CHUYEN_DU_LICH; PHAN_CONG_NHAN_VIEN → NHAN_VIEN; 3 bảng liên kết nhiều-nhiều TOUR ↔ (NOI_DUNG_CHAN, PHUONG_TIEN, DIEM_THAM_QUAN).

## Chức năng chính

1. **Danh mục** (6 tab): Tour, Khách hàng, Nhân viên, Điểm tham quan, Phương tiện, Nơi dừng chân — Thêm/Sửa/Xóa với dialog đầy đủ trường, validation phía Service.
2. **Quản lý Tour**: chi tiết tour, quản lý nơi dừng chân/phương tiện/điểm tham quan của tour, quản lý chuyến du lịch (lịch theo công ty).
3. **Đăng ký đoàn** (>12 người): thông tin cơ quan, số người, mua bảo hiểm (kèm danh sách người đi), địa điểm đón theo yêu cầu, tiền cọc, ngày đi bất kỳ.
4. **Đăng ký chuyến** (<12 người): chọn khách hàng + chuyến (hiển thị số chỗ còn), tự tính thành tiền từ đơn giá tour, điểm bán vé, địa điểm đón theo quy định, thanh toán/hủy (tự cập nhật số chỗ).
5. **Phân công nhân viên**: phân công cho đoàn/chuyến, kiểm tra trùng lặp lịch, tính lương tháng (lương căn bản + lương tour theo tháng).
6. **Khảo sát**: gửi phiếu sau khi đoàn/chuyến kết thúc, đánh giá 1-5 sao.
7. **Thống kê**: doanh thu theo tour, tham gia tour, khách hàng, hiệu suất nhân viên, độ phổ biến điểm tham quan, tổng quan.

## Cấu hình kết nối CSDL

`src/main/java/com/travel/company/config/DatabaseConfig.java`:
- URL: `jdbc:postgresql://localhost:5432/travel_company`
- User: `postgres` / Password: `postgres`

## Cách chạy

### Cách 1: run.bat (khuyên dung)

Can JDK 17+ va JavaFX SDK tai `C:\javafx`:

```
cd D:\BAITAP\lab5_thu6
run.bat
```

### Cách 2: Maven

```
cd D:\BAITAP\lab5_thu6
mvn clean javafx:run
```

### Cách 3: Thu cong

```
javac --module-path C:\javafx\lib --add-modules javafx.controls,javafx.fxml -cp "lib\postgresql-42.7.4.jar" -d out -encoding UTF-8 (Get-ChildItem src\main\java -Recurse -Filter *.java).FullName
java --module-path C:\javafx\lib --add-modules javafx.controls,javafx.fxml -cp "out;lib\postgresql-42.7.4.jar" com.travel.company.Main
```

## Yêu cầu hệ thống

- JDK 17 trở lên (đã test với JDK 25)
- JavaFX SDK 24+ (đã test với 24.0.2)
- PostgreSQL 14+ (đã test với PostgreSQL 18)
- Maven 3.6+ (nếu chạy bằng Maven)

## Ghi chú

- SchemaInitializer tự động tạo bảng và sinh dữ liệu mẫu khi CSDL trống.
- Mã tự động sinh theo bảng (T001..., KH001..., NV001..., ...).
- Trạng thái dùng tiếng Việt có dấu: "Chưa đi", "Đã kết thúc", "Đã thanh toán", "Đã hủy", "Chưa thanh toán".
- Thiết kế CSDL SQL Server xem tại `database/sqlserver_schema.sql`.
