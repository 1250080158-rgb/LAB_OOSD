import com.travel.company.data.SchemaInitializer;
import com.travel.company.model.*;
import com.travel.company.service.*;

import java.time.LocalDate;
import java.time.YearMonth;
import java.util.List;
import java.util.Map;

public class BackendTest {
    static int pass = 0;
    static int fail = 0;

    public static void main(String[] args) {
        SchemaInitializer.init();

        TourService tourService = new TourService();
        KhachHangService khService = new KhachHangService();
        NhanVienService nvService = new NhanVienService();
        ChuyenDuLichService chuyenService = new ChuyenDuLichService();
        DangKyChuyenService dkChuyenService = new DangKyChuyenService();
        DangKyDoanService dkDoanService = new DangKyDoanService();
        PhanCongNhanVienService pcService = new PhanCongNhanVienService();
        KhaoSatService ksService = new KhaoSatService();
        ThongKeService tkService = new ThongKeService();

        System.out.println("=== TEST 1: Tour CRUD ===");
        try {
            String maMoi = tourService.nextId();
            check("nextId tour", maMoi.equals("T005"), maMoi);
            Tour t = new Tour(maMoi, "Test Tour", 2, 1, 1000000);
            tourService.themTour(t);
            check("them tour", tourService.findById(maMoi) != null, maMoi);
            t.setDonGia(1500000);
            tourService.suaTour(t);
            check("sua tour", tourService.findById(maMoi).getDonGia() == 1500000, "donGia");
            // validation: soNguoi <= 0
            try {
                tourService.themTour(new Tour("T999", "", 2, 1, 100));
                check("validation ten tour rong", false, "khong nem exception");
            } catch (IllegalArgumentException e) {
                check("validation ten tour rong", true, e.getMessage());
            }
            tourService.xoaTour(maMoi);
            check("xoa tour", tourService.findById(maMoi) == null, maMoi);
        } catch (Exception e) {
            check("Tour CRUD", false, e.getMessage());
        }

        System.out.println("=== TEST 2: ChuyenDuLich CRUD ===");
        try {
            String maMoi = chuyenService.nextId();
            check("nextId chuyen", maMoi.equals("C004"), maMoi);
            ChuyenDuLich c = new ChuyenDuLich();
            c.setMaChuyen(maMoi);
            c.setMaTour("T001");
            c.setNgayDi(LocalDate.of(2026, 12, 1));
            c.setNgayVe(LocalDate.of(2026, 12, 5));
            c.setSoNguoiMax(20);
            chuyenService.themChuyen(c);
            check("them chuyen", chuyenService.findById(maMoi) != null, maMoi);
            // validation ngay ve < ngay di
            try {
                ChuyenDuLich bad = new ChuyenDuLich();
                bad.setMaChuyen("C999");
                bad.setMaTour("T001");
                bad.setNgayDi(LocalDate.of(2026, 12, 10));
                bad.setNgayVe(LocalDate.of(2026, 12, 5));
                bad.setSoNguoiMax(10);
                chuyenService.themChuyen(bad);
                check("validation ngay ve", false, "khong nem exception");
            } catch (IllegalArgumentException e) {
                check("validation ngay ve", true, e.getMessage());
            }
            chuyenService.xoaChuyen(maMoi);
        } catch (Exception e) {
            check("ChuyenDuLich CRUD", false, e.getMessage());
        }

        System.out.println("=== TEST 3: DangKyChuyen (ghe, thanh toan, huy) ===");
        try {
            ChuyenDuLich c001 = chuyenService.findById("C001");
            int truoc = c001.getSoNguoiDaDangKy();
            String maMoi = dkChuyenService.nextId();
            DangKyChuyen dk = new DangKyChuyen();
            dk.setMaPhieuChuyen(maMoi);
            dk.setMaKhachHang("KH001");
            dk.setMaChuyen("C001");
            dk.setNgayDangKy(LocalDate.now());
            dk.setThanhTien(3500000);
            dk.setDiemBanVe("Van phòng TP.HCM");
            dk.setDiaDiemDon("Bến xe Miền Đông");
            dkChuyenService.dangKyChuyen(dk);
            int sau = chuyenService.findById("C001").getSoNguoiDaDangKy();
            check("tang so nguoi dang ky", sau == truoc + 1, truoc + " -> " + sau);
            dkChuyenService.thanhToan(maMoi);
            check("thanh toan", dkChuyenService.findById(maMoi).getTrangThai().equals("Đã thanh toán"), "trangThai");
            // huy khi da thanh toan -> phai that bai
            try {
                dkChuyenService.huyChuyen(maMoi);
                check("huy sau thanh toan", false, "khong nem exception");
            } catch (IllegalArgumentException e) {
                check("huy sau thanh toan", true, e.getMessage());
            }
            // dang ky them 1 phieu chua thanh toan roi huy -> giam so nguoi
            String ma2 = dkChuyenService.nextId();
            DangKyChuyen dk2 = new DangKyChuyen();
            dk2.setMaPhieuChuyen(ma2);
            dk2.setMaKhachHang("KH002");
            dk2.setMaChuyen("C001");
            dk2.setNgayDangKy(LocalDate.now());
            dk2.setThanhTien(3500000);
            dkChuyenService.dangKyChuyen(dk2);
            int truocHuy = chuyenService.findById("C001").getSoNguoiDaDangKy();
            dkChuyenService.huyChuyen(ma2);
            int sauHuy = chuyenService.findById("C001").getSoNguoiDaDangKy();
            check("giam so nguoi khi huy", sauHuy == truocHuy - 1, truocHuy + " -> " + sauHuy);
            check("trang thai da huy", dkChuyenService.findById(ma2).getTrangThai().equals("Đã hủy"), "trangThai");
        } catch (Exception e) {
            check("DangKyChuyen", false, e.getMessage());
        }

        System.out.println("=== TEST 4: DangKyDoan (validation >12 nguoi) ===");
        try {
            String maMoi = dkDoanService.nextId();
            DangKyDoan doan = new DangKyDoan();
            doan.setMaPhieuDoan(maMoi);
            doan.setTenCoQuan("Công ty ABC");
            doan.setDiaChiCoQuan("123 Đường 3/2");
            doan.setDienThoaiCoQuan("02838999999");
            doan.setNguoiDaiDien("Nguyễn Văn A");
            doan.setSoNguoiDi(20);
            doan.setMuaBaoHiem(true);
            doan.getDanhSachNguoiDi().add("Nguyen Van A");
            doan.getDanhSachNguoiDi().add("Tran Thi B");
            doan.setDiaDiemDon("Văn phòng công ty");
            doan.setTienCoc(5000000);
            doan.setMaTour("T002");
            doan.setNgayDi(LocalDate.of(2026, 12, 20));
            dkDoanService.dangKyDoan(doan);
            check("them doan", dkDoanService.findById(maMoi) != null, maMoi);
            check("danh sach nguoi di", dkDoanService.findById(maMoi).getDanhSachNguoiDi().size() == 2, "size");
            // validation so nguoi <= 12
            try {
                DangKyDoan bad = new DangKyDoan();
                bad.setMaPhieuDoan("PD999");
                bad.setTenCoQuan("Test");
                bad.setNguoiDaiDien("Test");
                bad.setSoNguoiDi(10);
                bad.setMaTour("T001");
                bad.setNgayDi(LocalDate.now());
                dkDoanService.dangKyDoan(bad);
                check("validation >12 nguoi", false, "khong nem exception");
            } catch (IllegalArgumentException e) {
                check("validation >12 nguoi", true, e.getMessage());
            }
            dkDoanService.capNhatTrangThai(maMoi, "Đã kết thúc");
            check("hoan thanh doan", dkDoanService.findById(maMoi).getTrangThai().equals("Đã kết thúc"), "trangThai");
        } catch (Exception e) {
            check("DangKyDoan", false, e.getMessage());
        }

        System.out.println("=== TEST 5: PhanCong (xung dot lich, tinh luong) ===");
        try {
            String maMoi = pcService.nextId();
            PhanCongNhanVien pc = new PhanCongNhanVien();
            pc.setMaPhanCong(maMoi);
            pc.setMaNhanVien("NV001");
            pc.setLoaiPhanCong("Chuyen");
            pc.setMaDoanHoacChuyen("C001");
            pc.setNgayBatDau(LocalDate.of(2026, 11, 1));
            pc.setNgayKetThuc(LocalDate.of(2026, 11, 5));
            pc.setLuongTour(1000000);
            pcService.phanCong(pc);
            check("them phan cong", pcService.findById(maMoi) != null, maMoi);
            // phan cong trung lich -> phai that bai
            try {
                PhanCongNhanVien pc2 = new PhanCongNhanVien();
                pc2.setMaPhanCong("PC999");
                pc2.setMaNhanVien("NV001");
                pc2.setLoaiPhanCong("Chuyen");
                pc2.setMaDoanHoacChuyen("C002");
                pc2.setNgayBatDau(LocalDate.of(2026, 11, 3));
                pc2.setNgayKetThuc(LocalDate.of(2026, 11, 7));
                pc2.setLuongTour(500000);
                pcService.phanCong(pc2);
                check("validation xung dot lich", false, "khong nem exception");
            } catch (IllegalArgumentException e) {
                check("validation xung dot lich", true, e.getMessage());
            }
            // phan cong khong trung lich -> OK
            PhanCongNhanVien pc3 = new PhanCongNhanVien();
            pc3.setMaPhanCong(pcService.nextId());
            pc3.setMaNhanVien("NV001");
            pc3.setLoaiPhanCong("Chuyen");
            pc3.setMaDoanHoacChuyen("C002");
            pc3.setNgayBatDau(LocalDate.of(2026, 12, 1));
            pc3.setNgayKetThuc(LocalDate.of(2026, 12, 5));
            pc3.setLuongTour(800000);
            pcService.phanCong(pc3);
            check("phan cong khac lich", pcService.findById(pc3.getMaPhanCong()) != null, pc3.getMaPhanCong());
            // tinh luong thang 11/2026: 1,000,000 (pc3 la thang 12)
            double luongThang11 = pcService.tinhLuongTourThang("NV001", YearMonth.of(2026, 11));
            check("tinh luong thang 11", luongThang11 == 1000000, String.valueOf(luongThang11));
            double luongAll = pcService.tinhLuongTourThang("NV001", null);
            check("tinh luong all", luongAll == 1800000, String.valueOf(luongAll));
        } catch (Exception e) {
            check("PhanCong", false, e.getMessage());
        }

        System.out.println("=== TEST 6: KhaoSat ===");
        try {
            // Đoàn PD00x đã kết thúc ở test 4
            String maMoi = ksService.nextId();
            KhaoSat ks = new KhaoSat();
            ks.setMaKhaoSat(maMoi);
            ks.setMaDoanHoacChuyen("PD001".equals(maMoi) ? null : null);
            // tim doan da ket thuc
            List<DangKyDoan> doans = dkDoanService.findAll();
            String maDoanKT = doans.stream().filter(d -> "Đã kết thúc".equals(d.getTrangThai()))
                    .map(DangKyDoan::getMaPhieuDoan).findFirst().orElse(null);
            check("co doan da ket thuc", maDoanKT != null, "maDoan");
            ks.setMaDoanHoacChuyen(maDoanKT);
            ks.setLoaiKhaoSat("Doan");
            ks.setNgayKhaoSat(LocalDate.now());
            ks.setPhanHoi("Tour vui, đoàn kết");
            ks.setDanhGia(5);
            ksService.luuKhaoSat(ks);
            check("luu khao sat", ksService.findById(maMoi) != null, maMoi);
        } catch (Exception e) {
            check("KhaoSat", false, e.getMessage());
        }

        System.out.println("=== TEST 7: ThongKe ===");
        try {
            Map<String, Double> dt = tkService.doanhThuTour();
            check("doanh thu tour", dt != null && !dt.isEmpty(), String.valueOf(dt.size()));
            Map<String, Integer> tg = tkService.thamGiaTour();
            check("tham gia tour", tg != null && !tg.isEmpty(), String.valueOf(tg.size()));
            int[] kh = tkService.thongKeKhachHang();
            check("thong ke khach hang", kh[0] >= 3 && kh[1] >= 1, kh[0] + "/" + kh[1]);
            List<Object[]> hs = tkService.hieuSuatNhanVien();
            check("hieu suat nhan vien", hs != null && hs.size() == 3, String.valueOf(hs.size()));
            List<Object[]> dp = tkService.doPhoBienDiemThamQuan();
            check("do pho bien dtq", dp != null && !dp.isEmpty(), String.valueOf(dp.size()));
            Map<String, Integer> tq = tkService.tongQuan();
            check("tong quan", tq.get("Tour") >= 4, String.valueOf(tq.get("Tour")));
            check("diem trung binh", tkService.diemTrungBinhKhaoSat() == 5.0, String.valueOf(tkService.diemTrungBinhKhaoSat()));
        } catch (Exception e) {
            check("ThongKe", false, e.getMessage());
        }

        System.out.println("\n=== KET QUA: " + pass + " pass, " + fail + " fail ===");
        if (fail > 0) {
            System.exit(1);
        }
    }

    static void check(String ten, boolean ok, String chiTiet) {
        if (ok) {
            pass++;
            System.out.println("[PASS] " + ten + " (" + chiTiet + ")");
        } else {
            fail++;
            System.out.println("[FAIL] " + ten + " (" + chiTiet + ")");
        }
    }
}
