@echo off
REM Bien dich va chay ung dung JavaFX ket noi PostgreSQL
REM Can: JDK 17+, JavaFX SDK (C:\javafx), PostgreSQL JDBC driver (lib\postgresql-42.7.4.jar)

set JAVAFX_HOME=C:\javafx
set PROJECT_DIR=D:\BAITAP\lab5_thu6
set OUTPUT_DIR=%PROJECT_DIR%\out
set LIB_DIR=%PROJECT_DIR%\lib

echo Creating output directory...
if not exist %OUTPUT_DIR% mkdir %OUTPUT_DIR%

echo Compiling Java files...
javac --module-path %JAVAFX_HOME%\lib --add-modules javafx.controls,javafx.fxml -cp "%LIB_DIR%\postgresql-42.7.4.jar" -d %OUTPUT_DIR% -encoding UTF-8 %PROJECT_DIR%\src\main\java\com\travel\company\config\*.java %PROJECT_DIR%\src\main\java\com\travel\company\model\*.java %PROJECT_DIR%\src\main\java\com\travel\company\data\*.java %PROJECT_DIR%\src\main\java\com\travel\company\service\*.java %PROJECT_DIR%\src\main\java\com\travel\company\util\*.java %PROJECT_DIR%\src\main\java\com\travel\company\ui\*.java %PROJECT_DIR%\src\main\java\com\travel\company\*.java

if %ERRORLEVEL% NEQ 0 (
    echo Compilation failed!
    pause
    exit /b 1
)

echo Running application...
java --module-path %JAVAFX_HOME%\lib --add-modules javafx.controls,javafx.fxml -cp "%OUTPUT_DIR%;%LIB_DIR%\postgresql-42.7.4.jar" com.travel.company.Main

pause
