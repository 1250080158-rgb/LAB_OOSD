package com.travel.company.model;

import java.io.Serializable;

public class NhanVien implements Serializable {
    private String maNhanVien;
    private String hoTen;
    private String cmnd;
    private String soDienThoai;
    private String diaChi;
    private double luongCanBan;

    public NhanVien() {
    }

    public NhanVien(String maNhanVien, String hoTen, String cmnd, String soDienThoai, String diaChi, double luongCanBan) {
        this.maNhanVien = maNhanVien;
        this.hoTen = hoTen;
        this.cmnd = cmnd;
        this.soDienThoai = soDienThoai;
        this.diaChi = diaChi;
        this.luongCanBan = luongCanBan;
    }

    // Getters and Setters
    public String getMaNhanVien() {
        return maNhanVien;
    }

    public void setMaNhanVien(String maNhanVien) {
        this.maNhanVien = maNhanVien;
    }

    public String getHoTen() {
        return hoTen;
    }

    public void setHoTen(String hoTen) {
        this.hoTen = hoTen;
    }

    public String getCmnd() {
        return cmnd;
    }

    public void setCmnd(String cmnd) {
        this.cmnd = cmnd;
    }

    public String getSoDienThoai() {
        return soDienThoai;
    }

    public void setSoDienThoai(String soDienThoai) {
        this.soDienThoai = soDienThoai;
    }

    public String getDiaChi() {
        return diaChi;
    }

    public void setDiaChi(String diaChi) {
        this.diaChi = diaChi;
    }

    public double getLuongCanBan() {
        return luongCanBan;
    }

    public void setLuongCanBan(double luongCanBan) {
        this.luongCanBan = luongCanBan;
    }

    @Override
    public String toString() {
        return maNhanVien + " - " + hoTen;
    }
}
