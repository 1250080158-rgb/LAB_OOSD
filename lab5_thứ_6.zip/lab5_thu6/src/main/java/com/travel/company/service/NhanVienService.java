package com.travel.company.service;

import com.travel.company.data.NhanVienDao;
import com.travel.company.model.NhanVien;

import java.sql.SQLException;
import java.util.List;

public class NhanVienService {

    private final NhanVienDao dao = new NhanVienDao();

    public List<NhanVien> findAll() {
        try {
            return dao.findAll();
        } catch (SQLException e) {
            throw new RuntimeException("Lay danh sach nhan vien that bai: " + e.getMessage(), e);
        }
    }

    public NhanVien findById(String maNhanVien) {
        try {
            return dao.findById(maNhanVien);
        } catch (SQLException e) {
            throw new RuntimeException("Lay nhan vien that bai: " + e.getMessage(), e);
        }
    }

    public String nextId() {
        try {
            return dao.nextId();
        } catch (SQLException e) {
            throw new RuntimeException("Sinh ma nhan vien that bai: " + e.getMessage(), e);
        }
    }

    public void themNhanVien(NhanVien nv) {
        validate(nv);
        try {
            if (dao.findById(nv.getMaNhanVien()) != null) {
                throw new IllegalArgumentException("Ma nhan vien da ton tai!");
            }
            dao.insert(nv);
        } catch (SQLException e) {
            throw new RuntimeException("Them nhan vien that bai: " + e.getMessage(), e);
        }
    }

    public void suaNhanVien(NhanVien nv) {
        validate(nv);
        try {
            dao.update(nv);
        } catch (SQLException e) {
            throw new RuntimeException("Sua nhan vien that bai: " + e.getMessage(), e);
        }
    }

    public void xoaNhanVien(String maNhanVien) {
        try {
            dao.delete(maNhanVien);
        } catch (SQLException e) {
            throw new RuntimeException("Xoa nhan vien that bai (co the con lien ket du lieu): " + e.getMessage(), e);
        }
    }

    private void validate(NhanVien nv) {
        if (nv.getMaNhanVien() == null || nv.getMaNhanVien().trim().isEmpty()) {
            throw new IllegalArgumentException("Chua nhap ma nhan vien!");
        }
        if (nv.getHoTen() == null || nv.getHoTen().trim().isEmpty()) {
            throw new IllegalArgumentException("Chua nhap ho ten!");
        }
        if (nv.getLuongCanBan() < 0) {
            throw new IllegalArgumentException("Luong can ban khong duoc am!");
        }
    }
}
