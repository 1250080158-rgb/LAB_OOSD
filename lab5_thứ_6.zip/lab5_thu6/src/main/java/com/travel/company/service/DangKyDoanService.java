package com.travel.company.service;

import com.travel.company.data.DangKyDoanDao;
import com.travel.company.model.DangKyDoan;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;

public class DangKyDoanService {

    private final DangKyDoanDao dao = new DangKyDoanDao();

    public List<DangKyDoan> findAll() {
        try {
            return dao.findAll();
        } catch (SQLException e) {
            throw new RuntimeException("Lay danh sach dang ky doan that bai: " + e.getMessage(), e);
        }
    }

    public DangKyDoan findById(String maPhieuDoan) {
        try {
            return dao.findById(maPhieuDoan);
        } catch (SQLException e) {
            throw new RuntimeException("Lay dang ky doan that bai: " + e.getMessage(), e);
        }
    }

    public String nextId() {
        try {
            return dao.nextId();
        } catch (SQLException e) {
            throw new RuntimeException("Sinh ma phieu doan that bai: " + e.getMessage(), e);
        }
    }

    public void dangKyDoan(DangKyDoan doan) {
        validate(doan);
        try {
            if (dao.findById(doan.getMaPhieuDoan()) != null) {
                throw new IllegalArgumentException("Ma phieu doan da ton tai!");
            }
            dao.insert(doan);
        } catch (SQLException e) {
            throw new RuntimeException("Dang ky doan that bai: " + e.getMessage(), e);
        }
    }

    public void suaDoan(DangKyDoan doan) {
        validate(doan);
        try {
            dao.update(doan);
        } catch (SQLException e) {
            throw new RuntimeException("Sua doan that bai: " + e.getMessage(), e);
        }
    }

    public void capNhatTrangThai(String maPhieuDoan, String trangThai) {
        try {
            dao.updateTrangThai(maPhieuDoan, trangThai);
        } catch (SQLException e) {
            throw new RuntimeException("Cap nhat trang thai doan that bai: " + e.getMessage(), e);
        }
    }

    public void xoaDoan(String maPhieuDoan) {
        try {
            dao.delete(maPhieuDoan);
        } catch (SQLException e) {
            throw new RuntimeException("Xoa doan that bai: " + e.getMessage(), e);
        }
    }

    private void validate(DangKyDoan doan) {
        if (doan.getMaPhieuDoan() == null || doan.getMaPhieuDoan().trim().isEmpty()) {
            throw new IllegalArgumentException("Chua nhap ma phieu doan!");
        }
        if (doan.getTenCoQuan() == null || doan.getTenCoQuan().trim().isEmpty()) {
            throw new IllegalArgumentException("Chua nhap ten co quan/dai dien!");
        }
        if (doan.getNguoiDaiDien() == null || doan.getNguoiDaiDien().trim().isEmpty()) {
            throw new IllegalArgumentException("Chua nhap nguoi dai dien!");
        }
        if (doan.getSoNguoiDi() <= 12) {
            throw new IllegalArgumentException("Dang ky theo yeu cau so nguoi phai lon hon 12!");
        }
        if (doan.isMuaBaoHiem() && (doan.getDanhSachNguoiDi() == null || doan.getDanhSachNguoiDi().isEmpty())) {
            throw new IllegalArgumentException("Mua bao hiem phai co danh sach nguoi di!");
        }
        if (doan.getMaTour() == null || doan.getMaTour().trim().isEmpty()) {
            throw new IllegalArgumentException("Chua chon tour!");
        }
        if (doan.getNgayDi() == null) {
            throw new IllegalArgumentException("Chua chon ngay di!");
        }
        if (doan.getTienCoc() < 0) {
            throw new IllegalArgumentException("Tien coc khong duoc am!");
        }
    }
}
