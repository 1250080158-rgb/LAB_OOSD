package com.travel.company.service;

import com.travel.company.data.DiemThamQuanDao;
import com.travel.company.model.DiemThamQuan;

import java.sql.SQLException;
import java.util.List;

public class DiemThamQuanService {

    private final DiemThamQuanDao dao = new DiemThamQuanDao();

    public List<DiemThamQuan> findAll() {
        try {
            return dao.findAll();
        } catch (SQLException e) {
            throw new RuntimeException("Lay danh sach diem tham quan that bai: " + e.getMessage(), e);
        }
    }

    public DiemThamQuan findById(String maDiem) {
        try {
            return dao.findById(maDiem);
        } catch (SQLException e) {
            throw new RuntimeException("Lay diem tham quan that bai: " + e.getMessage(), e);
        }
    }

    public String nextId() {
        try {
            return dao.nextId();
        } catch (SQLException e) {
            throw new RuntimeException("Sinh ma diem tham quan that bai: " + e.getMessage(), e);
        }
    }

    public void themDiemThamQuan(DiemThamQuan dtq) {
        validate(dtq);
        try {
            if (dao.findById(dtq.getMaDiem()) != null) {
                throw new IllegalArgumentException("Ma diem tham quan da ton tai!");
            }
            dao.insert(dtq);
        } catch (SQLException e) {
            throw new RuntimeException("Them diem tham quan that bai: " + e.getMessage(), e);
        }
    }

    public void suaDiemThamQuan(DiemThamQuan dtq) {
        validate(dtq);
        try {
            dao.update(dtq);
        } catch (SQLException e) {
            throw new RuntimeException("Sua diem tham quan that bai: " + e.getMessage(), e);
        }
    }

    public void xoaDiemThamQuan(String maDiem) {
        try {
            dao.delete(maDiem);
        } catch (SQLException e) {
            throw new RuntimeException("Xoa diem tham quan that bai (co the con lien ket du lieu): " + e.getMessage(), e);
        }
    }

    private void validate(DiemThamQuan dtq) {
        if (dtq.getMaDiem() == null || dtq.getMaDiem().trim().isEmpty()) {
            throw new IllegalArgumentException("Chua nhap ma diem tham quan!");
        }
        if (dtq.getTenDiem() == null || dtq.getTenDiem().trim().isEmpty()) {
            throw new IllegalArgumentException("Chua nhap ten diem tham quan!");
        }
    }
}
