package com.travel.company.service;

import com.travel.company.data.TourDao;
import com.travel.company.model.NoiDungChan;
import com.travel.company.model.PhuongTien;
import com.travel.company.model.DiemThamQuan;
import com.travel.company.model.Tour;

import java.sql.SQLException;
import java.util.List;

public class TourService {

    private final TourDao tourDao = new TourDao();

    public List<Tour> findAll() {
        try {
            return tourDao.findAll();
        } catch (SQLException e) {
            throw new RuntimeException("Lay danh sach tour that bai: " + e.getMessage(), e);
        }
    }

    public Tour findById(String maTour) {
        try {
            return tourDao.findById(maTour);
        } catch (SQLException e) {
            throw new RuntimeException("Lay tour that bai: " + e.getMessage(), e);
        }
    }

    public String nextId() {
        try {
            return tourDao.nextId();
        } catch (SQLException e) {
            throw new RuntimeException("Sinh ma tour that bai: " + e.getMessage(), e);
        }
    }

    public void themTour(Tour tour) {
        validate(tour);
        try {
            if (tourDao.findById(tour.getMaTour()) != null) {
                throw new IllegalArgumentException("Ma tour da ton tai!");
            }
            tourDao.insert(tour);
        } catch (SQLException e) {
            throw new RuntimeException("Them tour that bai: " + e.getMessage(), e);
        }
    }

    public void suaTour(Tour tour) {
        validate(tour);
        try {
            tourDao.update(tour);
        } catch (SQLException e) {
            throw new RuntimeException("Sua tour that bai: " + e.getMessage(), e);
        }
    }

    public void xoaTour(String maTour) {
        try {
            tourDao.delete(maTour);
        } catch (SQLException e) {
            throw new RuntimeException("Xoa tour that bai (co the con lien ket du lieu): " + e.getMessage(), e);
        }
    }

    public void themNoiDungChan(String maTour, NoiDungChan ndc) {
        try {
            tourDao.addNoiDungChan(maTour, ndc.getMaNoiDungChan(), tourDao.findById(maTour).getNoiDungChans().size() + 1);
        } catch (SQLException e) {
            throw new RuntimeException("Them noi dung chan that bai: " + e.getMessage(), e);
        }
    }

    public void xoaNoiDungChan(String maTour, String maNoiDungChan) {
        try {
            tourDao.removeNoiDungChan(maTour, maNoiDungChan);
        } catch (SQLException e) {
            throw new RuntimeException("Xoa noi dung chan that bai: " + e.getMessage(), e);
        }
    }

    public void themPhuongTien(String maTour, PhuongTien pt) {
        try {
            tourDao.addPhuongTien(maTour, pt.getMaPhuongTien(), tourDao.findById(maTour).getPhuongTiens().size() + 1);
        } catch (SQLException e) {
            throw new RuntimeException("Them phuong tien that bai: " + e.getMessage(), e);
        }
    }

    public void xoaPhuongTien(String maTour, String maPhuongTien) {
        try {
            tourDao.removePhuongTien(maTour, maPhuongTien);
        } catch (SQLException e) {
            throw new RuntimeException("Xoa phuong tien that bai: " + e.getMessage(), e);
        }
    }

    public void themDiemThamQuan(String maTour, DiemThamQuan dtq) {
        try {
            tourDao.addDiemThamQuan(maTour, dtq.getMaDiem(), tourDao.findById(maTour).getDiemThamQuans().size() + 1);
        } catch (SQLException e) {
            throw new RuntimeException("Them diem tham quan that bai: " + e.getMessage(), e);
        }
    }

    public void xoaDiemThamQuan(String maTour, String maDiem) {
        try {
            tourDao.removeDiemThamQuan(maTour, maDiem);
        } catch (SQLException e) {
            throw new RuntimeException("Xoa diem tham quan that bai: " + e.getMessage(), e);
        }
    }

    private void validate(Tour tour) {
        if (tour.getMaTour() == null || tour.getMaTour().trim().isEmpty()) {
            throw new IllegalArgumentException("Chua nhap ma tour!");
        }
        if (tour.getTenTour() == null || tour.getTenTour().trim().isEmpty()) {
            throw new IllegalArgumentException("Chua nhap ten tour!");
        }
        if (tour.getSoNgay() <= 0) {
            throw new IllegalArgumentException("So ngay phai lon hon 0!");
        }
        if (tour.getSoDem() < 0) {
            throw new IllegalArgumentException("So dem khong duoc am!");
        }
        if (tour.getDonGia() < 0) {
            throw new IllegalArgumentException("Don gia khong duoc am!");
        }
    }
}
