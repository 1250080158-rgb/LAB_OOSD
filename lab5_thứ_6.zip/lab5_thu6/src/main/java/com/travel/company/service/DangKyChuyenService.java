package com.travel.company.service;

import com.travel.company.data.ChuyenDuLichDao;
import com.travel.company.data.DangKyChuyenDao;
import com.travel.company.model.ChuyenDuLich;
import com.travel.company.model.DangKyChuyen;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;

public class DangKyChuyenService {

    private final DangKyChuyenDao dao = new DangKyChuyenDao();
    private final ChuyenDuLichDao chuyenDao = new ChuyenDuLichDao();

    public List<DangKyChuyen> findAll() {
        try {
            return dao.findAll();
        } catch (SQLException e) {
            throw new RuntimeException("Lay danh sach dang ky chuyen that bai: " + e.getMessage(), e);
        }
    }

    public DangKyChuyen findById(String maPhieuChuyen) {
        try {
            return dao.findById(maPhieuChuyen);
        } catch (SQLException e) {
            throw new RuntimeException("Lay dang ky chuyen that bai: " + e.getMessage(), e);
        }
    }

    public String nextId() {
        try {
            return dao.nextId();
        } catch (SQLException e) {
            throw new RuntimeException("Sinh ma phieu chuyen that bai: " + e.getMessage(), e);
        }
    }

    public void dangKyChuyen(DangKyChuyen dangKy) {
        validate(dangKy);
        try {
            if (dao.findById(dangKy.getMaPhieuChuyen()) != null) {
                throw new IllegalArgumentException("Ma phieu chuyen da ton tai!");
            }
            ChuyenDuLich chuyen = chuyenDao.findById(dangKy.getMaChuyen());
            if (chuyen == null) {
                throw new IllegalArgumentException("Chuyen du lich khong ton tai!");
            }
            if (chuyen.getConLai() <= 0) {
                throw new IllegalArgumentException("Chuyen nay da het cho!");
            }
            dao.insert(dangKy);
            chuyenDao.updateSoNguoiDaDangKy(chuyen.getMaChuyen(), chuyen.getSoNguoiDaDangKy() + 1);
        } catch (SQLException e) {
            throw new RuntimeException("Dang ky chuyen that bai: " + e.getMessage(), e);
        }
    }

    public void thanhToan(String maPhieuChuyen) {
        try {
            DangKyChuyen dk = dao.findById(maPhieuChuyen);
            if (dk == null) {
                throw new IllegalArgumentException("Phieu dang ky khong ton tai!");
            }
            dao.updateTrangThai(maPhieuChuyen, "Đã thanh toán");
        } catch (SQLException e) {
            throw new RuntimeException("Thanh toan that bai: " + e.getMessage(), e);
        }
    }

    public void huyChuyen(String maPhieuChuyen) {
        try {
            DangKyChuyen dk = dao.findById(maPhieuChuyen);
            if (dk == null) {
                throw new IllegalArgumentException("Phieu dang ky khong ton tai!");
            }
            if ("Đã thanh toán".equals(dk.getTrangThai())) {
                throw new IllegalArgumentException("Đã thanh toán, không thể hủy!");
            }
            ChuyenDuLich chuyen = chuyenDao.findById(dk.getMaChuyen());
            if (chuyen != null && chuyen.getSoNguoiDaDangKy() > 0) {
                chuyenDao.updateSoNguoiDaDangKy(chuyen.getMaChuyen(), chuyen.getSoNguoiDaDangKy() - 1);
            }
            dao.updateTrangThai(maPhieuChuyen, "Đã hủy");
        } catch (SQLException e) {
            throw new RuntimeException("Huy chuyen that bai: " + e.getMessage(), e);
        }
    }

    public void xoaDangKy(String maPhieuChuyen) {
        try {
            DangKyChuyen dk = dao.findById(maPhieuChuyen);
            if (dk != null && !"Da huy".equals(dk.getTrangThai())) {
                ChuyenDuLich chuyen = chuyenDao.findById(dk.getMaChuyen());
                if (chuyen != null && chuyen.getSoNguoiDaDangKy() > 0) {
                    chuyenDao.updateSoNguoiDaDangKy(chuyen.getMaChuyen(), chuyen.getSoNguoiDaDangKy() - 1);
                }
            }
            dao.delete(maPhieuChuyen);
        } catch (SQLException e) {
            throw new RuntimeException("Xoa dang ky chuyen that bai: " + e.getMessage(), e);
        }
    }

    private void validate(DangKyChuyen dangKy) {
        if (dangKy.getMaPhieuChuyen() == null || dangKy.getMaPhieuChuyen().trim().isEmpty()) {
            throw new IllegalArgumentException("Chua nhap ma phieu chuyen!");
        }
        if (dangKy.getMaKhachHang() == null || dangKy.getMaKhachHang().trim().isEmpty()) {
            throw new IllegalArgumentException("Chua chon khach hang!");
        }
        if (dangKy.getMaChuyen() == null || dangKy.getMaChuyen().trim().isEmpty()) {
            throw new IllegalArgumentException("Chua chon chuyen!");
        }
        if (dangKy.getNgayDangKy() == null) {
            throw new IllegalArgumentException("Chua chon ngay dang ky!");
        }
        if (dangKy.getThanhTien() < 0) {
            throw new IllegalArgumentException("Thanh tien khong duoc am!");
        }
    }
}
