package com.travel.company.data;

import com.travel.company.model.PhuongTien;

import java.sql.SQLException;
import java.util.List;

public class PhuongTienDao {

    private static final RowMapper<PhuongTien> MAPPER = rs -> new PhuongTien(
            rs.getString("MaPhuongTien"),
            rs.getString("LoaiPhuongTien"),
            rs.getString("BienSo"),
            rs.getString("HangSanXuat"),
            rs.getInt("SoCho"));

    public List<PhuongTien> findAll() throws SQLException {
        return JdbcUtil.query("SELECT * FROM PHUONG_TIEN ORDER BY MaPhuongTien", MAPPER);
    }

    public PhuongTien findById(String maPhuongTien) throws SQLException {
        return JdbcUtil.queryOne("SELECT * FROM PHUONG_TIEN WHERE MaPhuongTien = ?", MAPPER, maPhuongTien);
    }

    public void insert(PhuongTien pt) throws SQLException {
        JdbcUtil.update("INSERT INTO PHUONG_TIEN (MaPhuongTien, LoaiPhuongTien, BienSo, HangSanXuat, SoCho) VALUES (?, ?, ?, ?, ?)",
                pt.getMaPhuongTien(), pt.getLoaiPhuongTien(), pt.getBienSo(), pt.getHangSanXuat(), pt.getSoCho());
    }

    public void update(PhuongTien pt) throws SQLException {
        JdbcUtil.update("UPDATE PHUONG_TIEN SET LoaiPhuongTien = ?, BienSo = ?, HangSanXuat = ?, SoCho = ? WHERE MaPhuongTien = ?",
                pt.getLoaiPhuongTien(), pt.getBienSo(), pt.getHangSanXuat(), pt.getSoCho(), pt.getMaPhuongTien());
    }

    public void delete(String maPhuongTien) throws SQLException {
        JdbcUtil.update("DELETE FROM PHUONG_TIEN WHERE MaPhuongTien = ?", maPhuongTien);
    }

    public String nextId() throws SQLException {
        return JdbcUtil.nextId("PHUONG_TIEN", "MaPhuongTien", "PT", 3);
    }
}
