package com.travel.company.service;

import com.travel.company.data.ChuyenDuLichDao;
import com.travel.company.data.DangKyDoanDao;
import com.travel.company.data.PhanCongNhanVienDao;
import com.travel.company.model.PhanCongNhanVien;

import java.sql.SQLException;
import java.time.LocalDate;
import java.time.YearMonth;
import java.util.List;
import java.util.stream.Collectors;

public class PhanCongNhanVienService {

    private final PhanCongNhanVienDao dao = new PhanCongNhanVienDao();
    private final DangKyDoanDao dangKyDoanDao = new DangKyDoanDao();
    private final ChuyenDuLichDao chuyenDuLichDao = new ChuyenDuLichDao();

    /**
     * Danh sach ma phiếu đoàn để phân công.
     */
    public List<String> getDangKyDoanIds() {
        try {
            return dangKyDoanDao.findAll().stream()
                    .map(d -> d.getMaPhieuDoan())
                    .collect(Collectors.toList());
        } catch (SQLException e) {
            throw new RuntimeException("Lay danh sach doan that bai: " + e.getMessage(), e);
        }
    }

    /**
     * Danh sach ma chuyen để phân công.
     */
    public List<String> getChuyenDuLichIds() {
        try {
            return chuyenDuLichDao.findAll().stream()
                    .map(c -> c.getMaChuyen())
                    .collect(Collectors.toList());
        } catch (SQLException e) {
            throw new RuntimeException("Lay danh sach chuyen that bai: " + e.getMessage(), e);
        }
    }

    public List<PhanCongNhanVien> findAll() {
        try {
            return dao.findAll();
        } catch (SQLException e) {
            throw new RuntimeException("Lay danh sach phan cong that bai: " + e.getMessage(), e);
        }
    }

    public List<PhanCongNhanVien> findByNhanVien(String maNhanVien) {
        try {
            return dao.findByNhanVien(maNhanVien);
        } catch (SQLException e) {
            throw new RuntimeException("Lay phan cong cua nhan vien that bai: " + e.getMessage(), e);
        }
    }

    public PhanCongNhanVien findById(String maPhanCong) {
        try {
            return dao.findById(maPhanCong);
        } catch (SQLException e) {
            throw new RuntimeException("Lay phan cong that bai: " + e.getMessage(), e);
        }
    }

    public String nextId() {
        try {
            return dao.nextId();
        } catch (SQLException e) {
            throw new RuntimeException("Sinh ma phan cong that bai: " + e.getMessage(), e);
        }
    }

    public void phanCong(PhanCongNhanVien pc) {
        validate(pc);
        try {
            if (dao.findById(pc.getMaPhanCong()) != null) {
                throw new IllegalArgumentException("Ma phan cong da ton tai!");
            }
            if (kiemTraXungDotLich(pc.getMaNhanVien(), pc.getNgayBatDau(), pc.getNgayKetThuc())) {
                throw new IllegalArgumentException("Nhan vien nay da co phan cong trong khoang thoi gian nay!");
            }
            dao.insert(pc);
        } catch (SQLException e) {
            throw new RuntimeException("Phan cong nhan vien that bai: " + e.getMessage(), e);
        }
    }

    public void xoaPhanCong(String maPhanCong) {
        try {
            dao.delete(maPhanCong);
        } catch (SQLException e) {
            throw new RuntimeException("Xoa phan cong that bai: " + e.getMessage(), e);
        }
    }

    /**
     * Kiem tra xung dot lich: 2 khoang ngay [bd1,kt1] va [bd2,kt2]重叠 khi
     * kt1 >= bd2 va kt2 >= bd1.
     */
    public boolean kiemTraXungDotLich(String maNhanVien, LocalDate ngayBatDau, LocalDate ngayKetThuc) {
        List<PhanCongNhanVien> danhSach = findByNhanVien(maNhanVien);
        for (PhanCongNhanVien pc : danhSach) {
            boolean xungDot = !ngayKetThuc.isBefore(pc.getNgayBatDau()) && !ngayBatDau.isAfter(pc.getNgayKetThuc());
            if (xungDot) {
                return true;
            }
        }
        return false;
    }

    /**
     * Tinh luong thang cua nhan vien: luong can ban + tong luong tour
     * cua cac phan cong trong thang (tinh theo ngay bat dau).
     */
    public double tinhLuongTourThang(String maNhanVien, YearMonth thang) {
        List<PhanCongNhanVien> danhSach = findByNhanVien(maNhanVien);
        double tong = 0;
        for (PhanCongNhanVien pc : danhSach) {
            if (pc.getNgayBatDau() == null) {
                continue;
            }
            YearMonth namThangPc = YearMonth.from(pc.getNgayBatDau());
            if (thang == null || namThangPc.equals(thang)) {
                tong += pc.getLuongTour();
            }
        }
        return tong;
    }

    private void validate(PhanCongNhanVien pc) {
        if (pc.getMaPhanCong() == null || pc.getMaPhanCong().trim().isEmpty()) {
            throw new IllegalArgumentException("Chua nhap ma phan cong!");
        }
        if (pc.getMaNhanVien() == null || pc.getMaNhanVien().trim().isEmpty()) {
            throw new IllegalArgumentException("Chua chon nhan vien!");
        }
        if (pc.getLoaiPhanCong() == null || pc.getLoaiPhanCong().trim().isEmpty()) {
            throw new IllegalArgumentException("Chua chon loai phan cong!");
        }
        if (pc.getMaDoanHoacChuyen() == null || pc.getMaDoanHoacChuyen().trim().isEmpty()) {
            throw new IllegalArgumentException("Chua chon doan/chuyen!");
        }
        if (pc.getNgayBatDau() == null || pc.getNgayKetThuc() == null) {
            throw new IllegalArgumentException("Chua chon ngay bat dau/ket thuc!");
        }
        if (pc.getNgayKetThuc().isBefore(pc.getNgayBatDau())) {
            throw new IllegalArgumentException("Ngay ket thuc phai sau ngay bat dau!");
        }
        if (pc.getLuongTour() < 0) {
            throw new IllegalArgumentException("Luong tour khong duoc am!");
        }
    }
}
