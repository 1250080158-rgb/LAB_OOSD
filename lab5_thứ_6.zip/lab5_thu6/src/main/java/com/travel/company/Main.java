package com.travel.company;

import com.travel.company.data.SchemaInitializer;
import com.travel.company.ui.MainFrame;

public class Main {
    public static void main(String[] args) {
        SchemaInitializer.init(); // Khoi tao CSDL (schema + du lieu mau)
        MainFrame.main(args);
    }
}
