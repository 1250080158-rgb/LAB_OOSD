package com.travel.company.model;

import java.io.Serializable;
import java.time.LocalDate;

public class KhaoSat implements Serializable {
    private String maKhaoSat;
    private String maDoanHoacChuyen; // Mã phiếu đoàn hoặc mã chuyến
    private String loaiKhaoSat; // "Doan" hoặc "Chuyen"
    private LocalDate ngayKhaoSat;
    private String phanHoi;
    private int danhGia; // 1-5 sao

    public KhaoSat() {
    }

    public KhaoSat(String maKhaoSat, String maDoanHoacChuyen, String loaiKhaoSat, LocalDate ngayKhaoSat, String phanHoi, int danhGia) {
        this.maKhaoSat = maKhaoSat;
        this.maDoanHoacChuyen = maDoanHoacChuyen;
        this.loaiKhaoSat = loaiKhaoSat;
        this.ngayKhaoSat = ngayKhaoSat;
        this.phanHoi = phanHoi;
        this.danhGia = danhGia;
    }

    // Getters and Setters
    public String getMaKhaoSat() {
        return maKhaoSat;
    }

    public void setMaKhaoSat(String maKhaoSat) {
        this.maKhaoSat = maKhaoSat;
    }

    public String getMaDoanHoacChuyen() {
        return maDoanHoacChuyen;
    }

    public void setMaDoanHoacChuyen(String maDoanHoacChuyen) {
        this.maDoanHoacChuyen = maDoanHoacChuyen;
    }

    public String getLoaiKhaoSat() {
        return loaiKhaoSat;
    }

    public void setLoaiKhaoSat(String loaiKhaoSat) {
        this.loaiKhaoSat = loaiKhaoSat;
    }

    public LocalDate getNgayKhaoSat() {
        return ngayKhaoSat;
    }

    public void setNgayKhaoSat(LocalDate ngayKhaoSat) {
        this.ngayKhaoSat = ngayKhaoSat;
    }

    public String getPhanHoi() {
        return phanHoi;
    }

    public void setPhanHoi(String phanHoi) {
        this.phanHoi = phanHoi;
    }

    public int getDanhGia() {
        return danhGia;
    }

    public void setDanhGia(int danhGia) {
        this.danhGia = danhGia;
    }

    @Override
    public String toString() {
        return maKhaoSat + " - " + maDoanHoacChuyen + " (" + danhGia + " sao)";
    }
}
