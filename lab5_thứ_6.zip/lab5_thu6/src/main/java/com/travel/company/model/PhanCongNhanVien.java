package com.travel.company.model;

import java.io.Serializable;
import java.time.LocalDate;

public class PhanCongNhanVien implements Serializable {
    private String maPhanCong;
    private String maNhanVien;
    private String loaiPhanCong; // "Doan" hoặc "Chuyen"
    private String maDoanHoacChuyen; // Mã phiếu đoàn hoặc mã chuyến
    private LocalDate ngayBatDau;
    private LocalDate ngayKetThuc;
    private double luongTour;

    public PhanCongNhanVien() {
    }

    public PhanCongNhanVien(String maPhanCong, String maNhanVien, String loaiPhanCong, String maDoanHoacChuyen,
                           LocalDate ngayBatDau, LocalDate ngayKetThuc, double luongTour) {
        this.maPhanCong = maPhanCong;
        this.maNhanVien = maNhanVien;
        this.loaiPhanCong = loaiPhanCong;
        this.maDoanHoacChuyen = maDoanHoacChuyen;
        this.ngayBatDau = ngayBatDau;
        this.ngayKetThuc = ngayKetThuc;
        this.luongTour = luongTour;
    }

    // Getters and Setters
    public String getMaPhanCong() {
        return maPhanCong;
    }

    public void setMaPhanCong(String maPhanCong) {
        this.maPhanCong = maPhanCong;
    }

    public String getMaNhanVien() {
        return maNhanVien;
    }

    public void setMaNhanVien(String maNhanVien) {
        this.maNhanVien = maNhanVien;
    }

    public String getLoaiPhanCong() {
        return loaiPhanCong;
    }

    public void setLoaiPhanCong(String loaiPhanCong) {
        this.loaiPhanCong = loaiPhanCong;
    }

    public String getMaDoanHoacChuyen() {
        return maDoanHoacChuyen;
    }

    public void setMaDoanHoacChuyen(String maDoanHoacChuyen) {
        this.maDoanHoacChuyen = maDoanHoacChuyen;
    }

    public LocalDate getNgayBatDau() {
        return ngayBatDau;
    }

    public void setNgayBatDau(LocalDate ngayBatDau) {
        this.ngayBatDau = ngayBatDau;
    }

    public LocalDate getNgayKetThuc() {
        return ngayKetThuc;
    }

    public void setNgayKetThuc(LocalDate ngayKetThuc) {
        this.ngayKetThuc = ngayKetThuc;
    }

    public double getLuongTour() {
        return luongTour;
    }

    public void setLuongTour(double luongTour) {
        this.luongTour = luongTour;
    }

    @Override
    public String toString() {
        return maPhanCong + " - " + maNhanVien + " (" + loaiPhanCong + ")";
    }
}
