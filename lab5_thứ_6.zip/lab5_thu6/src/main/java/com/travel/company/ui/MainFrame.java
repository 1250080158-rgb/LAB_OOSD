package com.travel.company.ui;

import com.travel.company.util.UiUtil;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Priority;
import javafx.stage.Stage;

public class MainFrame extends Application {

    private Stage primaryStage;

    @Override
    public void start(Stage primaryStage) {
        this.primaryStage = primaryStage;
        primaryStage.setTitle("Quản lý công ty du lịch");
        primaryStage.setMinWidth(1080);
        primaryStage.setMinHeight(560);

        GridPane root = new GridPane();
        root.setPadding(new Insets(20));
        root.setHgap(20);
        root.setVgap(20);
        root.setStyle("-fx-background-color: #EEEEEE;");

        Label title = new Label("HỆ THỐNG QUẢN LÝ CÔNG TY DU LỊCH VĂN HÓA VIỆT TP.HCM");
        title.setStyle("-fx-font-size: 36px; -fx-font-weight: bold; -fx-font-family: 'Times New Roman'; -fx-text-fill: #1F3864;");
        GridPane.setHgrow(title, Priority.ALWAYS);
        GridPane.setColumnSpan(title, 3);
        GridPane.setMargin(title, new Insets(16, 20, 16, 20));

        root.add(title, 0, 0);

        Button btnDanhMuc = createButton("Danh mục");
        btnDanhMuc.setOnAction(e -> openDanhMuc());
        root.add(btnDanhMuc, 0, 1);

        Button btnQuanLyTour = createButton("Quản lý Tour");
        btnQuanLyTour.setOnAction(e -> openQuanLyTour());
        root.add(btnQuanLyTour, 1, 1);

        Button btnDangKyDoan = createButton("Đăng ký đoàn");
        btnDangKyDoan.setOnAction(e -> openDangKyDoan());
        root.add(btnDangKyDoan, 2, 1);

        Button btnDangKyChuyen = createButton("Đăng ký chuyến");
        btnDangKyChuyen.setOnAction(e -> openDangKyChuyen());
        root.add(btnDangKyChuyen, 0, 2);

        Button btnPhanCong = createButton("Phân công nhân viên");
        btnPhanCong.setOnAction(e -> openPhanCong());
        root.add(btnPhanCong, 1, 2);

        Button btnKhaoSat = createButton("Khảo sát khách hàng");
        btnKhaoSat.setOnAction(e -> openKhaoSat());
        root.add(btnKhaoSat, 2, 2);

        Button btnThongKe = createButton("Thống kê");
        btnThongKe.setOnAction(e -> openThongKe());
        root.add(btnThongKe, 0, 3);

        Button btnThoat = createButton("Thoát");
        btnThoat.setOnAction(e -> handleThoat());
        root.add(btnThoat, 1, 3);

        Scene scene = new Scene(root, 1160, 640);
        primaryStage.setScene(scene);
        primaryStage.centerOnScreen();
        primaryStage.show();
    }

    private Button createButton(String text) {
        Button button = new Button(text);
        button.setStyle("-fx-font-size: 20px; -fx-font-family: 'Segoe UI'; -fx-pref-width: 310px; -fx-pref-height: 76px;");
        return button;
    }

    private void openDanhMuc() {
        DanhMucFrame danhMucFrame = new DanhMucFrame();
        danhMucFrame.show();
    }

    private void openQuanLyTour() {
        QuanLyTourFrame quanLyTourFrame = new QuanLyTourFrame();
        quanLyTourFrame.show();
    }

    private void openDangKyDoan() {
        DangKyDoanFrame dangKyDoanFrame = new DangKyDoanFrame();
        dangKyDoanFrame.show();
    }

    private void openDangKyChuyen() {
        DangKyChuyenFrame dangKyChuyenFrame = new DangKyChuyenFrame();
        dangKyChuyenFrame.show();
    }

    private void openPhanCong() {
        PhanCongFrame phanCongFrame = new PhanCongFrame();
        phanCongFrame.show();
    }

    private void openKhaoSat() {
        KhaoSatFrame khaoSatFrame = new KhaoSatFrame();
        khaoSatFrame.show();
    }

    private void openThongKe() {
        ThongKeFrame thongKeFrame = new ThongKeFrame();
        thongKeFrame.show();
    }

    private void handleThoat() {
        if (confirmExit()) {
            primaryStage.close();
            System.exit(0);
        }
    }

    private boolean confirmExit() {
        return UiUtil.confirm("Bạn có chắc muốn thoát chương trình?");
    }

    public static void main(String[] args) {
        launch(args);
    }
}
