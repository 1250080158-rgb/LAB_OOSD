package com.travel.company.model;

import java.io.Serializable;
import java.time.LocalDate;

public class DangKyChuyen implements Serializable {
    private String maPhieuChuyen;
    private String maKhachHang;
    private String maChuyen;
    private LocalDate ngayDangKy;
    private String diemBanVe;
    private String diaDiemDon;
    private double thanhTien;
    private String trangThai; // "Da thanh toan", "Chua thanh toan", "Da huy"

    public DangKyChuyen() {
        this.trangThai = "Chưa thanh toán";
    }

    public DangKyChuyen(String maPhieuChuyen, String maKhachHang, String maChuyen, LocalDate ngayDangKy, double thanhTien) {
        this();
        this.maPhieuChuyen = maPhieuChuyen;
        this.maKhachHang = maKhachHang;
        this.maChuyen = maChuyen;
        this.ngayDangKy = ngayDangKy;
        this.thanhTien = thanhTien;
    }

    public String getMaPhieuChuyen() {
        return maPhieuChuyen;
    }

    public void setMaPhieuChuyen(String maPhieuChuyen) {
        this.maPhieuChuyen = maPhieuChuyen;
    }

    public String getMaKhachHang() {
        return maKhachHang;
    }

    public void setMaKhachHang(String maKhachHang) {
        this.maKhachHang = maKhachHang;
    }

    public String getMaChuyen() {
        return maChuyen;
    }

    public void setMaChuyen(String maChuyen) {
        this.maChuyen = maChuyen;
    }

    public LocalDate getNgayDangKy() {
        return ngayDangKy;
    }

    public void setNgayDangKy(LocalDate ngayDangKy) {
        this.ngayDangKy = ngayDangKy;
    }

    public String getDiemBanVe() {
        return diemBanVe;
    }

    public void setDiemBanVe(String diemBanVe) {
        this.diemBanVe = diemBanVe;
    }

    public String getDiaDiemDon() {
        return diaDiemDon;
    }

    public void setDiaDiemDon(String diaDiemDon) {
        this.diaDiemDon = diaDiemDon;
    }

    public double getThanhTien() {
        return thanhTien;
    }

    public void setThanhTien(double thanhTien) {
        this.thanhTien = thanhTien;
    }

    public String getTrangThai() {
        return trangThai;
    }

    public void setTrangThai(String trangThai) {
        this.trangThai = trangThai;
    }

    @Override
    public String toString() {
        return maPhieuChuyen + " - " + maKhachHang;
    }
}
