package com.travel.company.data;

import com.travel.company.model.DangKyChuyen;

import java.sql.Date;
import java.sql.SQLException;
import java.util.List;

public class DangKyChuyenDao {

    private static final RowMapper<DangKyChuyen> MAPPER = rs -> {
        DangKyChuyen d = new DangKyChuyen();
        d.setMaPhieuChuyen(rs.getString("MaPhieuChuyen"));
        d.setMaKhachHang(rs.getString("MaKhachHang"));
        d.setMaChuyen(rs.getString("MaChuyen"));
        java.sql.Date ngayDangKy = rs.getDate("NgayDangKy");
        if (ngayDangKy != null) {
            d.setNgayDangKy(ngayDangKy.toLocalDate());
        }
        d.setDiemBanVe(rs.getString("DiemBanVe"));
        d.setDiaDiemDon(rs.getString("DiaDiemDon"));
        d.setThanhTien(rs.getDouble("ThanhTien"));
        d.setTrangThai(rs.getString("TrangThai"));
        return d;
    };

    public List<DangKyChuyen> findAll() throws SQLException {
        return JdbcUtil.query("SELECT * FROM DANG_KY_CHUYEN ORDER BY MaPhieuChuyen", MAPPER);
    }

    public DangKyChuyen findById(String maPhieuChuyen) throws SQLException {
        return JdbcUtil.queryOne("SELECT * FROM DANG_KY_CHUYEN WHERE MaPhieuChuyen = ?", MAPPER, maPhieuChuyen);
    }

    public void insert(DangKyChuyen d) throws SQLException {
        JdbcUtil.update("INSERT INTO DANG_KY_CHUYEN (MaPhieuChuyen, MaKhachHang, MaChuyen, NgayDangKy, DiemBanVe, DiaDiemDon, ThanhTien, TrangThai) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                d.getMaPhieuChuyen(), d.getMaKhachHang(), d.getMaChuyen(),
                Date.valueOf(d.getNgayDangKy()), d.getDiemBanVe(), d.getDiaDiemDon(),
                d.getThanhTien(), d.getTrangThai());
    }

    public void update(DangKyChuyen d) throws SQLException {
        JdbcUtil.update("UPDATE DANG_KY_CHUYEN SET MaKhachHang = ?, MaChuyen = ?, NgayDangKy = ?, DiemBanVe = ?, DiaDiemDon = ?, ThanhTien = ?, TrangThai = ? WHERE MaPhieuChuyen = ?",
                d.getMaKhachHang(), d.getMaChuyen(), Date.valueOf(d.getNgayDangKy()),
                d.getDiemBanVe(), d.getDiaDiemDon(), d.getThanhTien(), d.getTrangThai(), d.getMaPhieuChuyen());
    }

    public void updateTrangThai(String maPhieuChuyen, String trangThai) throws SQLException {
        JdbcUtil.update("UPDATE DANG_KY_CHUYEN SET TrangThai = ? WHERE MaPhieuChuyen = ?", trangThai, maPhieuChuyen);
    }

    public void delete(String maPhieuChuyen) throws SQLException {
        JdbcUtil.update("DELETE FROM DANG_KY_CHUYEN WHERE MaPhieuChuyen = ?", maPhieuChuyen);
    }

    public String nextId() throws SQLException {
        return JdbcUtil.nextId("DANG_KY_CHUYEN", "MaPhieuChuyen", "PC", 3);
    }
}
