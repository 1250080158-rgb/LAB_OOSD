package com.travel.company.ui;

import com.travel.company.model.DangKyDoan;
import com.travel.company.model.Tour;
import com.travel.company.service.DangKyDoanService;
import com.travel.company.service.TourService;
import com.travel.company.util.UiUtil;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

public class DangKyDoanFrame {
    private Stage stage;

    private final DangKyDoanService dangKyDoanService = new DangKyDoanService();
    private final TourService tourService = new TourService();
    private ObservableList<DangKyDoan> dangKyDoanList;

    public DangKyDoanFrame() {
        stage = new Stage();
        stage.setTitle("Đăng ký đoàn");

        VBox root = new VBox(10);
        root.setPadding(new Insets(10));

        Label label = new Label("Đăng ký đoàn (Khách > 12 người)");
        label.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;");

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(10));

        TextField txtMaPhieu = new TextField();
        txtMaPhieu.setPromptText("Tự động nếu để trống");
        grid.add(new Label("Mã phiếu:"), 0, 0);
        grid.add(txtMaPhieu, 1, 0);

        TextField txtTenCoQuan = new TextField();
        txtTenCoQuan.setPromptText("Tên cơ quan/đại diện");
        grid.add(new Label("Tên cơ quan:"), 0, 1);
        grid.add(txtTenCoQuan, 1, 1);

        TextField txtDiaChi = new TextField();
        txtDiaChi.setPromptText("Địa chỉ cơ quan");
        grid.add(new Label("Địa chỉ:"), 0, 2);
        grid.add(txtDiaChi, 1, 2);

        TextField txtDienThoai = new TextField();
        txtDienThoai.setPromptText("Điện thoại cơ quan");
        grid.add(new Label("Điện thoại:"), 0, 3);
        grid.add(txtDienThoai, 1, 3);

        TextField txtNguoiDaiDien = new TextField();
        txtNguoiDaiDien.setPromptText("Người đại diện");
        grid.add(new Label("Người đại diện:"), 0, 4);
        grid.add(txtNguoiDaiDien, 1, 4);

        TextField txtSoNguoi = new TextField();
        txtSoNguoi.setPromptText("Số người đi (>12)");
        grid.add(new Label("Số người:"), 0, 5);
        grid.add(txtSoNguoi, 1, 5);

        CheckBox chkBaoHiem = new CheckBox("Mua bảo hiểm");
        grid.add(chkBaoHiem, 0, 6);
        grid.add(new Label("(kèm danh sách người đi, mỗi dòng 1 người)"), 1, 6);

        TextArea txtDanhSach = new TextArea();
        txtDanhSach.setPromptText("Danh sách người đi (nếu mua bảo hiểm)");
        txtDanhSach.setPrefRowCount(3);
        grid.add(new Label("Danh sách:"), 0, 7);
        grid.add(txtDanhSach, 1, 7);

        TextField txtDiaDiemDon = new TextField();
        txtDiaDiemDon.setPromptText("Địa điểm đón theo yêu cầu");
        grid.add(new Label("Địa điểm đón:"), 0, 8);
        grid.add(txtDiaDiemDon, 1, 8);

        TextField txtTienCoc = new TextField();
        txtTienCoc.setPromptText("Tiền cọc");
        grid.add(new Label("Tiền cọc:"), 0, 9);
        grid.add(txtTienCoc, 1, 9);

        ComboBox<Tour> comboTour = new ComboBox<>();
        ObservableList<Tour> tourList = FXCollections.observableArrayList(tourService.findAll());
        comboTour.setItems(tourList);
        comboTour.setPromptText("Chọn Tour");
        grid.add(new Label("Tour:"), 0, 10);
        grid.add(comboTour, 1, 10);

        DatePicker datePicker = new DatePicker();
        datePicker.setPromptText("Ngày đi (chọn ngày bất kỳ)");
        grid.add(new Label("Ngày đi:"), 0, 11);
        grid.add(datePicker, 1, 11);

        HBox buttonBox = new HBox(10);
        Button btnDangKy = new Button("Đăng ký");
        Button btnXoaForm = new Button("Xóa form");

        btnDangKy.setOnAction(e -> {
            try {
                String maPhieu = txtMaPhieu.getText().trim();
                if (maPhieu.isEmpty()) {
                    maPhieu = dangKyDoanService.nextId();
                }

                String tenCoQuan = txtTenCoQuan.getText().trim();
                String diaChi = txtDiaChi.getText().trim();
                String dienThoai = txtDienThoai.getText().trim();
                String nguoiDaiDien = txtNguoiDaiDien.getText().trim();
                int soNguoi = Integer.parseInt(txtSoNguoi.getText().trim());
                boolean muaBaoHiem = chkBaoHiem.isSelected();
                String diaDiemDon = txtDiaDiemDon.getText().trim();
                double tienCoc = txtTienCoc.getText().trim().isEmpty()
                        ? 0 : Double.parseDouble(txtTienCoc.getText().trim());
                Tour tour = comboTour.getValue();
                LocalDate ngayDi = datePicker.getValue();

                DangKyDoan doan = new DangKyDoan();
                doan.setMaPhieuDoan(maPhieu);
                doan.setTenCoQuan(tenCoQuan);
                doan.setDiaChiCoQuan(diaChi);
                doan.setDienThoaiCoQuan(dienThoai);
                doan.setNguoiDaiDien(nguoiDaiDien);
                doan.setSoNguoiDi(soNguoi);
                doan.setMuaBaoHiem(muaBaoHiem);
                doan.setDiaDiemDon(diaDiemDon);
                doan.setTienCoc(tienCoc);
                doan.setMaTour(tour != null ? tour.getMaTour() : null);
                doan.setNgayDi(ngayDi);

                if (muaBaoHiem) {
                    List<String> ds = Arrays.asList(txtDanhSach.getText().split("\\r?\\n"));
                    for (String ten : ds) {
                        if (!ten.trim().isEmpty()) {
                            doan.getDanhSachNguoiDi().add(ten.trim());
                        }
                    }
                }

                dangKyDoanService.dangKyDoan(doan);
                dangKyDoanList.setAll(dangKyDoanService.findAll());
                UiUtil.alert("Thông báo", "Đăng ký đoàn thành công! Mã phiếu: " + maPhieu);
                xoaForm(txtMaPhieu, txtTenCoQuan, txtDiaChi, txtDienThoai, txtNguoiDaiDien, txtSoNguoi,
                        chkBaoHiem, txtDanhSach, txtDiaDiemDon, txtTienCoc, comboTour, datePicker);
            } catch (NumberFormatException ex) {
                UiUtil.error("Vui lòng nhập đúng định dạng số!");
            } catch (IllegalArgumentException ex) {
                UiUtil.error(ex.getMessage());
            } catch (RuntimeException ex) {
                UiUtil.error(ex.getMessage());
            }
        });

        btnXoaForm.setOnAction(e -> xoaForm(txtMaPhieu, txtTenCoQuan, txtDiaChi, txtDienThoai,
                txtNguoiDaiDien, txtSoNguoi, chkBaoHiem, txtDanhSach, txtDiaDiemDon, txtTienCoc, comboTour, datePicker));

        buttonBox.getChildren().addAll(btnDangKy, btnXoaForm);

        Label lblList = new Label("Danh sách đoàn đã đăng ký:");
        lblList.setStyle("-fx-font-weight: bold;");

        TableView<DangKyDoan> tableView = new TableView<>();
        dangKyDoanList = FXCollections.observableArrayList(dangKyDoanService.findAll());
        tableView.setItems(dangKyDoanList);

        TableColumn<DangKyDoan, String> colMa = new TableColumn<>("Mã phiếu");
        colMa.setCellValueFactory(new PropertyValueFactory<>("maPhieuDoan"));
        colMa.setPrefWidth(100);

        TableColumn<DangKyDoan, String> colCoQuan = new TableColumn<>("Cơ quan");
        colCoQuan.setCellValueFactory(new PropertyValueFactory<>("tenCoQuan"));
        colCoQuan.setPrefWidth(200);

        TableColumn<DangKyDoan, Integer> colSoNguoi = new TableColumn<>("Số người");
        colSoNguoi.setCellValueFactory(new PropertyValueFactory<>("soNguoiDi"));
        colSoNguoi.setPrefWidth(80);

        TableColumn<DangKyDoan, String> colTour = new TableColumn<>("Tour");
        colTour.setCellValueFactory(new PropertyValueFactory<>("maTour"));
        colTour.setPrefWidth(100);

        TableColumn<DangKyDoan, LocalDate> colNgayDi = new TableColumn<>("Ngày đi");
        colNgayDi.setCellValueFactory(new PropertyValueFactory<>("ngayDi"));
        colNgayDi.setPrefWidth(120);

        TableColumn<DangKyDoan, String> colTrangThai = new TableColumn<>("Trạng thái");
        colTrangThai.setCellValueFactory(new PropertyValueFactory<>("trangThai"));
        colTrangThai.setPrefWidth(120);

        tableView.getColumns().addAll(colMa, colCoQuan, colSoNguoi, colTour, colNgayDi, colTrangThai);

        HBox listButtonBox = new HBox(10);
        Button btnSua = new Button("Sửa");
        Button btnXoa = new Button("Xóa");
        Button btnHoanThanh = new Button("Hoàn thành tour");

        btnSua.setOnAction(e -> suaDoan(tableView));
        btnXoa.setOnAction(e -> xoaDoan(tableView));
        btnHoanThanh.setOnAction(e -> hoanThanhDoan(tableView));

        listButtonBox.getChildren().addAll(btnSua, btnXoa, btnHoanThanh);

        Button btnBack = new Button("Quay lại");
        btnBack.setStyle("-fx-font-size: 14px; -fx-font-family: 'Segoe UI';");
        btnBack.setOnAction(e -> stage.close());

        root.getChildren().addAll(label, grid, buttonBox, lblList, tableView, listButtonBox, btnBack);

        Scene scene = new Scene(root, 900, 700);
        stage.setScene(scene);
    }

    private void xoaForm(TextField txtMaPhieu, TextField txtTenCoQuan, TextField txtDiaChi,
                         TextField txtDienThoai, TextField txtNguoiDaiDien, TextField txtSoNguoi,
                         CheckBox chkBaoHiem, TextArea txtDanhSach, TextField txtDiaDiemDon,
                         TextField txtTienCoc, ComboBox<Tour> comboTour, DatePicker datePicker) {
        txtMaPhieu.clear();
        txtTenCoQuan.clear();
        txtDiaChi.clear();
        txtDienThoai.clear();
        txtNguoiDaiDien.clear();
        txtSoNguoi.clear();
        chkBaoHiem.setSelected(false);
        txtDanhSach.clear();
        txtDiaDiemDon.clear();
        txtTienCoc.clear();
        comboTour.setValue(null);
        datePicker.setValue(null);
    }

    private void suaDoan(TableView<DangKyDoan> tableView) {
        DangKyDoan selected = tableView.getSelectionModel().getSelectedItem();
        if (selected == null) {
            UiUtil.error("Vui lòng chọn đoàn để sửa!");
            return;
        }
        ChoiceDialog<String> dialog = new ChoiceDialog<>(selected.getTrangThai(),
                Arrays.asList("Chưa đi", "Đang đi", "Đã kết thúc", "Đã hủy"));
        dialog.setTitle("Sửa trạng thái đoàn");
        dialog.setHeaderText("Sửa trạng thái");
        dialog.setContentText("Trạng thái:");
        dialog.showAndWait().ifPresent(trangThai -> {
            try {
                dangKyDoanService.capNhatTrangThai(selected.getMaPhieuDoan(), trangThai);
                selected.setTrangThai(trangThai);
                dangKyDoanList.setAll(dangKyDoanService.findAll());
                UiUtil.alert("Thông báo", "Đã sửa trạng thái thành công!");
            } catch (RuntimeException ex) {
                UiUtil.error(ex.getMessage());
            }
        });
    }

    private void xoaDoan(TableView<DangKyDoan> tableView) {
        DangKyDoan selected = tableView.getSelectionModel().getSelectedItem();
        if (selected == null) {
            UiUtil.error("Vui lòng chọn đoàn để xóa!");
            return;
        }
        if (UiUtil.confirm("Bạn có chắc muốn xóa đoàn này? Lưu ý: sẽ mất tiền cọc!")) {
            try {
                dangKyDoanService.xoaDoan(selected.getMaPhieuDoan());
                dangKyDoanList.setAll(dangKyDoanService.findAll());
                UiUtil.alert("Thông báo", "Đã xóa đoàn thành công!");
            } catch (RuntimeException ex) {
                UiUtil.error(ex.getMessage());
            }
        }
    }

    private void hoanThanhDoan(TableView<DangKyDoan> tableView) {
        DangKyDoan selected = tableView.getSelectionModel().getSelectedItem();
        if (selected == null) {
            UiUtil.error("Vui lòng chọn đoàn để hoàn thành!");
            return;
        }
        if (UiUtil.confirm("Bạn có chắc muốn đánh dấu đoàn này đã hoàn thành?")) {
            try {
                dangKyDoanService.capNhatTrangThai(selected.getMaPhieuDoan(), "Đã kết thúc");
                selected.setTrangThai("Đã kết thúc");
                dangKyDoanList.setAll(dangKyDoanService.findAll());
                UiUtil.alert("Thông báo", "Đã đánh dấu hoàn thành tour!");
            } catch (RuntimeException ex) {
                UiUtil.error(ex.getMessage());
            }
        }
    }

    public void show() {
        stage.show();
    }
}
