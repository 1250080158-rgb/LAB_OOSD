package com.travel.company.ui;

import com.travel.company.service.ThongKeService;
import com.travel.company.util.UiUtil;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.util.List;
import java.util.Map;

public class ThongKeFrame {
    private Stage stage;

    private final ThongKeService thongKeService = new ThongKeService();

    public ThongKeFrame() {
        stage = new Stage();
        stage.setTitle("Thống kê");

        VBox root = new VBox(10);
        root.setPadding(new Insets(10));

        Label label = new Label("Thống kê");
        label.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;");

        VBox buttonBox = new VBox(10);
        buttonBox.setPadding(new Insets(10));

        Button btnDoanhThuTour = new Button("Doanh thu theo Tour");
        Button btnThamGiaTour = new Button("Thống kê tham gia Tour");
        Button btnKhachHang = new Button("Thống kê Khách hàng");
        Button btnNhanVien = new Button("Hiệu suất Nhân viên");
        Button btnDiemThamQuan = new Button("Độ phổ biến Điểm tham quan");
        Button btnTongQuan = new Button("Tổng quan");

        btnDoanhThuTour.setOnAction(e -> hienThi(thongKeDoanhThuTour()));
        btnThamGiaTour.setOnAction(e -> hienThi(thongKeThamGiaTour()));
        btnKhachHang.setOnAction(e -> hienThi(thongKeKhachHang()));
        btnNhanVien.setOnAction(e -> hienThi(thongKeNhanVien()));
        btnDiemThamQuan.setOnAction(e -> hienThi(thongKeDiemThamQuan()));
        btnTongQuan.setOnAction(e -> hienThi(thongKeTongQuan()));

        buttonBox.getChildren().addAll(btnDoanhThuTour, btnThamGiaTour, btnKhachHang,
                btnNhanVien, btnDiemThamQuan, btnTongQuan);

        Button btnBack = new Button("Quay lại");
        btnBack.setStyle("-fx-font-size: 14px; -fx-font-family: 'Segoe UI';");
        btnBack.setOnAction(e -> stage.close());

        root.getChildren().addAll(label, buttonBox, btnBack);

        Scene scene = new Scene(root, 400, 350);
        stage.setScene(scene);
    }

    private void hienThi(String noiDung) {
        TextArea textArea = new TextArea(noiDung);
        textArea.setEditable(false);
        textArea.setWrapText(true);
        textArea.setPrefSize(560, 420);

        VBox root = new VBox(10);
        root.setPadding(new Insets(10));
        root.getChildren().addAll(new Label("Kết quả thống kê"), textArea);

        Stage stage = new Stage();
        stage.setTitle("Thống kê");
        stage.setScene(new Scene(root));
        stage.show();
    }

    private String thongKeDoanhThuTour() {
        StringBuilder sb = new StringBuilder("DOANH THU THEO TOUR\n");
        sb.append("===================\n\n");

        Map<String, Double> ketQua = thongKeService.doanhThuTour();
        double tongDoanhThu = 0;
        for (Map.Entry<String, Double> entry : ketQua.entrySet()) {
            sb.append(String.format("%s: %s VNĐ\n", entry.getKey(), String.format("%,.0f", entry.getValue())));
            tongDoanhThu += entry.getValue();
        }
        sb.append(String.format("\nTỔNG DOANH THU: %s VNĐ", String.format("%,.0f", tongDoanhThu)));
        return sb.toString();
    }

    private String thongKeThamGiaTour() {
        StringBuilder sb = new StringBuilder("THỐNG KÊ THAM GIA TOUR\n");
        sb.append("========================\n\n");

        Map<String, Integer> ketQua = thongKeService.thamGiaTour();
        int tongKhach = 0;
        for (Map.Entry<String, Integer> entry : ketQua.entrySet()) {
            sb.append(String.format("%s: %d khách\n", entry.getKey(), entry.getValue()));
            tongKhach += entry.getValue();
        }
        sb.append(String.format("\nTỔNG KHÁCH: %d", tongKhach));
        return sb.toString();
    }

    private String thongKeKhachHang() {
        StringBuilder sb = new StringBuilder("THỐNG KÊ KHÁCH HÀNG\n");
        sb.append("=====================\n\n");

        int[] ketQua = thongKeService.thongKeKhachHang();
        int tongKhachHang = ketQua[0];
        int khachDaDiTour = ketQua[1];
        int khachChuaDiTour = ketQua[2];

        sb.append(String.format("Tổng khách hàng: %d\n", tongKhachHang));
        sb.append(String.format("Khách đã đi tour: %d\n", khachDaDiTour));
        sb.append(String.format("Khách chưa đi tour: %d\n", khachChuaDiTour));
        if (tongKhachHang > 0) {
            sb.append(String.format("Tỷ lệ tham gia: %.1f%%", (double) khachDaDiTour / tongKhachHang * 100));
        }
        return sb.toString();
    }

    private String thongKeNhanVien() {
        StringBuilder sb = new StringBuilder("HIỆU SUẤT NHÂN VIÊN\n");
        sb.append("====================\n\n");

        List<Object[]> ketQua = thongKeService.hieuSuatNhanVien();
        for (Object[] row : ketQua) {
            String maNV = (String) row[0];
            String hoTen = (String) row[1];
            double luongCanBan = (double) row[2];
            int soTour = (int) row[3];
            double luongTour = (double) row[4];
            double tongLuong = luongCanBan + luongTour;

            sb.append(String.format("%s (%s):\n", hoTen, maNV));
            sb.append(String.format("  - Số tour đã dẫn: %d\n", soTour));
            sb.append(String.format("  - Lương căn bản: %s VNĐ\n", String.format("%,.0f", luongCanBan)));
            sb.append(String.format("  - Lương theo tour: %s VNĐ\n", String.format("%,.0f", luongTour)));
            sb.append(String.format("  - Tổng lương: %s VNĐ\n\n", String.format("%,.0f", tongLuong)));
        }
        return sb.toString();
    }

    private String thongKeDiemThamQuan() {
        StringBuilder sb = new StringBuilder("ĐỘ PHỔ BIẾN ĐIỂM THAM QUAN\n");
        sb.append("===========================\n\n");

        List<Object[]> ketQua = thongKeService.doPhoBienDiemThamQuan();
        for (Object[] row : ketQua) {
            String tenDiem = (String) row[1];
            String diaDiem = (String) row[2];
            int soTour = (int) row[3];
            sb.append(String.format("%s (%s): %d tour\n", tenDiem, diaDiem, soTour));
        }
        return sb.toString();
    }

    private String thongKeTongQuan() {
        StringBuilder sb = new StringBuilder("TỔNG QUAN HỆ THỐNG\n");
        sb.append("==================\n\n");

        Map<String, Integer> ketQua = thongKeService.tongQuan();
        for (Map.Entry<String, Integer> entry : ketQua.entrySet()) {
            sb.append(String.format("Số %s: %d\n", entry.getKey(), entry.getValue()));
        }
        sb.append(String.format("\nĐiểm trung bình khảo sát: %.1f/5", thongKeService.diemTrungBinhKhaoSat()));
        return sb.toString();
    }

    public void show() {
        stage.show();
    }
}
