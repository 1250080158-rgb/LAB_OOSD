package com.travel.company.data;

import com.travel.company.model.DiemThamQuan;
import com.travel.company.model.NoiDungChan;
import com.travel.company.model.PhuongTien;
import com.travel.company.model.Tour;

import java.sql.SQLException;
import java.util.List;

public class TourDao {

    private static final RowMapper<Tour> MAPPER = rs -> new Tour(
            rs.getString("MaTour"),
            rs.getString("TenTour"),
            rs.getInt("SoNgay"),
            rs.getInt("SoDem"),
            rs.getDouble("DonGia"));

    private static final RowMapper<NoiDungChan> NDC_MAPPER = rs -> new NoiDungChan(
            rs.getString("MaNoiDungChan"),
            rs.getString("TenNoi"),
            rs.getString("DiaDiem"),
            rs.getBoolean("DoiPhuongTien"),
            rs.getBoolean("CoNaiAn"),
            rs.getBoolean("CoKhachSan"),
            rs.getInt("LoaiKhachSan"));

    private static final RowMapper<PhuongTien> PT_MAPPER = rs -> new PhuongTien(
            rs.getString("MaPhuongTien"),
            rs.getString("LoaiPhuongTien"),
            rs.getString("BienSo"),
            rs.getString("HangSanXuat"),
            rs.getInt("SoCho"));

    private static final RowMapper<DiemThamQuan> DTQ_MAPPER = rs -> new DiemThamQuan(
            rs.getString("MaDiem"),
            rs.getString("TenDiem"),
            rs.getString("DiaDiem"),
            rs.getString("NoiDung"),
            rs.getString("YNghia"));

    public List<Tour> findAll() throws SQLException {
        List<Tour> tours = JdbcUtil.query("SELECT * FROM TOUR ORDER BY MaTour", MAPPER);
        for (Tour tour : tours) {
            loadChiTiet(tour);
        }
        return tours;
    }

    public Tour findById(String maTour) throws SQLException {
        Tour tour = JdbcUtil.queryOne("SELECT * FROM TOUR WHERE MaTour = ?", MAPPER, maTour);
        if (tour != null) {
            loadChiTiet(tour);
        }
        return tour;
    }

    private void loadChiTiet(Tour tour) throws SQLException {
        tour.setNoiDungChans(JdbcUtil.query(
                "SELECT ndc.* FROM NOI_DUNG_CHAN ndc JOIN TOUR_NOI_DUNG_CHAN t ON t.MaNoiDungChan = ndc.MaNoiDungChan WHERE t.MaTour = ? ORDER BY t.ThuTu",
                NDC_MAPPER, tour.getMaTour()));
        tour.setPhuongTiens(JdbcUtil.query(
                "SELECT pt.* FROM PHUONG_TIEN pt JOIN TOUR_PHUONG_TIEN t ON t.MaPhuongTien = pt.MaPhuongTien WHERE t.MaTour = ? ORDER BY t.ThuTu",
                PT_MAPPER, tour.getMaTour()));
        tour.setDiemThamQuans(JdbcUtil.query(
                "SELECT dtq.* FROM DIEM_THAM_QUAN dtq JOIN TOUR_DIEM_THAM_QUAN t ON t.MaDiem = dtq.MaDiem WHERE t.MaTour = ? ORDER BY t.ThuTu",
                DTQ_MAPPER, tour.getMaTour()));
    }

    public void insert(Tour tour) throws SQLException {
        JdbcUtil.update("INSERT INTO TOUR (MaTour, TenTour, SoNgay, SoDem, DonGia) VALUES (?, ?, ?, ?, ?)",
                tour.getMaTour(), tour.getTenTour(), tour.getSoNgay(), tour.getSoDem(), tour.getDonGia());
    }

    public void update(Tour tour) throws SQLException {
        JdbcUtil.update("UPDATE TOUR SET TenTour = ?, SoNgay = ?, SoDem = ?, DonGia = ? WHERE MaTour = ?",
                tour.getTenTour(), tour.getSoNgay(), tour.getSoDem(), tour.getDonGia(), tour.getMaTour());
    }

    public void delete(String maTour) throws SQLException {
        JdbcUtil.update("DELETE FROM TOUR WHERE MaTour = ?", maTour);
    }

    public String nextId() throws SQLException {
        return JdbcUtil.nextId("TOUR", "MaTour", "T", 3);
    }

    public void addNoiDungChan(String maTour, String maNoiDungChan, int thuTu) throws SQLException {
        JdbcUtil.update("INSERT INTO TOUR_NOI_DUNG_CHAN (MaTour, MaNoiDungChan, ThuTu) VALUES (?, ?, ?) ON CONFLICT DO NOTHING",
                maTour, maNoiDungChan, thuTu);
    }

    public void removeNoiDungChan(String maTour, String maNoiDungChan) throws SQLException {
        JdbcUtil.update("DELETE FROM TOUR_NOI_DUNG_CHAN WHERE MaTour = ? AND MaNoiDungChan = ?", maTour, maNoiDungChan);
    }

    public void addPhuongTien(String maTour, String maPhuongTien, int thuTu) throws SQLException {
        JdbcUtil.update("INSERT INTO TOUR_PHUONG_TIEN (MaTour, MaPhuongTien, ThuTu) VALUES (?, ?, ?) ON CONFLICT DO NOTHING",
                maTour, maPhuongTien, thuTu);
    }

    public void removePhuongTien(String maTour, String maPhuongTien) throws SQLException {
        JdbcUtil.update("DELETE FROM TOUR_PHUONG_TIEN WHERE MaTour = ? AND MaPhuongTien = ?", maTour, maPhuongTien);
    }

    public void addDiemThamQuan(String maTour, String maDiem, int thuTu) throws SQLException {
        JdbcUtil.update("INSERT INTO TOUR_DIEM_THAM_QUAN (MaTour, MaDiem, ThuTu) VALUES (?, ?, ?) ON CONFLICT DO NOTHING",
                maTour, maDiem, thuTu);
    }

    public void removeDiemThamQuan(String maTour, String maDiem) throws SQLException {
        JdbcUtil.update("DELETE FROM TOUR_DIEM_THAM_QUAN WHERE MaTour = ? AND MaDiem = ?", maTour, maDiem);
    }
}
