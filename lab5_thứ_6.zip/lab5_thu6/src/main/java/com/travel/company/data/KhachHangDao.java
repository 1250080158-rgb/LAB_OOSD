package com.travel.company.data;

import com.travel.company.model.KhachHang;

import java.sql.SQLException;
import java.util.List;

public class KhachHangDao {

    private static final RowMapper<KhachHang> MAPPER = rs -> new KhachHang(
            rs.getString("MaKhachHang"),
            rs.getString("HoTen"),
            rs.getString("CMND"),
            rs.getString("SoDienThoai"),
            rs.getString("DiaChi"),
            rs.getString("Email"));

    public List<KhachHang> findAll() throws SQLException {
        return JdbcUtil.query("SELECT * FROM KHACH_HANG ORDER BY MaKhachHang", MAPPER);
    }

    public KhachHang findById(String maKhachHang) throws SQLException {
        return JdbcUtil.queryOne("SELECT * FROM KHACH_HANG WHERE MaKhachHang = ?", MAPPER, maKhachHang);
    }

    public void insert(KhachHang kh) throws SQLException {
        JdbcUtil.update("INSERT INTO KHACH_HANG (MaKhachHang, HoTen, CMND, SoDienThoai, DiaChi, Email) VALUES (?, ?, ?, ?, ?, ?)",
                kh.getMaKhachHang(), kh.getHoTen(), kh.getCmnd(), kh.getSoDienThoai(), kh.getDiaChi(), kh.getEmail());
    }

    public void update(KhachHang kh) throws SQLException {
        JdbcUtil.update("UPDATE KHACH_HANG SET HoTen = ?, CMND = ?, SoDienThoai = ?, DiaChi = ?, Email = ? WHERE MaKhachHang = ?",
                kh.getHoTen(), kh.getCmnd(), kh.getSoDienThoai(), kh.getDiaChi(), kh.getEmail(), kh.getMaKhachHang());
    }

    public void delete(String maKhachHang) throws SQLException {
        JdbcUtil.update("DELETE FROM KHACH_HANG WHERE MaKhachHang = ?", maKhachHang);
    }

    public String nextId() throws SQLException {
        return JdbcUtil.nextId("KHACH_HANG", "MaKhachHang", "KH", 3);
    }
}
