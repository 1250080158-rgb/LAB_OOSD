package com.travel.company.data;

import com.travel.company.model.DangKyDoan;

import java.sql.Date;
import java.sql.SQLException;
import java.util.List;

public class DangKyDoanDao {

    private static final RowMapper<DangKyDoan> MAPPER = rs -> {
        DangKyDoan d = new DangKyDoan();
        d.setMaPhieuDoan(rs.getString("MaPhieuDoan"));
        d.setTenCoQuan(rs.getString("TenCoQuan"));
        d.setDiaChiCoQuan(rs.getString("DiaChiCoQuan"));
        d.setDienThoaiCoQuan(rs.getString("DienThoaiCoQuan"));
        d.setNguoiDaiDien(rs.getString("NguoiDaiDien"));
        d.setSoNguoiDi(rs.getInt("SoNguoiDi"));
        d.setMuaBaoHiem(rs.getBoolean("MuaBaoHiem"));
        d.setDiaDiemDon(rs.getString("DiaDiemDon"));
        d.setTienCoc(rs.getDouble("TienCoc"));
        d.setMaTour(rs.getString("MaTour"));
        java.sql.Date ngayDi = rs.getDate("NgayDi");
        if (ngayDi != null) {
            d.setNgayDi(ngayDi.toLocalDate());
        }
        d.setTrangThai(rs.getString("TrangThai"));
        return d;
    };

    public List<DangKyDoan> findAll() throws SQLException {
        List<DangKyDoan> list = JdbcUtil.query("SELECT * FROM DANG_KY_DOAN ORDER BY MaPhieuDoan", MAPPER);
        for (DangKyDoan d : list) {
            d.setDanhSachNguoiDi(findDanhSachNguoiDi(d.getMaPhieuDoan()));
        }
        return list;
    }

    public DangKyDoan findById(String maPhieuDoan) throws SQLException {
        DangKyDoan d = JdbcUtil.queryOne("SELECT * FROM DANG_KY_DOAN WHERE MaPhieuDoan = ?", MAPPER, maPhieuDoan);
        if (d != null) {
            d.setDanhSachNguoiDi(findDanhSachNguoiDi(d.getMaPhieuDoan()));
        }
        return d;
    }

    private List<String> findDanhSachNguoiDi(String maPhieuDoan) throws SQLException {
        return JdbcUtil.query("SELECT HoTen FROM DANH_SACH_NGUOI_DI WHERE MaPhieuDoan = ? ORDER BY HoTen",
                rs -> rs.getString("HoTen"), maPhieuDoan);
    }

    public void insert(DangKyDoan d) throws SQLException {
        JdbcUtil.update("INSERT INTO DANG_KY_DOAN (MaPhieuDoan, TenCoQuan, DiaChiCoQuan, DienThoaiCoQuan, NguoiDaiDien, SoNguoiDi, MuaBaoHiem, DiaDiemDon, TienCoc, MaTour, NgayDi, TrangThai) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                d.getMaPhieuDoan(), d.getTenCoQuan(), d.getDiaChiCoQuan(), d.getDienThoaiCoQuan(),
                d.getNguoiDaiDien(), d.getSoNguoiDi(), d.isMuaBaoHiem(), d.getDiaDiemDon(),
                d.getTienCoc(), d.getMaTour(), Date.valueOf(d.getNgayDi()), d.getTrangThai());
        for (String nguoi : d.getDanhSachNguoiDi()) {
            JdbcUtil.update("INSERT INTO DANH_SACH_NGUOI_DI (MaPhieuDoan, HoTen) VALUES (?, ?)", d.getMaPhieuDoan(), nguoi);
        }
    }

    public void update(DangKyDoan d) throws SQLException {
        JdbcUtil.update("UPDATE DANG_KY_DOAN SET TenCoQuan = ?, DiaChiCoQuan = ?, DienThoaiCoQuan = ?, NguoiDaiDien = ?, SoNguoiDi = ?, MuaBaoHiem = ?, DiaDiemDon = ?, TienCoc = ?, MaTour = ?, NgayDi = ?, TrangThai = ? WHERE MaPhieuDoan = ?",
                d.getTenCoQuan(), d.getDiaChiCoQuan(), d.getDienThoaiCoQuan(), d.getNguoiDaiDien(),
                d.getSoNguoiDi(), d.isMuaBaoHiem(), d.getDiaDiemDon(), d.getTienCoc(),
                d.getMaTour(), Date.valueOf(d.getNgayDi()), d.getTrangThai(), d.getMaPhieuDoan());
        JdbcUtil.update("DELETE FROM DANH_SACH_NGUOI_DI WHERE MaPhieuDoan = ?", d.getMaPhieuDoan());
        for (String nguoi : d.getDanhSachNguoiDi()) {
            JdbcUtil.update("INSERT INTO DANH_SACH_NGUOI_DI (MaPhieuDoan, HoTen) VALUES (?, ?)", d.getMaPhieuDoan(), nguoi);
        }
    }

    public void updateTrangThai(String maPhieuDoan, String trangThai) throws SQLException {
        JdbcUtil.update("UPDATE DANG_KY_DOAN SET TrangThai = ? WHERE MaPhieuDoan = ?", trangThai, maPhieuDoan);
    }

    public void delete(String maPhieuDoan) throws SQLException {
        JdbcUtil.update("DELETE FROM DANG_KY_DOAN WHERE MaPhieuDoan = ?", maPhieuDoan);
    }

    public String nextId() throws SQLException {
        return JdbcUtil.nextId("DANG_KY_DOAN", "MaPhieuDoan", "PD", 3);
    }
}
