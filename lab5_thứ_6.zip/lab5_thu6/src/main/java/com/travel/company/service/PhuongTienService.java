package com.travel.company.service;

import com.travel.company.data.PhuongTienDao;
import com.travel.company.model.PhuongTien;

import java.sql.SQLException;
import java.util.List;

public class PhuongTienService {

    private final PhuongTienDao dao = new PhuongTienDao();

    public List<PhuongTien> findAll() {
        try {
            return dao.findAll();
        } catch (SQLException e) {
            throw new RuntimeException("Lay danh sach phuong tien that bai: " + e.getMessage(), e);
        }
    }

    public PhuongTien findById(String maPhuongTien) {
        try {
            return dao.findById(maPhuongTien);
        } catch (SQLException e) {
            throw new RuntimeException("Lay phuong tien that bai: " + e.getMessage(), e);
        }
    }

    public String nextId() {
        try {
            return dao.nextId();
        } catch (SQLException e) {
            throw new RuntimeException("Sinh ma phuong tien that bai: " + e.getMessage(), e);
        }
    }

    public void themPhuongTien(PhuongTien pt) {
        validate(pt);
        try {
            if (dao.findById(pt.getMaPhuongTien()) != null) {
                throw new IllegalArgumentException("Ma phuong tien da ton tai!");
            }
            dao.insert(pt);
        } catch (SQLException e) {
            throw new RuntimeException("Them phuong tien that bai: " + e.getMessage(), e);
        }
    }

    public void suaPhuongTien(PhuongTien pt) {
        validate(pt);
        try {
            dao.update(pt);
        } catch (SQLException e) {
            throw new RuntimeException("Sua phuong tien that bai: " + e.getMessage(), e);
        }
    }

    public void xoaPhuongTien(String maPhuongTien) {
        try {
            dao.delete(maPhuongTien);
        } catch (SQLException e) {
            throw new RuntimeException("Xoa phuong tien that bai (co the con lien ket du lieu): " + e.getMessage(), e);
        }
    }

    private void validate(PhuongTien pt) {
        if (pt.getMaPhuongTien() == null || pt.getMaPhuongTien().trim().isEmpty()) {
            throw new IllegalArgumentException("Chua nhap ma phuong tien!");
        }
        if (pt.getLoaiPhuongTien() == null || pt.getLoaiPhuongTien().trim().isEmpty()) {
            throw new IllegalArgumentException("Chua nhap loai phuong tien!");
        }
        if (pt.getSoCho() <= 0) {
            throw new IllegalArgumentException("So cho phai lon hon 0!");
        }
    }
}
