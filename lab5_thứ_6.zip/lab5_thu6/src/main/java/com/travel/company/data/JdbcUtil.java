package com.travel.company.data;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class JdbcUtil {

    private JdbcUtil() {
    }

    public static PreparedStatement prepare(Connection conn, String sql, Object... params) throws SQLException {
        PreparedStatement ps = conn.prepareStatement(sql);
        for (int i = 0; i < params.length; i++) {
            ps.setObject(i + 1, params[i]);
        }
        return ps;
    }

    public static <T> List<T> query(String sql, RowMapper<T> mapper, Object... params) throws SQLException {
        Connection conn = DatabaseConnection.getConnection();
        try (PreparedStatement ps = prepare(conn, sql, params);
             ResultSet rs = ps.executeQuery()) {
            List<T> list = new ArrayList<>();
            while (rs.next()) {
                list.add(mapper.mapRow(rs));
            }
            return list;
        }
    }

    public static <T> T queryOne(String sql, RowMapper<T> mapper, Object... params) throws SQLException {
        List<T> list = query(sql, mapper, params);
        return list.isEmpty() ? null : list.get(0);
    }

    public static int update(String sql, Object... params) throws SQLException {
        Connection conn = DatabaseConnection.getConnection();
        try (PreparedStatement ps = prepare(conn, sql, params)) {
            return ps.executeUpdate();
        }
    }

    public static String nextId(String table, String column, String prefix, int digits) throws SQLException {
        String sql = "SELECT MAX(TRIM(" + column + ")) AS max_id FROM " + table + " WHERE TRIM(" + column + ") LIKE ?";
        String max = queryOne(sql, rs -> rs.getString("max_id"), prefix + "%");
        if (max == null) {
            return prefix + String.format("%0" + digits + "d", 1);
        }
        max = max.trim();
        try {
            int num = Integer.parseInt(max.substring(prefix.length()));
            return prefix + String.format("%0" + digits + "d", num + 1);
        } catch (NumberFormatException e) {
            return prefix + String.format("%0" + digits + "d", 1);
        }
    }
}
