package com.travel.company.data;

import com.travel.company.model.NoiDungChan;

import java.sql.SQLException;
import java.util.List;

public class NoiDungChanDao {

    private static final RowMapper<NoiDungChan> MAPPER = rs -> new NoiDungChan(
            rs.getString("MaNoiDungChan"),
            rs.getString("TenNoi"),
            rs.getString("DiaDiem"),
            rs.getBoolean("DoiPhuongTien"),
            rs.getBoolean("CoNaiAn"),
            rs.getBoolean("CoKhachSan"),
            rs.getInt("LoaiKhachSan"));

    public List<NoiDungChan> findAll() throws SQLException {
        return JdbcUtil.query("SELECT * FROM NOI_DUNG_CHAN ORDER BY MaNoiDungChan", MAPPER);
    }

    public NoiDungChan findById(String maNoiDungChan) throws SQLException {
        return JdbcUtil.queryOne("SELECT * FROM NOI_DUNG_CHAN WHERE MaNoiDungChan = ?", MAPPER, maNoiDungChan);
    }

    public void insert(NoiDungChan ndc) throws SQLException {
        JdbcUtil.update("INSERT INTO NOI_DUNG_CHAN (MaNoiDungChan, TenNoi, DiaDiem, DoiPhuongTien, CoNaiAn, CoKhachSan, LoaiKhachSan) VALUES (?, ?, ?, ?, ?, ?, ?)",
                ndc.getMaNoiDungChan(), ndc.getTenNoi(), ndc.getDiaDiem(),
                ndc.isDoiPhuongTien(), ndc.isCoNaiAn(), ndc.isCoKhachSan(), ndc.getLoaiKhachSan());
    }

    public void update(NoiDungChan ndc) throws SQLException {
        JdbcUtil.update("UPDATE NOI_DUNG_CHAN SET TenNoi = ?, DiaDiem = ?, DoiPhuongTien = ?, CoNaiAn = ?, CoKhachSan = ?, LoaiKhachSan = ? WHERE MaNoiDungChan = ?",
                ndc.getTenNoi(), ndc.getDiaDiem(), ndc.isDoiPhuongTien(), ndc.isCoNaiAn(), ndc.isCoKhachSan(), ndc.getLoaiKhachSan(), ndc.getMaNoiDungChan());
    }

    public void delete(String maNoiDungChan) throws SQLException {
        JdbcUtil.update("DELETE FROM NOI_DUNG_CHAN WHERE MaNoiDungChan = ?", maNoiDungChan);
    }

    public String nextId() throws SQLException {
        return JdbcUtil.nextId("NOI_DUNG_CHAN", "MaNoiDungChan", "NDC", 3);
    }
}
