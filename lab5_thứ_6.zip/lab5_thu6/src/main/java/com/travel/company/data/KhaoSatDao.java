package com.travel.company.data;

import com.travel.company.model.KhaoSat;

import java.sql.Date;
import java.sql.SQLException;
import java.util.List;

public class KhaoSatDao {

    private static final RowMapper<KhaoSat> MAPPER = rs -> {
        KhaoSat ks = new KhaoSat();
        ks.setMaKhaoSat(rs.getString("MaKhaoSat"));
        ks.setMaDoanHoacChuyen(rs.getString("MaDoanHoacChuyen"));
        ks.setLoaiKhaoSat(rs.getString("LoaiKhaoSat"));
        java.sql.Date ngay = rs.getDate("NgayKhaoSat");
        if (ngay != null) {
            ks.setNgayKhaoSat(ngay.toLocalDate());
        }
        ks.setPhanHoi(rs.getString("PhanHoi"));
        ks.setDanhGia(rs.getInt("DanhGia"));
        return ks;
    };

    public List<KhaoSat> findAll() throws SQLException {
        return JdbcUtil.query("SELECT * FROM KHAO_SAT ORDER BY MaKhaoSat", MAPPER);
    }

    public KhaoSat findById(String maKhaoSat) throws SQLException {
        return JdbcUtil.queryOne("SELECT * FROM KHAO_SAT WHERE MaKhaoSat = ?", MAPPER, maKhaoSat);
    }

    public void insert(KhaoSat ks) throws SQLException {
        JdbcUtil.update("INSERT INTO KHAO_SAT (MaKhaoSat, MaDoanHoacChuyen, LoaiKhaoSat, NgayKhaoSat, PhanHoi, DanhGia) VALUES (?, ?, ?, ?, ?, ?)",
                ks.getMaKhaoSat(), ks.getMaDoanHoacChuyen(), ks.getLoaiKhaoSat(),
                Date.valueOf(ks.getNgayKhaoSat()), ks.getPhanHoi(), ks.getDanhGia());
    }

    public void update(KhaoSat ks) throws SQLException {
        JdbcUtil.update("UPDATE KHAO_SAT SET MaDoanHoacChuyen = ?, LoaiKhaoSat = ?, NgayKhaoSat = ?, PhanHoi = ?, DanhGia = ? WHERE MaKhaoSat = ?",
                ks.getMaDoanHoacChuyen(), ks.getLoaiKhaoSat(), Date.valueOf(ks.getNgayKhaoSat()),
                ks.getPhanHoi(), ks.getDanhGia(), ks.getMaKhaoSat());
    }

    public void delete(String maKhaoSat) throws SQLException {
        JdbcUtil.update("DELETE FROM KHAO_SAT WHERE MaKhaoSat = ?", maKhaoSat);
    }

    public String nextId() throws SQLException {
        return JdbcUtil.nextId("KHAO_SAT", "MaKhaoSat", "KS", 3);
    }
}
