package com.travel.company.config;

public final class DatabaseConfig {
    public static final String URL = "jdbc:postgresql://localhost:5432/travel_company";
    public static final String USER = "postgres";
    public static final String PASSWORD = "postgres";

    private DatabaseConfig() {
    }
}
