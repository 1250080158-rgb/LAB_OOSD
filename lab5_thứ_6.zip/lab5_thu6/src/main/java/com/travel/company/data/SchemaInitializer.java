package com.travel.company.data;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;

/**
 * Khoi tao schema (neu chua co) va sinh du lieu mau (neu bang trong).
 * DDL tuong duong voi database/postgresql_schema.sql.
 */
public class SchemaInitializer {

    private static final String[] DDL = {
            "CREATE TABLE IF NOT EXISTS TOUR (MaTour CHAR(10) PRIMARY KEY, TenTour VARCHAR(100) NOT NULL, SoNgay INT NOT NULL CHECK (SoNgay > 0), SoDem INT NOT NULL CHECK (SoDem >= 0), DonGia DECIMAL(18,0) NOT NULL CHECK (DonGia >= 0))",
            "CREATE TABLE IF NOT EXISTS KHACH_HANG (MaKhachHang CHAR(10) PRIMARY KEY, HoTen VARCHAR(100) NOT NULL, CMND CHAR(12) UNIQUE, SoDienThoai CHAR(15), DiaChi VARCHAR(200), Email VARCHAR(100))",
            "CREATE TABLE IF NOT EXISTS NHAN_VIEN (MaNhanVien CHAR(10) PRIMARY KEY, HoTen VARCHAR(100) NOT NULL, CMND CHAR(12) UNIQUE, SoDienThoai CHAR(15), DiaChi VARCHAR(200), LuongCanBan DECIMAL(18,0) NOT NULL)",
            "CREATE TABLE IF NOT EXISTS DIEM_THAM_QUAN (MaDiem CHAR(10) PRIMARY KEY, TenDiem VARCHAR(100) NOT NULL, DiaDiem VARCHAR(100), NoiDung TEXT, YNghia TEXT)",
            "CREATE TABLE IF NOT EXISTS PHUONG_TIEN (MaPhuongTien CHAR(10) PRIMARY KEY, LoaiPhuongTien VARCHAR(50) NOT NULL, BienSo VARCHAR(20), HangSanXuat VARCHAR(50), SoCho INT NOT NULL CHECK (SoCho > 0))",
            "CREATE TABLE IF NOT EXISTS NOI_DUNG_CHAN (MaNoiDungChan CHAR(10) PRIMARY KEY, TenNoi VARCHAR(100) NOT NULL, DiaDiem VARCHAR(100), DoiPhuongTien BOOLEAN NOT NULL DEFAULT FALSE, CoNaiAn BOOLEAN NOT NULL DEFAULT FALSE, CoKhachSan BOOLEAN NOT NULL DEFAULT FALSE, LoaiKhachSan INT CHECK (LoaiKhachSan IN (2,3,4,5) OR LoaiKhachSan IS NULL))",
            "CREATE TABLE IF NOT EXISTS CHUYEN_DU_LICH (MaChuyen CHAR(10) PRIMARY KEY, MaTour CHAR(10) NOT NULL REFERENCES TOUR(MaTour), NgayDi DATE NOT NULL, NgayVe DATE NOT NULL, SoNguoiMax INT NOT NULL CHECK (SoNguoiMax > 0), SoNguoiDaDangKy INT NOT NULL DEFAULT 0, TrangThai VARCHAR(20) NOT NULL DEFAULT 'Chua di', CONSTRAINT CHK_CHUYEN_NGAY CHECK (NgayVe >= NgayDi), CONSTRAINT CHK_CHUYEN_SOCHO CHECK (SoNguoiDaDangKy <= SoNguoiMax))",
            "CREATE TABLE IF NOT EXISTS DANG_KY_DOAN (MaPhieuDoan CHAR(10) PRIMARY KEY, TenCoQuan VARCHAR(100) NOT NULL, DiaChiCoQuan VARCHAR(200), DienThoaiCoQuan CHAR(15), NguoiDaiDien VARCHAR(100) NOT NULL, SoNguoiDi INT NOT NULL CHECK (SoNguoiDi > 12), MuaBaoHiem BOOLEAN NOT NULL DEFAULT FALSE, DiaDiemDon VARCHAR(200), TienCoc DECIMAL(18,0) NOT NULL DEFAULT 0, MaTour CHAR(10) NOT NULL REFERENCES TOUR(MaTour), NgayDi DATE NOT NULL, TrangThai VARCHAR(20) NOT NULL DEFAULT 'Chua di')",
            "CREATE TABLE IF NOT EXISTS DANH_SACH_NGUOI_DI (MaPhieuDoan CHAR(10) NOT NULL REFERENCES DANG_KY_DOAN(MaPhieuDoan) ON DELETE CASCADE, HoTen VARCHAR(100) NOT NULL, PRIMARY KEY (MaPhieuDoan, HoTen))",
            "CREATE TABLE IF NOT EXISTS DANG_KY_CHUYEN (MaPhieuChuyen CHAR(10) PRIMARY KEY, MaKhachHang CHAR(10) NOT NULL REFERENCES KHACH_HANG(MaKhachHang), MaChuyen CHAR(10) NOT NULL REFERENCES CHUYEN_DU_LICH(MaChuyen), NgayDangKy DATE NOT NULL, DiemBanVe VARCHAR(100), DiaDiemDon VARCHAR(200), ThanhTien DECIMAL(18,0) NOT NULL, TrangThai VARCHAR(20) NOT NULL DEFAULT 'Chua thanh toan')",
            "CREATE TABLE IF NOT EXISTS PHAN_CONG_NHAN_VIEN (MaPhanCong CHAR(10) PRIMARY KEY, MaNhanVien CHAR(10) NOT NULL REFERENCES NHAN_VIEN(MaNhanVien), LoaiPhanCong VARCHAR(10) NOT NULL CHECK (LoaiPhanCong IN ('Doan','Chuyen')), MaDoanHoacChuyen CHAR(10) NOT NULL, NgayBatDau DATE NOT NULL, NgayKetThuc DATE NOT NULL, LuongTour DECIMAL(18,0) NOT NULL DEFAULT 0, CONSTRAINT CHK_PHANCONG_NGAY CHECK (NgayKetThuc >= NgayBatDau))",
            "CREATE TABLE IF NOT EXISTS KHAO_SAT (MaKhaoSat CHAR(10) PRIMARY KEY, MaDoanHoacChuyen CHAR(10) NOT NULL, LoaiKhaoSat VARCHAR(10) NOT NULL CHECK (LoaiKhaoSat IN ('Doan','Chuyen')), NgayKhaoSat DATE NOT NULL, PhanHoi TEXT NOT NULL, DanhGia INT NOT NULL CHECK (DanhGia BETWEEN 1 AND 5))",
            "CREATE TABLE IF NOT EXISTS TOUR_NOI_DUNG_CHAN (MaTour CHAR(10) NOT NULL REFERENCES TOUR(MaTour) ON DELETE CASCADE, MaNoiDungChan CHAR(10) NOT NULL REFERENCES NOI_DUNG_CHAN(MaNoiDungChan) ON DELETE CASCADE, ThuTu INT NOT NULL DEFAULT 0, PRIMARY KEY (MaTour, MaNoiDungChan))",
            "CREATE TABLE IF NOT EXISTS TOUR_PHUONG_TIEN (MaTour CHAR(10) NOT NULL REFERENCES TOUR(MaTour) ON DELETE CASCADE, MaPhuongTien CHAR(10) NOT NULL REFERENCES PHUONG_TIEN(MaPhuongTien) ON DELETE CASCADE, ThuTu INT NOT NULL DEFAULT 0, PRIMARY KEY (MaTour, MaPhuongTien))",
            "CREATE TABLE IF NOT EXISTS TOUR_DIEM_THAM_QUAN (MaTour CHAR(10) NOT NULL REFERENCES TOUR(MaTour) ON DELETE CASCADE, MaDiem CHAR(10) NOT NULL REFERENCES DIEM_THAM_QUAN(MaDiem) ON DELETE CASCADE, ThuTu INT NOT NULL DEFAULT 0, PRIMARY KEY (MaTour, MaDiem))"
    };

    private static final String[] INDEXES = {
            "CREATE INDEX IF NOT EXISTS IX_DANG_KY_CHUYEN_MACHUYEN ON DANG_KY_CHUYEN(MaChuyen)",
            "CREATE INDEX IF NOT EXISTS IX_DANG_KY_CHUYEN_MAKHACHHANG ON DANG_KY_CHUYEN(MaKhachHang)",
            "CREATE INDEX IF NOT EXISTS IX_PHAN_CONG_MANHANVIEN ON PHAN_CONG_NHAN_VIEN(MaNhanVien)",
            "CREATE INDEX IF NOT EXISTS IX_DANG_KY_DOAN_MATOUR ON DANG_KY_DOAN(MaTour)"
    };

    public static synchronized void init() {
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement()) {
            for (String ddl : DDL) {
                stmt.execute(ddl);
            }
            for (String idx : INDEXES) {
                stmt.execute(idx);
            }
            if (isDbEmpty(conn)) {
                sinhDuLieuMau(conn);
            }
        } catch (SQLException e) {
            throw new RuntimeException("Khoi tao CSDL that bai: " + e.getMessage(), e);
        }
    }

    private static boolean isDbEmpty(Connection conn) throws SQLException {
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT COUNT(*) AS c FROM TOUR")) {
            rs.next();
            return rs.getInt("c") == 0;
        }
    }

    private static void sinhDuLieuMau(Connection conn) throws SQLException {
        try (Statement stmt = conn.createStatement()) {
            // Tour
            stmt.execute("INSERT INTO TOUR VALUES ('T001', N'Tour Ha Noi - Lao Cai', 5, 4, 3500000)");
            stmt.execute("INSERT INTO TOUR VALUES ('T002', N'Tour Da Nang - Hoi An', 4, 3, 2800000)");
            stmt.execute("INSERT INTO TOUR VALUES ('T003', N'Tour Phu Quoc', 3, 2, 2500000)");
            stmt.execute("INSERT INTO TOUR VALUES ('T004', N'Tour Nha Trang', 4, 3, 3000000)");

            // Khach hang
            stmt.execute("INSERT INTO KHACH_HANG VALUES ('KH001', N'Nguyen Van A', '001234567890', '0901234567', N'TP.HCM', 'nguyenvana@email.com')");
            stmt.execute("INSERT INTO KHACH_HANG VALUES ('KH002', N'Tran Thi B', '001234567891', '0912345678', N'TP.HCM', 'tranthib@email.com')");
            stmt.execute("INSERT INTO KHACH_HANG VALUES ('KH003', N'Le Van C', '001234567892', '0923456789', N'TP.HCM', 'levanc@email.com')");

            // Nhan vien
            stmt.execute("INSERT INTO NHAN_VIEN VALUES ('NV001', N'Pham Minh D', '001234567893', '0934567890', N'TP.HCM', 5000000)");
            stmt.execute("INSERT INTO NHAN_VIEN VALUES ('NV002', N'Hoang Thi E', '001234567894', '0945678901', N'TP.HCM', 5000000)");
            stmt.execute("INSERT INTO NHAN_VIEN VALUES ('NV003', N'Do Van F', '001234567895', '0956789012', N'TP.HCM', 5000000)");

            // Diem tham quan
            stmt.execute("INSERT INTO DIEM_THAM_QUAN VALUES ('DT001', N'Ho Guom', N'Ha Noi', N'Ho nuoc nam o trung tam Ha Noi', N'Bieu tuong cua thu do')");
            stmt.execute("INSERT INTO DIEM_THAM_QUAN VALUES ('DT002', N'Cau Rong', N'Da Nang', N'Cau phun lua', N'Bieu tuong cua Da Nang')");
            stmt.execute("INSERT INTO DIEM_THAM_QUAN VALUES ('DT003', N'Vi Ha Long', N'Quang Ninh', N'Di san thien nhien the gioi', N'Vi dep nhat the gioi')");

            // Phuong tien
            stmt.execute("INSERT INTO PHUONG_TIEN VALUES ('PT001', N'May bay', '', N'Vietnam Airlines', 180)");
            stmt.execute("INSERT INTO PHUONG_TIEN VALUES ('PT002', N'Xe o to', '51A-12345', N'Toyota', 45)");
            stmt.execute("INSERT INTO PHUONG_TIEN VALUES ('PT003', N'Tau hoa', '', N'Duong sat Viet Nam', 500)");

            // Noi dung chan
            stmt.execute("INSERT INTO NOI_DUNG_CHAN VALUES ('NDC001', N'Ha Noi', N'Ha Noi', TRUE, TRUE, TRUE, 4)");
            stmt.execute("INSERT INTO NOI_DUNG_CHAN VALUES ('NDC002', N'Da Nang', N'Da Nang', TRUE, TRUE, TRUE, 3)");
            stmt.execute("INSERT INTO NOI_DUNG_CHAN VALUES ('NDC003', N'Nha Trang', N'Khanh Hoa', FALSE, TRUE, TRUE, 4)");

            // Chuyen du lich (lich cua cac tours)
            stmt.execute("INSERT INTO CHUYEN_DU_LICH VALUES ('C001', 'T001', '2026-11-01', '2026-11-05', 40, 0, 'Chưa đi')");
            stmt.execute("INSERT INTO CHUYEN_DU_LICH VALUES ('C002', 'T002', '2026-11-10', '2026-11-13', 30, 0, 'Chưa đi')");
            stmt.execute("INSERT INTO CHUYEN_DU_LICH VALUES ('C003', 'T003', '2026-11-15', '2026-11-17', 25, 0, 'Chưa đi')");

            // Lien ket tour - noi dung chan / phuong tien / diem tham quan
            stmt.execute("INSERT INTO TOUR_NOI_DUNG_CHAN VALUES ('T001', 'NDC001', 1)");
            stmt.execute("INSERT INTO TOUR_NOI_DUNG_CHAN VALUES ('T002', 'NDC002', 1)");
            stmt.execute("INSERT INTO TOUR_NOI_DUNG_CHAN VALUES ('T004', 'NDC003', 1)");
            stmt.execute("INSERT INTO TOUR_PHUONG_TIEN VALUES ('T001', 'PT003', 1)");
            stmt.execute("INSERT INTO TOUR_PHUONG_TIEN VALUES ('T002', 'PT002', 1)");
            stmt.execute("INSERT INTO TOUR_PHUONG_TIEN VALUES ('T003', 'PT001', 1)");
            stmt.execute("INSERT INTO TOUR_DIEM_THAM_QUAN VALUES ('T001', 'DT001', 1)");
            stmt.execute("INSERT INTO TOUR_DIEM_THAM_QUAN VALUES ('T001', 'DT003', 2)");
            stmt.execute("INSERT INTO TOUR_DIEM_THAM_QUAN VALUES ('T002', 'DT002', 1)");
        }
    }
}
