package com.travel.company.service;

import com.travel.company.data.ChuyenDuLichDao;
import com.travel.company.model.ChuyenDuLich;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;

public class ChuyenDuLichService {

    private final ChuyenDuLichDao dao = new ChuyenDuLichDao();

    public List<ChuyenDuLich> findAll() {
        try {
            return dao.findAll();
        } catch (SQLException e) {
            throw new RuntimeException("Lay danh sach chuyen that bai: " + e.getMessage(), e);
        }
    }

    public List<ChuyenDuLich> findByTour(String maTour) {
        try {
            return dao.findByTour(maTour);
        } catch (SQLException e) {
            throw new RuntimeException("Lay chuyen cua tour that bai: " + e.getMessage(), e);
        }
    }

    public ChuyenDuLich findById(String maChuyen) {
        try {
            return dao.findById(maChuyen);
        } catch (SQLException e) {
            throw new RuntimeException("Lay chuyen that bai: " + e.getMessage(), e);
        }
    }

    public String nextId() {
        try {
            return dao.nextId();
        } catch (SQLException e) {
            throw new RuntimeException("Sinh ma chuyen that bai: " + e.getMessage(), e);
        }
    }

    public void themChuyen(ChuyenDuLich c) {
        validate(c);
        try {
            if (dao.findById(c.getMaChuyen()) != null) {
                throw new IllegalArgumentException("Ma chuyen da ton tai!");
            }
            dao.insert(c);
        } catch (SQLException e) {
            throw new RuntimeException("Them chuyen that bai: " + e.getMessage(), e);
        }
    }

    public void suaChuyen(ChuyenDuLich c) {
        validate(c);
        try {
            dao.update(c);
        } catch (SQLException e) {
            throw new RuntimeException("Sua chuyen that bai: " + e.getMessage(), e);
        }
    }

    public void xoaChuyen(String maChuyen) {
        try {
            dao.delete(maChuyen);
        } catch (SQLException e) {
            throw new RuntimeException("Xoa chuyen that bai (co the con du lieu dang ky): " + e.getMessage(), e);
        }
    }

    public void capNhatSoNguoiDaDangKy(String maChuyen, int soNguoi) {
        try {
            dao.updateSoNguoiDaDangKy(maChuyen, soNguoi);
        } catch (SQLException e) {
            throw new RuntimeException("Cap nhat so nguoi dang ky that bai: " + e.getMessage(), e);
        }
    }

    public void capNhatTrangThai(String maChuyen, String trangThai) {
        try {
            dao.updateTrangThai(maChuyen, trangThai);
        } catch (SQLException e) {
            throw new RuntimeException("Cap nhat trang thai chuyen that bai: " + e.getMessage(), e);
        }
    }

    private void validate(ChuyenDuLich c) {
        if (c.getMaChuyen() == null || c.getMaChuyen().trim().isEmpty()) {
            throw new IllegalArgumentException("Chua nhap ma chuyen!");
        }
        if (c.getMaTour() == null || c.getMaTour().trim().isEmpty()) {
            throw new IllegalArgumentException("Chua chon tour!");
        }
        if (c.getNgayDi() == null || c.getNgayVe() == null) {
            throw new IllegalArgumentException("Chua chon ngay di/ve!");
        }
        if (c.getNgayVe().isBefore(c.getNgayDi())) {
            throw new IllegalArgumentException("Ngay ve phai sau ngay di!");
        }
        if (c.getSoNguoiMax() <= 0) {
            throw new IllegalArgumentException("So nguoi toi da phai lon hon 0!");
        }
    }
}
