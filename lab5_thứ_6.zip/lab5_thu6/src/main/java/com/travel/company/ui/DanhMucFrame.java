package com.travel.company.ui;

import com.travel.company.model.*;
import com.travel.company.service.*;
import com.travel.company.util.FormDialogUtil;
import com.travel.company.util.UiUtil;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.util.Map;
import java.util.Optional;

public class DanhMucFrame {
    private Stage stage;

    private final TourService tourService = new TourService();
    private final KhachHangService khachHangService = new KhachHangService();
    private final NhanVienService nhanVienService = new NhanVienService();
    private final DiemThamQuanService diemThamQuanService = new DiemThamQuanService();
    private final PhuongTienService phuongTienService = new PhuongTienService();
    private final NoiDungChanService noiDungChanService = new NoiDungChanService();

    public DanhMucFrame() {
        stage = new Stage();
        stage.setTitle("Danh mục");

        TabPane tabPane = new TabPane();

        Tab tabTour = new Tab("Tour");
        tabTour.setContent(createTourContent());
        tabTour.setClosable(false);

        Tab tabKhachHang = new Tab("Khách hàng");
        tabKhachHang.setContent(createKhachHangContent());
        tabKhachHang.setClosable(false);

        Tab tabNhanVien = new Tab("Nhân viên");
        tabNhanVien.setContent(createNhanVienContent());
        tabNhanVien.setClosable(false);

        Tab tabDiemThamQuan = new Tab("Điểm tham quan");
        tabDiemThamQuan.setContent(createDiemThamQuanContent());
        tabDiemThamQuan.setClosable(false);

        Tab tabPhuongTien = new Tab("Phương tiện");
        tabPhuongTien.setContent(createPhuongTienContent());
        tabPhuongTien.setClosable(false);

        Tab tabNoiDungChan = new Tab("Nơi dừng chân");
        tabNoiDungChan.setContent(createNoiDungChanContent());
        tabNoiDungChan.setClosable(false);

        tabPane.getTabs().addAll(tabTour, tabKhachHang, tabNhanVien, tabDiemThamQuan, tabPhuongTien, tabNoiDungChan);

        VBox root = new VBox(10);
        root.setPadding(new Insets(10));
        root.getChildren().addAll(tabPane, createBackButton());

        Scene scene = new Scene(root, 900, 600);
        stage.setScene(scene);
    }

    // ===================== TOUR =====================

    private VBox createTourContent() {
        VBox content = new VBox(10);
        content.setPadding(new Insets(10));

        Label label = new Label("Quản lý Tour");
        label.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;");

        TableView<Tour> tableView = new TableView<>();
        ObservableList<Tour> tourList = FXCollections.observableArrayList(tourService.findAll());
        tableView.setItems(tourList);

        TableColumn<Tour, String> colMaTour = new TableColumn<>("Mã Tour");
        colMaTour.setCellValueFactory(new PropertyValueFactory<>("maTour"));
        colMaTour.setPrefWidth(100);

        TableColumn<Tour, String> colTenTour = new TableColumn<>("Tên Tour");
        colTenTour.setCellValueFactory(new PropertyValueFactory<>("tenTour"));
        colTenTour.setPrefWidth(250);

        TableColumn<Tour, Integer> colSoNgay = new TableColumn<>("Số ngày");
        colSoNgay.setCellValueFactory(new PropertyValueFactory<>("soNgay"));
        colSoNgay.setPrefWidth(80);

        TableColumn<Tour, Integer> colSoDem = new TableColumn<>("Số đêm");
        colSoDem.setCellValueFactory(new PropertyValueFactory<>("soDem"));
        colSoDem.setPrefWidth(80);

        TableColumn<Tour, Double> colDonGia = new TableColumn<>("Đơn giá");
        colDonGia.setCellValueFactory(new PropertyValueFactory<>("donGia"));
        colDonGia.setPrefWidth(120);

        tableView.getColumns().addAll(colMaTour, colTenTour, colSoNgay, colSoDem, colDonGia);

        HBox buttonBox = new HBox(10);
        Button btnThem = new Button("Thêm");
        Button btnSua = new Button("Sửa");
        Button btnXoa = new Button("Xóa");

        btnThem.setOnAction(e -> {
            try {
                String maMoi = tourService.nextId();
                Optional<Map<String, String>> ketQua = FormDialogUtil.showForm("Thêm Tour",
                        new String[]{"Mã Tour", "Tên Tour", "Số ngày", "Số đêm", "Đơn giá (VNĐ)"},
                        new String[]{maMoi, "", "1", "0", "1000000"});
                if (ketQua.isPresent()) {
                    Map<String, String> v = ketQua.get();
                    Tour tour = new Tour();
                    tour.setMaTour(v.get("Mã Tour"));
                    tour.setTenTour(v.get("Tên Tour"));
                    tour.setSoNgay(Integer.parseInt(v.get("Số ngày")));
                    tour.setSoDem(Integer.parseInt(v.get("Số đêm")));
                    tour.setDonGia(Double.parseDouble(v.get("Đơn giá (VNĐ)")));
                    tourService.themTour(tour);
                    tourList.setAll(tourService.findAll());
                    UiUtil.alert("Thông báo", "Đã thêm tour thành công!");
                }
            } catch (NumberFormatException ex) {
                UiUtil.error("Số ngày, số đêm, đơn giá phải là số!");
            } catch (IllegalArgumentException ex) {
                UiUtil.error(ex.getMessage());
            }
        });

        btnSua.setOnAction(e -> {
            Tour selected = tableView.getSelectionModel().getSelectedItem();
            if (selected == null) {
                UiUtil.error("Vui lòng chọn tour để sửa!");
                return;
            }
            try {
                Optional<Map<String, String>> ketQua = FormDialogUtil.showForm("Sửa Tour",
                        new String[]{"Mã Tour", "Tên Tour", "Số ngày", "Số đêm", "Đơn giá (VNĐ)"},
                        new String[]{selected.getMaTour(), selected.getTenTour(),
                                String.valueOf(selected.getSoNgay()), String.valueOf(selected.getSoDem()),
                                String.valueOf((long) selected.getDonGia())});
                if (ketQua.isPresent()) {
                    Map<String, String> v = ketQua.get();
                    selected.setTenTour(v.get("Tên Tour"));
                    selected.setSoNgay(Integer.parseInt(v.get("Số ngày")));
                    selected.setSoDem(Integer.parseInt(v.get("Số đêm")));
                    selected.setDonGia(Double.parseDouble(v.get("Đơn giá (VNĐ)")));
                    tourService.suaTour(selected);
                    tourList.setAll(tourService.findAll());
                    UiUtil.alert("Thông báo", "Đã sửa tour thành công!");
                }
            } catch (NumberFormatException ex) {
                UiUtil.error("Số ngày, số đêm, đơn giá phải là số!");
            } catch (IllegalArgumentException ex) {
                UiUtil.error(ex.getMessage());
            }
        });

        btnXoa.setOnAction(e -> {
            Tour selected = tableView.getSelectionModel().getSelectedItem();
            if (selected == null) {
                UiUtil.error("Vui lòng chọn tour để xóa!");
                return;
            }
            if (UiUtil.confirm("Bạn có chắc muốn xóa tour này?")) {
                try {
                    tourService.xoaTour(selected.getMaTour());
                    tourList.setAll(tourService.findAll());
                    UiUtil.alert("Thông báo", "Đã xóa tour thành công!");
                } catch (RuntimeException ex) {
                    UiUtil.error(ex.getMessage());
                }
            }
        });

        buttonBox.getChildren().addAll(btnThem, btnSua, btnXoa);
        content.getChildren().addAll(label, tableView, buttonBox);
        return content;
    }

    // ===================== KHACH HANG =====================

    private VBox createKhachHangContent() {
        VBox content = new VBox(10);
        content.setPadding(new Insets(10));

        Label label = new Label("Quản lý Khách hàng");
        label.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;");

        TableView<KhachHang> tableView = new TableView<>();
        ObservableList<KhachHang> list = FXCollections.observableArrayList(khachHangService.findAll());
        tableView.setItems(list);

        TableColumn<KhachHang, String> colMaKH = new TableColumn<>("Mã KH");
        colMaKH.setCellValueFactory(new PropertyValueFactory<>("maKhachHang"));
        colMaKH.setPrefWidth(100);

        TableColumn<KhachHang, String> colHoTen = new TableColumn<>("Họ tên");
        colHoTen.setCellValueFactory(new PropertyValueFactory<>("hoTen"));
        colHoTen.setPrefWidth(200);

        TableColumn<KhachHang, String> colCMND = new TableColumn<>("CMND");
        colCMND.setCellValueFactory(new PropertyValueFactory<>("cmnd"));
        colCMND.setPrefWidth(150);

        TableColumn<KhachHang, String> colSDT = new TableColumn<>("SĐT");
        colSDT.setCellValueFactory(new PropertyValueFactory<>("soDienThoai"));
        colSDT.setPrefWidth(120);

        TableColumn<KhachHang, String> colDiaChi = new TableColumn<>("Địa chỉ");
        colDiaChi.setCellValueFactory(new PropertyValueFactory<>("diaChi"));
        colDiaChi.setPrefWidth(180);

        tableView.getColumns().addAll(colMaKH, colHoTen, colCMND, colSDT, colDiaChi);

        HBox buttonBox = new HBox(10);
        Button btnThem = new Button("Thêm");
        Button btnSua = new Button("Sửa");
        Button btnXoa = new Button("Xóa");

        btnThem.setOnAction(e -> {
            try {
                String maMoi = khachHangService.nextId();
                Optional<Map<String, String>> ketQua = FormDialogUtil.showForm("Thêm Khách hàng",
                        new String[]{"Mã KH", "Họ tên", "CMND", "SĐT", "Địa chỉ", "Email"},
                        new String[]{maMoi, "", "", "", "", ""});
                if (ketQua.isPresent()) {
                    Map<String, String> v = ketQua.get();
                    KhachHang kh = new KhachHang(v.get("Mã KH"), v.get("Họ tên"), v.get("CMND"),
                            v.get("SĐT"), v.get("Địa chỉ"), v.get("Email"));
                    khachHangService.themKhachHang(kh);
                    list.setAll(khachHangService.findAll());
                    UiUtil.alert("Thông báo", "Đã thêm khách hàng thành công!");
                }
            } catch (IllegalArgumentException ex) {
                UiUtil.error(ex.getMessage());
            }
        });

        btnSua.setOnAction(e -> {
            KhachHang selected = tableView.getSelectionModel().getSelectedItem();
            if (selected == null) {
                UiUtil.error("Vui lòng chọn khách hàng để sửa!");
                return;
            }
            Optional<Map<String, String>> ketQua = FormDialogUtil.showForm("Sửa Khách hàng",
                    new String[]{"Mã KH", "Họ tên", "CMND", "SĐT", "Địa chỉ", "Email"},
                    new String[]{selected.getMaKhachHang(), selected.getHoTen(), selected.getCmnd(),
                            selected.getSoDienThoai(), selected.getDiaChi(), selected.getEmail()});
            if (ketQua.isPresent()) {
                Map<String, String> v = ketQua.get();
                selected.setHoTen(v.get("Họ tên"));
                selected.setCmnd(v.get("CMND"));
                selected.setSoDienThoai(v.get("SĐT"));
                selected.setDiaChi(v.get("Địa chỉ"));
                selected.setEmail(v.get("Email"));
                try {
                    khachHangService.suaKhachHang(selected);
                    list.setAll(khachHangService.findAll());
                    UiUtil.alert("Thông báo", "Đã sửa khách hàng thành công!");
                } catch (IllegalArgumentException ex) {
                    UiUtil.error(ex.getMessage());
                }
            }
        });

        btnXoa.setOnAction(e -> {
            KhachHang selected = tableView.getSelectionModel().getSelectedItem();
            if (selected == null) {
                UiUtil.error("Vui lòng chọn khách hàng để xóa!");
                return;
            }
            if (UiUtil.confirm("Bạn có chắc muốn xóa khách hàng này?")) {
                try {
                    khachHangService.xoaKhachHang(selected.getMaKhachHang());
                    list.setAll(khachHangService.findAll());
                    UiUtil.alert("Thông báo", "Đã xóa khách hàng thành công!");
                } catch (RuntimeException ex) {
                    UiUtil.error(ex.getMessage());
                }
            }
        });

        buttonBox.getChildren().addAll(btnThem, btnSua, btnXoa);
        content.getChildren().addAll(label, tableView, buttonBox);
        return content;
    }

    // ===================== NHAN VIEN =====================

    private VBox createNhanVienContent() {
        VBox content = new VBox(10);
        content.setPadding(new Insets(10));

        Label label = new Label("Quản lý Nhân viên");
        label.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;");

        TableView<NhanVien> tableView = new TableView<>();
        ObservableList<NhanVien> list = FXCollections.observableArrayList(nhanVienService.findAll());
        tableView.setItems(list);

        TableColumn<NhanVien, String> colMaNV = new TableColumn<>("Mã NV");
        colMaNV.setCellValueFactory(new PropertyValueFactory<>("maNhanVien"));
        colMaNV.setPrefWidth(100);

        TableColumn<NhanVien, String> colHoTen = new TableColumn<>("Họ tên");
        colHoTen.setCellValueFactory(new PropertyValueFactory<>("hoTen"));
        colHoTen.setPrefWidth(200);

        TableColumn<NhanVien, String> colCMND = new TableColumn<>("CMND");
        colCMND.setCellValueFactory(new PropertyValueFactory<>("cmnd"));
        colCMND.setPrefWidth(150);

        TableColumn<NhanVien, String> colSDT = new TableColumn<>("SĐT");
        colSDT.setCellValueFactory(new PropertyValueFactory<>("soDienThoai"));
        colSDT.setPrefWidth(120);

        TableColumn<NhanVien, Double> colLuong = new TableColumn<>("Lương cơ bản");
        colLuong.setCellValueFactory(new PropertyValueFactory<>("luongCanBan"));
        colLuong.setPrefWidth(120);

        tableView.getColumns().addAll(colMaNV, colHoTen, colCMND, colSDT, colLuong);

        HBox buttonBox = new HBox(10);
        Button btnThem = new Button("Thêm");
        Button btnSua = new Button("Sửa");
        Button btnXoa = new Button("Xóa");

        btnThem.setOnAction(e -> {
            try {
                String maMoi = nhanVienService.nextId();
                Optional<Map<String, String>> ketQua = FormDialogUtil.showForm("Thêm Nhân viên",
                        new String[]{"Mã NV", "Họ tên", "CMND", "SĐT", "Địa chỉ", "Lương cơ bản (VNĐ)"},
                        new String[]{maMoi, "", "", "", "", "5000000"});
                if (ketQua.isPresent()) {
                    Map<String, String> v = ketQua.get();
                    NhanVien nv = new NhanVien(v.get("Mã NV"), v.get("Họ tên"), v.get("CMND"),
                            v.get("SĐT"), v.get("Địa chỉ"), Double.parseDouble(v.get("Lương cơ bản (VNĐ)")));
                    nhanVienService.themNhanVien(nv);
                    list.setAll(nhanVienService.findAll());
                    UiUtil.alert("Thông báo", "Đã thêm nhân viên thành công!");
                }
            } catch (NumberFormatException ex) {
                UiUtil.error("Lương cơ bản phải là số!");
            } catch (IllegalArgumentException ex) {
                UiUtil.error(ex.getMessage());
            }
        });

        btnSua.setOnAction(e -> {
            NhanVien selected = tableView.getSelectionModel().getSelectedItem();
            if (selected == null) {
                UiUtil.error("Vui lòng chọn nhân viên để sửa!");
                return;
            }
            try {
                Optional<Map<String, String>> ketQua = FormDialogUtil.showForm("Sửa Nhân viên",
                        new String[]{"Mã NV", "Họ tên", "CMND", "SĐT", "Địa chỉ", "Lương cơ bản (VNĐ)"},
                        new String[]{selected.getMaNhanVien(), selected.getHoTen(), selected.getCmnd(),
                                selected.getSoDienThoai(), selected.getDiaChi(),
                                String.valueOf((long) selected.getLuongCanBan())});
                if (ketQua.isPresent()) {
                    Map<String, String> v = ketQua.get();
                    selected.setHoTen(v.get("Họ tên"));
                    selected.setCmnd(v.get("CMND"));
                    selected.setSoDienThoai(v.get("SĐT"));
                    selected.setDiaChi(v.get("Địa chỉ"));
                    selected.setLuongCanBan(Double.parseDouble(v.get("Lương cơ bản (VNĐ)")));
                    nhanVienService.suaNhanVien(selected);
                    list.setAll(nhanVienService.findAll());
                    UiUtil.alert("Thông báo", "Đã sửa nhân viên thành công!");
                }
            } catch (NumberFormatException ex) {
                UiUtil.error("Lương cơ bản phải là số!");
            } catch (IllegalArgumentException ex) {
                UiUtil.error(ex.getMessage());
            }
        });

        btnXoa.setOnAction(e -> {
            NhanVien selected = tableView.getSelectionModel().getSelectedItem();
            if (selected == null) {
                UiUtil.error("Vui lòng chọn nhân viên để xóa!");
                return;
            }
            if (UiUtil.confirm("Bạn có chắc muốn xóa nhân viên này?")) {
                try {
                    nhanVienService.xoaNhanVien(selected.getMaNhanVien());
                    list.setAll(nhanVienService.findAll());
                    UiUtil.alert("Thông báo", "Đã xóa nhân viên thành công!");
                } catch (RuntimeException ex) {
                    UiUtil.error(ex.getMessage());
                }
            }
        });

        buttonBox.getChildren().addAll(btnThem, btnSua, btnXoa);
        content.getChildren().addAll(label, tableView, buttonBox);
        return content;
    }

    // ===================== DIEM THAM QUAN =====================

    private VBox createDiemThamQuanContent() {
        VBox content = new VBox(10);
        content.setPadding(new Insets(10));

        Label label = new Label("Quản lý Điểm tham quan");
        label.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;");

        TableView<DiemThamQuan> tableView = new TableView<>();
        ObservableList<DiemThamQuan> list = FXCollections.observableArrayList(diemThamQuanService.findAll());
        tableView.setItems(list);

        TableColumn<DiemThamQuan, String> colMa = new TableColumn<>("Mã");
        colMa.setCellValueFactory(new PropertyValueFactory<>("maDiem"));
        colMa.setPrefWidth(80);

        TableColumn<DiemThamQuan, String> colTen = new TableColumn<>("Tên điểm");
        colTen.setCellValueFactory(new PropertyValueFactory<>("tenDiem"));
        colTen.setPrefWidth(200);

        TableColumn<DiemThamQuan, String> colDiaDiem = new TableColumn<>("Địa điểm");
        colDiaDiem.setCellValueFactory(new PropertyValueFactory<>("diaDiem"));
        colDiaDiem.setPrefWidth(200);

        TableColumn<DiemThamQuan, String> colNoiDung = new TableColumn<>("Nội dung");
        colNoiDung.setCellValueFactory(new PropertyValueFactory<>("noiDung"));
        colNoiDung.setPrefWidth(250);

        TableColumn<DiemThamQuan, String> colYNghia = new TableColumn<>("Ý nghĩa");
        colYNghia.setCellValueFactory(new PropertyValueFactory<>("yNghia"));
        colYNghia.setPrefWidth(250);

        tableView.getColumns().addAll(colMa, colTen, colDiaDiem, colNoiDung, colYNghia);

        HBox buttonBox = new HBox(10);
        Button btnThem = new Button("Thêm");
        Button btnSua = new Button("Sửa");
        Button btnXoa = new Button("Xóa");

        btnThem.setOnAction(e -> {
            try {
                String maMoi = diemThamQuanService.nextId();
                Optional<Map<String, String>> ketQua = FormDialogUtil.showForm("Thêm Điểm tham quan",
                        new String[]{"Mã điểm", "Tên điểm", "Địa điểm", "Nội dung", "Ý nghĩa"},
                        new String[]{maMoi, "", "", "", ""});
                if (ketQua.isPresent()) {
                    Map<String, String> v = ketQua.get();
                    DiemThamQuan dtq = new DiemThamQuan(v.get("Mã điểm"), v.get("Tên điểm"),
                            v.get("Địa điểm"), v.get("Nội dung"), v.get("Ý nghĩa"));
                    diemThamQuanService.themDiemThamQuan(dtq);
                    list.setAll(diemThamQuanService.findAll());
                    UiUtil.alert("Thông báo", "Đã thêm điểm tham quan thành công!");
                }
            } catch (IllegalArgumentException ex) {
                UiUtil.error(ex.getMessage());
            }
        });

        btnSua.setOnAction(e -> {
            DiemThamQuan selected = tableView.getSelectionModel().getSelectedItem();
            if (selected == null) {
                UiUtil.error("Vui lòng chọn điểm tham quan để sửa!");
                return;
            }
            Optional<Map<String, String>> ketQua = FormDialogUtil.showForm("Sửa Điểm tham quan",
                    new String[]{"Mã điểm", "Tên điểm", "Địa điểm", "Nội dung", "Ý nghĩa"},
                    new String[]{selected.getMaDiem(), selected.getTenDiem(), selected.getDiaDiem(),
                            selected.getNoiDung(), selected.getYNghia()});
            if (ketQua.isPresent()) {
                Map<String, String> v = ketQua.get();
                selected.setTenDiem(v.get("Tên điểm"));
                selected.setDiaDiem(v.get("Địa điểm"));
                selected.setNoiDung(v.get("Nội dung"));
                selected.setYNghia(v.get("Ý nghĩa"));
                try {
                    diemThamQuanService.suaDiemThamQuan(selected);
                    list.setAll(diemThamQuanService.findAll());
                    UiUtil.alert("Thông báo", "Đã sửa điểm tham quan thành công!");
                } catch (IllegalArgumentException ex) {
                    UiUtil.error(ex.getMessage());
                }
            }
        });

        btnXoa.setOnAction(e -> {
            DiemThamQuan selected = tableView.getSelectionModel().getSelectedItem();
            if (selected == null) {
                UiUtil.error("Vui lòng chọn điểm tham quan để xóa!");
                return;
            }
            if (UiUtil.confirm("Bạn có chắc muốn xóa điểm tham quan này?")) {
                try {
                    diemThamQuanService.xoaDiemThamQuan(selected.getMaDiem());
                    list.setAll(diemThamQuanService.findAll());
                    UiUtil.alert("Thông báo", "Đã xóa điểm tham quan thành công!");
                } catch (RuntimeException ex) {
                    UiUtil.error(ex.getMessage());
                }
            }
        });

        buttonBox.getChildren().addAll(btnThem, btnSua, btnXoa);
        content.getChildren().addAll(label, tableView, buttonBox);
        return content;
    }

    // ===================== PHUONG TIEN =====================

    private VBox createPhuongTienContent() {
        VBox content = new VBox(10);
        content.setPadding(new Insets(10));

        Label label = new Label("Quản lý Phương tiện");
        label.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;");

        TableView<PhuongTien> tableView = new TableView<>();
        ObservableList<PhuongTien> list = FXCollections.observableArrayList(phuongTienService.findAll());
        tableView.setItems(list);

        TableColumn<PhuongTien, String> colMa = new TableColumn<>("Mã");
        colMa.setCellValueFactory(new PropertyValueFactory<>("maPhuongTien"));
        colMa.setPrefWidth(80);

        TableColumn<PhuongTien, String> colLoai = new TableColumn<>("Loại");
        colLoai.setCellValueFactory(new PropertyValueFactory<>("loaiPhuongTien"));
        colLoai.setPrefWidth(150);

        TableColumn<PhuongTien, String> colBienSo = new TableColumn<>("Biển số");
        colBienSo.setCellValueFactory(new PropertyValueFactory<>("bienSo"));
        colBienSo.setPrefWidth(120);

        TableColumn<PhuongTien, String> colHang = new TableColumn<>("Hãng");
        colHang.setCellValueFactory(new PropertyValueFactory<>("hangSanXuat"));
        colHang.setPrefWidth(150);

        TableColumn<PhuongTien, Integer> colSoCho = new TableColumn<>("Số chỗ");
        colSoCho.setCellValueFactory(new PropertyValueFactory<>("soCho"));
        colSoCho.setPrefWidth(80);

        tableView.getColumns().addAll(colMa, colLoai, colBienSo, colHang, colSoCho);

        HBox buttonBox = new HBox(10);
        Button btnThem = new Button("Thêm");
        Button btnSua = new Button("Sửa");
        Button btnXoa = new Button("Xóa");

        btnThem.setOnAction(e -> {
            try {
                String maMoi = phuongTienService.nextId();
                Optional<Map<String, String>> ketQua = FormDialogUtil.showForm("Thêm Phương tiện",
                        new String[]{"Mã phương tiện", "Loại (Máy bay/Xe đò/Tàu hỏa/Xe ô tô)", "Biển số", "Hãng sản xuất", "Số chỗ"},
                        new String[]{maMoi, "Xe ô tô", "", "", "45"});
                if (ketQua.isPresent()) {
                    Map<String, String> v = ketQua.get();
                    PhuongTien pt = new PhuongTien(v.get("Mã phương tiện"), v.get("Loại (Máy bay/Xe đò/Tàu hỏa/Xe ô tô)"),
                            v.get("Biển số"), v.get("Hãng sản xuất"), Integer.parseInt(v.get("Số chỗ")));
                    phuongTienService.themPhuongTien(pt);
                    list.setAll(phuongTienService.findAll());
                    UiUtil.alert("Thông báo", "Đã thêm phương tiện thành công!");
                }
            } catch (NumberFormatException ex) {
                UiUtil.error("Số chỗ phải là số nguyên!");
            } catch (IllegalArgumentException ex) {
                UiUtil.error(ex.getMessage());
            }
        });

        btnSua.setOnAction(e -> {
            PhuongTien selected = tableView.getSelectionModel().getSelectedItem();
            if (selected == null) {
                UiUtil.error("Vui lòng chọn phương tiện để sửa!");
                return;
            }
            try {
                Optional<Map<String, String>> ketQua = FormDialogUtil.showForm("Sửa Phương tiện",
                        new String[]{"Mã phương tiện", "Loại", "Biển số", "Hãng sản xuất", "Số chỗ"},
                        new String[]{selected.getMaPhuongTien(), selected.getLoaiPhuongTien(),
                                selected.getBienSo(), selected.getHangSanXuat(), String.valueOf(selected.getSoCho())});
                if (ketQua.isPresent()) {
                    Map<String, String> v = ketQua.get();
                    selected.setLoaiPhuongTien(v.get("Loại"));
                    selected.setBienSo(v.get("Biển số"));
                    selected.setHangSanXuat(v.get("Hãng sản xuất"));
                    selected.setSoCho(Integer.parseInt(v.get("Số chỗ")));
                    phuongTienService.suaPhuongTien(selected);
                    list.setAll(phuongTienService.findAll());
                    UiUtil.alert("Thông báo", "Đã sửa phương tiện thành công!");
                }
            } catch (NumberFormatException ex) {
                UiUtil.error("Số chỗ phải là số nguyên!");
            } catch (IllegalArgumentException ex) {
                UiUtil.error(ex.getMessage());
            }
        });

        btnXoa.setOnAction(e -> {
            PhuongTien selected = tableView.getSelectionModel().getSelectedItem();
            if (selected == null) {
                UiUtil.error("Vui lòng chọn phương tiện để xóa!");
                return;
            }
            if (UiUtil.confirm("Bạn có chắc muốn xóa phương tiện này?")) {
                try {
                    phuongTienService.xoaPhuongTien(selected.getMaPhuongTien());
                    list.setAll(phuongTienService.findAll());
                    UiUtil.alert("Thông báo", "Đã xóa phương tiện thành công!");
                } catch (RuntimeException ex) {
                    UiUtil.error(ex.getMessage());
                }
            }
        });

        buttonBox.getChildren().addAll(btnThem, btnSua, btnXoa);
        content.getChildren().addAll(label, tableView, buttonBox);
        return content;
    }

    // ===================== NOI DUNG CHAN =====================

    private VBox createNoiDungChanContent() {
        VBox content = new VBox(10);
        content.setPadding(new Insets(10));

        Label label = new Label("Quản lý Nơi dừng chân");
        label.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;");

        TableView<NoiDungChan> tableView = new TableView<>();
        ObservableList<NoiDungChan> list = FXCollections.observableArrayList(noiDungChanService.findAll());
        tableView.setItems(list);

        TableColumn<NoiDungChan, String> colMa = new TableColumn<>("Mã");
        colMa.setCellValueFactory(new PropertyValueFactory<>("maNoiDungChan"));
        colMa.setPrefWidth(80);

        TableColumn<NoiDungChan, String> colTen = new TableColumn<>("Tên nơi");
        colTen.setCellValueFactory(new PropertyValueFactory<>("tenNoi"));
        colTen.setPrefWidth(200);

        TableColumn<NoiDungChan, String> colDiaDiem = new TableColumn<>("Địa điểm");
        colDiaDiem.setCellValueFactory(new PropertyValueFactory<>("diaDiem"));
        colDiaDiem.setPrefWidth(200);

        TableColumn<NoiDungChan, Boolean> colDoiPT = new TableColumn<>("Đổi PT");
        colDoiPT.setCellValueFactory(new PropertyValueFactory<>("doiPhuongTien"));
        colDoiPT.setPrefWidth(80);

        TableColumn<NoiDungChan, Boolean> colNaiAn = new TableColumn<>("Nhai ăn");
        colNaiAn.setCellValueFactory(new PropertyValueFactory<>("coNaiAn"));
        colNaiAn.setPrefWidth(80);

        TableColumn<NoiDungChan, Boolean> colKhachSan = new TableColumn<>("Khách sạn");
        colKhachSan.setCellValueFactory(new PropertyValueFactory<>("coKhachSan"));
        colKhachSan.setPrefWidth(80);

        TableColumn<NoiDungChan, Integer> colLoaiKS = new TableColumn<>("Loại KS");
        colLoaiKS.setCellValueFactory(new PropertyValueFactory<>("loaiKhachSan"));
        colLoaiKS.setPrefWidth(80);

        tableView.getColumns().addAll(colMa, colTen, colDiaDiem, colDoiPT, colNaiAn, colKhachSan, colLoaiKS);

        HBox buttonBox = new HBox(10);
        Button btnThem = new Button("Thêm");
        Button btnSua = new Button("Sửa");
        Button btnXoa = new Button("Xóa");

        btnThem.setOnAction(e -> {
            try {
                String maMoi = noiDungChanService.nextId();
                NoiDungChan ndc = showNoiDungChanDialog("Thêm Nơi dừng chân", maMoi, "", "", false, false, false, 0);
                if (ndc != null) {
                    noiDungChanService.themNoiDungChan(ndc);
                    list.setAll(noiDungChanService.findAll());
                    UiUtil.alert("Thông báo", "Đã thêm nơi dừng chân thành công!");
                }
            } catch (IllegalArgumentException ex) {
                UiUtil.error(ex.getMessage());
            }
        });

        btnSua.setOnAction(e -> {
            NoiDungChan selected = tableView.getSelectionModel().getSelectedItem();
            if (selected == null) {
                UiUtil.error("Vui lòng chọn nơi dừng chân để sửa!");
                return;
            }
            try {
                NoiDungChan ndc = showNoiDungChanDialog("Sửa Nơi dừng chân", selected.getMaNoiDungChan(),
                        selected.getTenNoi(), selected.getDiaDiem(), selected.isDoiPhuongTien(),
                        selected.isCoNaiAn(), selected.isCoKhachSan(), selected.getLoaiKhachSan());
                if (ndc != null) {
                    noiDungChanService.suaNoiDungChan(ndc);
                    list.setAll(noiDungChanService.findAll());
                    UiUtil.alert("Thông báo", "Đã sửa nơi dừng chân thành công!");
                }
            } catch (IllegalArgumentException ex) {
                UiUtil.error(ex.getMessage());
            }
        });

        btnXoa.setOnAction(e -> {
            NoiDungChan selected = tableView.getSelectionModel().getSelectedItem();
            if (selected == null) {
                UiUtil.error("Vui lòng chọn nơi dừng chân để xóa!");
                return;
            }
            if (UiUtil.confirm("Bạn có chắc muốn xóa nơi dừng chân này?")) {
                try {
                    noiDungChanService.xoaNoiDungChan(selected.getMaNoiDungChan());
                    list.setAll(noiDungChanService.findAll());
                    UiUtil.alert("Thông báo", "Đã xóa nơi dừng chân thành công!");
                } catch (RuntimeException ex) {
                    UiUtil.error(ex.getMessage());
                }
            }
        });

        buttonBox.getChildren().addAll(btnThem, btnSua, btnXoa);
        content.getChildren().addAll(label, tableView, buttonBox);
        return content;
    }

    /**
     * Dialog nhap lieu noi dung chan (co checkbox va loai khach san).
     * Tra ve null neu huy.
     */
    private NoiDungChan showNoiDungChanDialog(String title, String ma, String tenNoi, String diaDiem,
                                               boolean doiPT, boolean coNaiAn, boolean coKhachSan, int loaiKS) {
        Dialog<NoiDungChan> dialog = new Dialog<>();
        dialog.setTitle(title);
        dialog.setHeaderText(null);
        dialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(20, 150, 10, 10));

        TextField txtMa = new TextField(ma);
        TextField txtTen = new TextField(tenNoi);
        TextField txtDiaDiem = new TextField(diaDiem);
        CheckBox chkDoiPT = new CheckBox("Đổi phương tiện");
        chkDoiPT.setSelected(doiPT);
        CheckBox chkNaiAn = new CheckBox("Có nhà ăn");
        chkNaiAn.setSelected(coNaiAn);
        CheckBox chkKhachSan = new CheckBox("Có khách sạn");
        chkKhachSan.setSelected(coKhachSan);
        ComboBox<Integer> comboLoaiKS = new ComboBox<>();
        comboLoaiKS.getItems().addAll(0, 2, 3, 4, 5);
        comboLoaiKS.setValue(loaiKS);
        Label lblLoaiKS = new Label("(0 = không, 2-5 = sao)");

        grid.add(new Label("Mã nơi dừng chân:"), 0, 0);
        grid.add(txtMa, 1, 0);
        grid.add(new Label("Tên nơi:"), 0, 1);
        grid.add(txtTen, 1, 1);
        grid.add(new Label("Địa điểm:"), 0, 2);
        grid.add(txtDiaDiem, 1, 2);
        grid.add(chkDoiPT, 0, 3);
        grid.add(chkNaiAn, 0, 4);
        grid.add(chkKhachSan, 0, 5);
        grid.add(new Label("Loại khách sạn:"), 0, 6);
        grid.add(comboLoaiKS, 1, 6);
        grid.add(lblLoaiKS, 2, 6);

        dialog.getDialogPane().setContent(grid);
        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == ButtonType.OK) {
                NoiDungChan ndc = new NoiDungChan();
                ndc.setMaNoiDungChan(txtMa.getText().trim());
                ndc.setTenNoi(txtTen.getText().trim());
                ndc.setDiaDiem(txtDiaDiem.getText().trim());
                ndc.setDoiPhuongTien(chkDoiPT.isSelected());
                ndc.setCoNaiAn(chkNaiAn.isSelected());
                ndc.setCoKhachSan(chkKhachSan.isSelected());
                ndc.setLoaiKhachSan(comboLoaiKS.getValue());
                return ndc;
            }
            return null;
        });
        return dialog.showAndWait().orElse(null);
    }

    private Button createBackButton() {
        Button btnBack = new Button("Quay lại");
        btnBack.setStyle("-fx-font-size: 14px; -fx-font-family: 'Segoe UI';");
        btnBack.setOnAction(e -> stage.close());
        return btnBack;
    }

    public void show() {
        stage.show();
    }
}
