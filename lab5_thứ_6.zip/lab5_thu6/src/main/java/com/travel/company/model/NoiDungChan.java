package com.travel.company.model;

import java.io.Serializable;

public class NoiDungChan implements Serializable {
    private String maNoiDungChan;
    private String tenNoi;
    private String diaDiem;
    private boolean doiPhuongTien;
    private boolean coNaiAn;
    private boolean coKhachSan;
    private int loaiKhachSan; // 2, 3, 4, 5 sao

    public NoiDungChan() {
    }

    public NoiDungChan(String maNoiDungChan, String tenNoi, String diaDiem, boolean doiPhuongTien, boolean coNaiAn, boolean coKhachSan, int loaiKhachSan) {
        this.maNoiDungChan = maNoiDungChan;
        this.tenNoi = tenNoi;
        this.diaDiem = diaDiem;
        this.doiPhuongTien = doiPhuongTien;
        this.coNaiAn = coNaiAn;
        this.coKhachSan = coKhachSan;
        this.loaiKhachSan = loaiKhachSan;
    }

    // Getters and Setters
    public String getMaNoiDungChan() {
        return maNoiDungChan;
    }

    public void setMaNoiDungChan(String maNoiDungChan) {
        this.maNoiDungChan = maNoiDungChan;
    }

    public String getTenNoi() {
        return tenNoi;
    }

    public void setTenNoi(String tenNoi) {
        this.tenNoi = tenNoi;
    }

    public String getDiaDiem() {
        return diaDiem;
    }

    public void setDiaDiem(String diaDiem) {
        this.diaDiem = diaDiem;
    }

    public boolean isDoiPhuongTien() {
        return doiPhuongTien;
    }

    public void setDoiPhuongTien(boolean doiPhuongTien) {
        this.doiPhuongTien = doiPhuongTien;
    }

    public boolean isCoNaiAn() {
        return coNaiAn;
    }

    public void setCoNaiAn(boolean coNaiAn) {
        this.coNaiAn = coNaiAn;
    }

    public boolean isCoKhachSan() {
        return coKhachSan;
    }

    public void setCoKhachSan(boolean coKhachSan) {
        this.coKhachSan = coKhachSan;
    }

    public int getLoaiKhachSan() {
        return loaiKhachSan;
    }

    public void setLoaiKhachSan(int loaiKhachSan) {
        this.loaiKhachSan = loaiKhachSan;
    }

    @Override
    public String toString() {
        return maNoiDungChan + " - " + tenNoi;
    }
}
