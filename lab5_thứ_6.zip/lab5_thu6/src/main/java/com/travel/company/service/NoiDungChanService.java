package com.travel.company.service;

import com.travel.company.data.NoiDungChanDao;
import com.travel.company.model.NoiDungChan;

import java.sql.SQLException;
import java.util.List;

public class NoiDungChanService {

    private final NoiDungChanDao dao = new NoiDungChanDao();

    public List<NoiDungChan> findAll() {
        try {
            return dao.findAll();
        } catch (SQLException e) {
            throw new RuntimeException("Lay danh sach noi dung chan that bai: " + e.getMessage(), e);
        }
    }

    public NoiDungChan findById(String maNoiDungChan) {
        try {
            return dao.findById(maNoiDungChan);
        } catch (SQLException e) {
            throw new RuntimeException("Lay noi dung chan that bai: " + e.getMessage(), e);
        }
    }

    public String nextId() {
        try {
            return dao.nextId();
        } catch (SQLException e) {
            throw new RuntimeException("Sinh ma noi dung chan that bai: " + e.getMessage(), e);
        }
    }

    public void themNoiDungChan(NoiDungChan ndc) {
        validate(ndc);
        try {
            if (dao.findById(ndc.getMaNoiDungChan()) != null) {
                throw new IllegalArgumentException("Ma noi dung chan da ton tai!");
            }
            dao.insert(ndc);
        } catch (SQLException e) {
            throw new RuntimeException("Them noi dung chan that bai: " + e.getMessage(), e);
        }
    }

    public void suaNoiDungChan(NoiDungChan ndc) {
        validate(ndc);
        try {
            dao.update(ndc);
        } catch (SQLException e) {
            throw new RuntimeException("Sua noi dung chan that bai: " + e.getMessage(), e);
        }
    }

    public void xoaNoiDungChan(String maNoiDungChan) {
        try {
            dao.delete(maNoiDungChan);
        } catch (SQLException e) {
            throw new RuntimeException("Xoa noi dung chan that bai (co the con lien ket du lieu): " + e.getMessage(), e);
        }
    }

    private void validate(NoiDungChan ndc) {
        if (ndc.getMaNoiDungChan() == null || ndc.getMaNoiDungChan().trim().isEmpty()) {
            throw new IllegalArgumentException("Chua nhap ma noi dung chan!");
        }
        if (ndc.getTenNoi() == null || ndc.getTenNoi().trim().isEmpty()) {
            throw new IllegalArgumentException("Chua nhap ten noi dung chan!");
        }
    }
}
