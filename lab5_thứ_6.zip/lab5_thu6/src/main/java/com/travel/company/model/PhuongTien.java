package com.travel.company.model;

import java.io.Serializable;

public class PhuongTien implements Serializable {
    private String maPhuongTien;
    private String loaiPhuongTien; // Máy bay, xe đò, tàu hỏa, xe ô tô
    private String bienSo;
    private String hangSanXuat;
    private int soCho;

    public PhuongTien() {
    }

    public PhuongTien(String maPhuongTien, String loaiPhuongTien, String bienSo, String hangSanXuat, int soCho) {
        this.maPhuongTien = maPhuongTien;
        this.loaiPhuongTien = loaiPhuongTien;
        this.bienSo = bienSo;
        this.hangSanXuat = hangSanXuat;
        this.soCho = soCho;
    }

    // Getters and Setters
    public String getMaPhuongTien() {
        return maPhuongTien;
    }

    public void setMaPhuongTien(String maPhuongTien) {
        this.maPhuongTien = maPhuongTien;
    }

    public String getLoaiPhuongTien() {
        return loaiPhuongTien;
    }

    public void setLoaiPhuongTien(String loaiPhuongTien) {
        this.loaiPhuongTien = loaiPhuongTien;
    }

    public String getBienSo() {
        return bienSo;
    }

    public void setBienSo(String bienSo) {
        this.bienSo = bienSo;
    }

    public String getHangSanXuat() {
        return hangSanXuat;
    }

    public void setHangSanXuat(String hangSanXuat) {
        this.hangSanXuat = hangSanXuat;
    }

    public int getSoCho() {
        return soCho;
    }

    public void setSoCho(int soCho) {
        this.soCho = soCho;
    }

    @Override
    public String toString() {
        return maPhuongTien + " - " + loaiPhuongTien + " (" + bienSo + ")";
    }
}
