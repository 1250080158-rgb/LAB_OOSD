package com.travel.company.service;

import com.travel.company.data.KhachHangDao;
import com.travel.company.model.KhachHang;

import java.sql.SQLException;
import java.util.List;

public class KhachHangService {

    private final KhachHangDao dao = new KhachHangDao();

    public List<KhachHang> findAll() {
        try {
            return dao.findAll();
        } catch (SQLException e) {
            throw new RuntimeException("Lay danh sach khach hang that bai: " + e.getMessage(), e);
        }
    }

    public KhachHang findById(String maKhachHang) {
        try {
            return dao.findById(maKhachHang);
        } catch (SQLException e) {
            throw new RuntimeException("Lay khach hang that bai: " + e.getMessage(), e);
        }
    }

    public String nextId() {
        try {
            return dao.nextId();
        } catch (SQLException e) {
            throw new RuntimeException("Sinh ma khach hang that bai: " + e.getMessage(), e);
        }
    }

    public void themKhachHang(KhachHang kh) {
        validate(kh);
        try {
            if (dao.findById(kh.getMaKhachHang()) != null) {
                throw new IllegalArgumentException("Ma khach hang da ton tai!");
            }
            dao.insert(kh);
        } catch (SQLException e) {
            throw new RuntimeException("Them khach hang that bai: " + e.getMessage(), e);
        }
    }

    public void suaKhachHang(KhachHang kh) {
        validate(kh);
        try {
            dao.update(kh);
        } catch (SQLException e) {
            throw new RuntimeException("Sua khach hang that bai: " + e.getMessage(), e);
        }
    }

    public void xoaKhachHang(String maKhachHang) {
        try {
            dao.delete(maKhachHang);
        } catch (SQLException e) {
            throw new RuntimeException("Xoa khach hang that bai (co the con lien ket du lieu): " + e.getMessage(), e);
        }
    }

    private void validate(KhachHang kh) {
        if (kh.getMaKhachHang() == null || kh.getMaKhachHang().trim().isEmpty()) {
            throw new IllegalArgumentException("Chua nhap ma khach hang!");
        }
        if (kh.getHoTen() == null || kh.getHoTen().trim().isEmpty()) {
            throw new IllegalArgumentException("Chua nhap ho ten!");
        }
    }
}
