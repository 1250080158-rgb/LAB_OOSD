package com.travel.company.data;

import com.travel.company.model.NhanVien;

import java.sql.SQLException;
import java.util.List;

public class NhanVienDao {

    private static final RowMapper<NhanVien> MAPPER = rs -> new NhanVien(
            rs.getString("MaNhanVien"),
            rs.getString("HoTen"),
            rs.getString("CMND"),
            rs.getString("SoDienThoai"),
            rs.getString("DiaChi"),
            rs.getDouble("LuongCanBan"));

    public List<NhanVien> findAll() throws SQLException {
        return JdbcUtil.query("SELECT * FROM NHAN_VIEN ORDER BY MaNhanVien", MAPPER);
    }

    public NhanVien findById(String maNhanVien) throws SQLException {
        return JdbcUtil.queryOne("SELECT * FROM NHAN_VIEN WHERE MaNhanVien = ?", MAPPER, maNhanVien);
    }

    public void insert(NhanVien nv) throws SQLException {
        JdbcUtil.update("INSERT INTO NHAN_VIEN (MaNhanVien, HoTen, CMND, SoDienThoai, DiaChi, LuongCanBan) VALUES (?, ?, ?, ?, ?, ?)",
                nv.getMaNhanVien(), nv.getHoTen(), nv.getCmnd(), nv.getSoDienThoai(), nv.getDiaChi(), nv.getLuongCanBan());
    }

    public void update(NhanVien nv) throws SQLException {
        JdbcUtil.update("UPDATE NHAN_VIEN SET HoTen = ?, CMND = ?, SoDienThoai = ?, DiaChi = ?, LuongCanBan = ? WHERE MaNhanVien = ?",
                nv.getHoTen(), nv.getCmnd(), nv.getSoDienThoai(), nv.getDiaChi(), nv.getLuongCanBan(), nv.getMaNhanVien());
    }

    public void delete(String maNhanVien) throws SQLException {
        JdbcUtil.update("DELETE FROM NHAN_VIEN WHERE MaNhanVien = ?", maNhanVien);
    }

    public String nextId() throws SQLException {
        return JdbcUtil.nextId("NHAN_VIEN", "MaNhanVien", "NV", 3);
    }
}
