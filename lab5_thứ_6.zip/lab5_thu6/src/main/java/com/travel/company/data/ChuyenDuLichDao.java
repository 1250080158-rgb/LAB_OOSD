package com.travel.company.data;

import com.travel.company.model.ChuyenDuLich;

import java.sql.Date;
import java.sql.SQLException;
import java.util.List;

public class ChuyenDuLichDao {

    private static final RowMapper<ChuyenDuLich> MAPPER = rs -> {
        ChuyenDuLich c = new ChuyenDuLich();
        c.setMaChuyen(rs.getString("MaChuyen"));
        c.setMaTour(rs.getString("MaTour"));
        java.sql.Date ngayDi = rs.getDate("NgayDi");
        java.sql.Date ngayVe = rs.getDate("NgayVe");
        if (ngayDi != null) {
            c.setNgayDi(ngayDi.toLocalDate());
        }
        if (ngayVe != null) {
            c.setNgayVe(ngayVe.toLocalDate());
        }
        c.setSoNguoiMax(rs.getInt("SoNguoiMax"));
        c.setSoNguoiDaDangKy(rs.getInt("SoNguoiDaDangKy"));
        c.setTrangThai(rs.getString("TrangThai"));
        return c;
    };

    public List<ChuyenDuLich> findAll() throws SQLException {
        return JdbcUtil.query("SELECT * FROM CHUYEN_DU_LICH ORDER BY MaChuyen", MAPPER);
    }

    public List<ChuyenDuLich> findByTour(String maTour) throws SQLException {
        return JdbcUtil.query("SELECT * FROM CHUYEN_DU_LICH WHERE MaTour = ? ORDER BY NgayDi", MAPPER, maTour);
    }

    public ChuyenDuLich findById(String maChuyen) throws SQLException {
        return JdbcUtil.queryOne("SELECT * FROM CHUYEN_DU_LICH WHERE MaChuyen = ?", MAPPER, maChuyen);
    }

    public void insert(ChuyenDuLich c) throws SQLException {
        JdbcUtil.update("INSERT INTO CHUYEN_DU_LICH (MaChuyen, MaTour, NgayDi, NgayVe, SoNguoiMax, SoNguoiDaDangKy, TrangThai) VALUES (?, ?, ?, ?, ?, ?, ?)",
                c.getMaChuyen(), c.getMaTour(), Date.valueOf(c.getNgayDi()), Date.valueOf(c.getNgayVe()),
                c.getSoNguoiMax(), c.getSoNguoiDaDangKy(), c.getTrangThai());
    }

    public void update(ChuyenDuLich c) throws SQLException {
        JdbcUtil.update("UPDATE CHUYEN_DU_LICH SET MaTour = ?, NgayDi = ?, NgayVe = ?, SoNguoiMax = ?, SoNguoiDaDangKy = ?, TrangThai = ? WHERE MaChuyen = ?",
                c.getMaTour(), Date.valueOf(c.getNgayDi()), Date.valueOf(c.getNgayVe()),
                c.getSoNguoiMax(), c.getSoNguoiDaDangKy(), c.getTrangThai(), c.getMaChuyen());
    }

    public void delete(String maChuyen) throws SQLException {
        JdbcUtil.update("DELETE FROM CHUYEN_DU_LICH WHERE MaChuyen = ?", maChuyen);
    }

    public void updateSoNguoiDaDangKy(String maChuyen, int soNguoi) throws SQLException {
        JdbcUtil.update("UPDATE CHUYEN_DU_LICH SET SoNguoiDaDangKy = ? WHERE MaChuyen = ?", soNguoi, maChuyen);
    }

    public void updateTrangThai(String maChuyen, String trangThai) throws SQLException {
        JdbcUtil.update("UPDATE CHUYEN_DU_LICH SET TrangThai = ? WHERE MaChuyen = ?", trangThai, maChuyen);
    }

    public String nextId() throws SQLException {
        return JdbcUtil.nextId("CHUYEN_DU_LICH", "MaChuyen", "C", 3);
    }
}
