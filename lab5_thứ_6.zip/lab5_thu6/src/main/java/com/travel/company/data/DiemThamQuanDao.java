package com.travel.company.data;

import com.travel.company.model.DiemThamQuan;

import java.sql.SQLException;
import java.util.List;

public class DiemThamQuanDao {

    private static final RowMapper<DiemThamQuan> MAPPER = rs -> new DiemThamQuan(
            rs.getString("MaDiem"),
            rs.getString("TenDiem"),
            rs.getString("DiaDiem"),
            rs.getString("NoiDung"),
            rs.getString("YNghia"));

    public List<DiemThamQuan> findAll() throws SQLException {
        return JdbcUtil.query("SELECT * FROM DIEM_THAM_QUAN ORDER BY MaDiem", MAPPER);
    }

    public DiemThamQuan findById(String maDiem) throws SQLException {
        return JdbcUtil.queryOne("SELECT * FROM DIEM_THAM_QUAN WHERE MaDiem = ?", MAPPER, maDiem);
    }

    public void insert(DiemThamQuan dtq) throws SQLException {
        JdbcUtil.update("INSERT INTO DIEM_THAM_QUAN (MaDiem, TenDiem, DiaDiem, NoiDung, YNghia) VALUES (?, ?, ?, ?, ?)",
                dtq.getMaDiem(), dtq.getTenDiem(), dtq.getDiaDiem(), dtq.getNoiDung(), dtq.getYNghia());
    }

    public void update(DiemThamQuan dtq) throws SQLException {
        JdbcUtil.update("UPDATE DIEM_THAM_QUAN SET TenDiem = ?, DiaDiem = ?, NoiDung = ?, YNghia = ? WHERE MaDiem = ?",
                dtq.getTenDiem(), dtq.getDiaDiem(), dtq.getNoiDung(), dtq.getYNghia(), dtq.getMaDiem());
    }

    public void delete(String maDiem) throws SQLException {
        JdbcUtil.update("DELETE FROM DIEM_THAM_QUAN WHERE MaDiem = ?", maDiem);
    }

    public String nextId() throws SQLException {
        return JdbcUtil.nextId("DIEM_THAM_QUAN", "MaDiem", "DT", 3);
    }
}
