package com.travel.company.model;

import java.io.Serializable;
import java.time.LocalDate;

public class ChuyenDuLich implements Serializable {
    private String maChuyen;
    private String maTour;
    private LocalDate ngayDi;
    private LocalDate ngayVe;
    private int soNguoiMax;
    private int soNguoiDaDangKy;
    private String trangThai; // "Chưa đi", "Đang đi", "Đã kết thúc", "Đã hủy"

    public ChuyenDuLich() {
        this.trangThai = "Chưa đi";
        this.soNguoiDaDangKy = 0;
    }

    public ChuyenDuLich(String maChuyen, String maTour, LocalDate ngayDi, LocalDate ngayVe, int soNguoiMax) {
        this();
        this.maChuyen = maChuyen;
        this.maTour = maTour;
        this.ngayDi = ngayDi;
        this.ngayVe = ngayVe;
        this.soNguoiMax = soNguoiMax;
    }

    // Getters and Setters
    public String getMaChuyen() {
        return maChuyen;
    }

    public void setMaChuyen(String maChuyen) {
        this.maChuyen = maChuyen;
    }

    public String getMaTour() {
        return maTour;
    }

    public void setMaTour(String maTour) {
        this.maTour = maTour;
    }

    public LocalDate getNgayDi() {
        return ngayDi;
    }

    public void setNgayDi(LocalDate ngayDi) {
        this.ngayDi = ngayDi;
    }

    public LocalDate getNgayVe() {
        return ngayVe;
    }

    public void setNgayVe(LocalDate ngayVe) {
        this.ngayVe = ngayVe;
    }

    public int getSoNguoiMax() {
        return soNguoiMax;
    }

    public void setSoNguoiMax(int soNguoiMax) {
        this.soNguoiMax = soNguoiMax;
    }

    public int getSoNguoiDaDangKy() {
        return soNguoiDaDangKy;
    }

    public void setSoNguoiDaDangKy(int soNguoiDaDangKy) {
        this.soNguoiDaDangKy = soNguoiDaDangKy;
    }

    public String getTrangThai() {
        return trangThai;
    }

    public void setTrangThai(String trangThai) {
        this.trangThai = trangThai;
    }

    public int getConLai() {
        return soNguoiMax - soNguoiDaDangKy;
    }

    @Override
    public String toString() {
        return maChuyen + " - " + ngayDi + " (Còn " + getConLai() + " chỗ)";
    }
}
