package com.travel.company.ui;

import com.travel.company.model.*;
import com.travel.company.service.*;
import com.travel.company.util.UiUtil;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.time.LocalDate;

public class DangKyChuyenFrame {
    private Stage stage;

    private final DangKyChuyenService dangKyChuyenService = new DangKyChuyenService();
    private final KhachHangService khachHangService = new KhachHangService();
    private final ChuyenDuLichService chuyenDuLichService = new ChuyenDuLichService();
    private final TourService tourService = new TourService();
    private ObservableList<DangKyChuyen> dangKyChuyenList;

    public DangKyChuyenFrame() {
        stage = new Stage();
        stage.setTitle("Đăng ký chuyến");

        VBox root = new VBox(10);
        root.setPadding(new Insets(10));

        Label label = new Label("Đăng ký chuyến (Khách lẻ < 12 người)");
        label.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;");

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(10));

        TextField txtMaPhieu = new TextField();
        txtMaPhieu.setPromptText("Tự động nếu để trống");
        grid.add(new Label("Mã phiếu:"), 0, 0);
        grid.add(txtMaPhieu, 1, 0);

        ComboBox<KhachHang> comboKhachHang = new ComboBox<>();
        ObservableList<KhachHang> khachHangList = FXCollections.observableArrayList(khachHangService.findAll());
        comboKhachHang.setItems(khachHangList);
        comboKhachHang.setPromptText("Chọn khách hàng");
        grid.add(new Label("Khách hàng:"), 0, 1);
        grid.add(comboKhachHang, 1, 1);

        ComboBox<ChuyenDuLich> comboChuyen = new ComboBox<>();
        ObservableList<ChuyenDuLich> chuyenList = FXCollections.observableArrayList(chuyenDuLichService.findAll());
        comboChuyen.setItems(chuyenList);
        comboChuyen.setPromptText("Chọn chuyến (theo lịch công ty)");
        comboChuyen.setCellFactory(lv -> new ListCell<ChuyenDuLich>() {
            @Override
            protected void updateItem(ChuyenDuLich c, boolean empty) {
                super.updateItem(c, empty);
                if (empty || c == null) {
                    setText(null);
                } else {
                    setText(c.getMaChuyen() + " - " + c.getNgayDi() + " (còn " + c.getConLai() + " chỗ)");
                }
            }
        });
        comboChuyen.setButtonCell(new ListCell<ChuyenDuLich>() {
            @Override
            protected void updateItem(ChuyenDuLich c, boolean empty) {
                super.updateItem(c, empty);
                if (empty || c == null) {
                    setText(null);
                } else {
                    setText(c.getMaChuyen() + " - " + c.getNgayDi() + " (còn " + c.getConLai() + " chỗ)");
                }
            }
        });
        grid.add(new Label("Chuyến:"), 0, 2);
        grid.add(comboChuyen, 1, 2);

        DatePicker datePicker = new DatePicker();
        datePicker.setPromptText("Ngày đăng ký");
        datePicker.setValue(LocalDate.now());
        grid.add(new Label("Ngày đăng ký:"), 0, 3);
        grid.add(datePicker, 1, 3);

        TextField txtThanhTien = new TextField();
        txtThanhTien.setPromptText("Thành tiền (tự tính từ tour)");
        txtThanhTien.setEditable(false);
        grid.add(new Label("Thành tiền:"), 0, 4);
        grid.add(txtThanhTien, 1, 4);

        TextField txtDiemBanVe = new TextField();
        txtDiemBanVe.setPromptText("Điểm bán vé");
        grid.add(new Label("Điểm bán vé:"), 0, 5);
        grid.add(txtDiemBanVe, 1, 5);

        TextField txtDiaDiemDon = new TextField();
        txtDiaDiemDon.setPromptText("Địa điểm đón theo quy định");
        grid.add(new Label("Địa điểm đón:"), 0, 6);
        grid.add(txtDiaDiemDon, 1, 6);

        // Tu dong tinh thanh tien khi chon chuyen
        comboChuyen.setOnAction(e -> {
            ChuyenDuLich chuyen = comboChuyen.getValue();
            if (chuyen != null) {
                Tour tour = tourService.findById(chuyen.getMaTour());
                if (tour != null) {
                    txtThanhTien.setText(String.valueOf((long) tour.getDonGia()));
                }
            }
        });

        HBox buttonBox = new HBox(10);
        Button btnDangKy = new Button("Đăng ký");
        Button btnXoaForm = new Button("Xóa form");

        btnDangKy.setOnAction(e -> {
            try {
                String maPhieu = txtMaPhieu.getText().trim();
                if (maPhieu.isEmpty()) {
                    maPhieu = dangKyChuyenService.nextId();
                }

                KhachHang khachHang = comboKhachHang.getValue();
                ChuyenDuLich chuyen = comboChuyen.getValue();
                LocalDate ngayDangKy = datePicker.getValue();
                double thanhTien = Double.parseDouble(txtThanhTien.getText().trim());

                DangKyChuyen dangKy = new DangKyChuyen();
                dangKy.setMaPhieuChuyen(maPhieu);
                dangKy.setMaKhachHang(khachHang != null ? khachHang.getMaKhachHang() : null);
                dangKy.setMaChuyen(chuyen != null ? chuyen.getMaChuyen() : null);
                dangKy.setNgayDangKy(ngayDangKy);
                dangKy.setThanhTien(thanhTien);
                dangKy.setDiemBanVe(txtDiemBanVe.getText().trim());
                dangKy.setDiaDiemDon(txtDiaDiemDon.getText().trim());

                dangKyChuyenService.dangKyChuyen(dangKy);
                dangKyChuyenList.setAll(dangKyChuyenService.findAll());
                UiUtil.alert("Thông báo", "Đăng ký chuyến thành công! Mã phiếu: " + maPhieu);
                xoaForm(txtMaPhieu, comboKhachHang, comboChuyen, datePicker, txtThanhTien, txtDiemBanVe, txtDiaDiemDon);
            } catch (NumberFormatException ex) {
                UiUtil.error("Vui lòng nhập đúng định dạng số!");
            } catch (IllegalArgumentException ex) {
                UiUtil.error(ex.getMessage());
            } catch (RuntimeException ex) {
                UiUtil.error(ex.getMessage());
            }
        });

        btnXoaForm.setOnAction(e -> xoaForm(txtMaPhieu, comboKhachHang, comboChuyen, datePicker,
                txtThanhTien, txtDiemBanVe, txtDiaDiemDon));

        buttonBox.getChildren().addAll(btnDangKy, btnXoaForm);

        Label lblList = new Label("Danh sách chuyến đã đăng ký:");
        lblList.setStyle("-fx-font-weight: bold;");

        TableView<DangKyChuyen> tableView = new TableView<>();
        dangKyChuyenList = FXCollections.observableArrayList(dangKyChuyenService.findAll());
        tableView.setItems(dangKyChuyenList);

        TableColumn<DangKyChuyen, String> colMa = new TableColumn<>("Mã phiếu");
        colMa.setCellValueFactory(new PropertyValueFactory<>("maPhieuChuyen"));
        colMa.setPrefWidth(100);

        TableColumn<DangKyChuyen, String> colKhachHang = new TableColumn<>("Khách hàng");
        colKhachHang.setCellValueFactory(new PropertyValueFactory<>("maKhachHang"));
        colKhachHang.setPrefWidth(120);

        TableColumn<DangKyChuyen, String> colChuyen = new TableColumn<>("Chuyến");
        colChuyen.setCellValueFactory(new PropertyValueFactory<>("maChuyen"));
        colChuyen.setPrefWidth(100);

        TableColumn<DangKyChuyen, LocalDate> colNgayDangKy = new TableColumn<>("Ngày đăng ký");
        colNgayDangKy.setCellValueFactory(new PropertyValueFactory<>("ngayDangKy"));
        colNgayDangKy.setPrefWidth(120);

        TableColumn<DangKyChuyen, Double> colThanhTien = new TableColumn<>("Thành tiền");
        colThanhTien.setCellValueFactory(new PropertyValueFactory<>("thanhTien"));
        colThanhTien.setPrefWidth(120);

        TableColumn<DangKyChuyen, String> colTrangThai = new TableColumn<>("Trạng thái");
        colTrangThai.setCellValueFactory(new PropertyValueFactory<>("trangThai"));
        colTrangThai.setPrefWidth(120);

        tableView.getColumns().addAll(colMa, colKhachHang, colChuyen, colNgayDangKy, colThanhTien, colTrangThai);

        HBox listButtonBox = new HBox(10);
        Button btnThanhToan = new Button("Thanh toán");
        Button btnHuy = new Button("Hủy");
        Button btnXoa = new Button("Xóa");

        btnThanhToan.setOnAction(e -> thanhToan(tableView));
        btnHuy.setOnAction(e -> huyChuyen(tableView));
        btnXoa.setOnAction(e -> xoaDangKy(tableView));

        listButtonBox.getChildren().addAll(btnThanhToan, btnHuy, btnXoa);

        Button btnBack = new Button("Quay lại");
        btnBack.setStyle("-fx-font-size: 14px; -fx-font-family: 'Segoe UI';");
        btnBack.setOnAction(e -> stage.close());

        root.getChildren().addAll(label, grid, buttonBox, lblList, tableView, listButtonBox, btnBack);

        Scene scene = new Scene(root, 900, 700);
        stage.setScene(scene);
    }

    private void xoaForm(TextField txtMaPhieu, ComboBox<KhachHang> comboKhachHang,
                         ComboBox<ChuyenDuLich> comboChuyen, DatePicker datePicker,
                         TextField txtThanhTien, TextField txtDiemBanVe, TextField txtDiaDiemDon) {
        txtMaPhieu.clear();
        comboKhachHang.setValue(null);
        comboChuyen.setValue(null);
        datePicker.setValue(LocalDate.now());
        txtThanhTien.clear();
        txtDiemBanVe.clear();
        txtDiaDiemDon.clear();
    }

    private void thanhToan(TableView<DangKyChuyen> tableView) {
        DangKyChuyen selected = tableView.getSelectionModel().getSelectedItem();
        if (selected == null) {
            UiUtil.error("Vui lòng chọn chuyến để thanh toán!");
            return;
        }
        if (UiUtil.confirm("Bạn có chắc muốn thanh toán chuyến này?")) {
            try {
                dangKyChuyenService.thanhToan(selected.getMaPhieuChuyen());
                selected.setTrangThai("Đã thanh toán");
                dangKyChuyenList.setAll(dangKyChuyenService.findAll());
                UiUtil.alert("Thông báo", "Đã thanh toán thành công!");
            } catch (RuntimeException ex) {
                UiUtil.error(ex.getMessage());
            }
        }
    }

    private void huyChuyen(TableView<DangKyChuyen> tableView) {
        DangKyChuyen selected = tableView.getSelectionModel().getSelectedItem();
        if (selected == null) {
            UiUtil.error("Vui lòng chọn chuyến để hủy!");
            return;
        }
        if (UiUtil.confirm("Bạn có chắc muốn hủy chuyến này?")) {
            try {
                dangKyChuyenService.huyChuyen(selected.getMaPhieuChuyen());
                dangKyChuyenList.setAll(dangKyChuyenService.findAll());
                UiUtil.alert("Thông báo", "Đã hủy chuyến thành công!");
            } catch (RuntimeException ex) {
                UiUtil.error(ex.getMessage());
            }
        }
    }

    private void xoaDangKy(TableView<DangKyChuyen> tableView) {
        DangKyChuyen selected = tableView.getSelectionModel().getSelectedItem();
        if (selected == null) {
            UiUtil.error("Vui lòng chọn phiếu đăng ký để xóa!");
            return;
        }
        if (UiUtil.confirm("Bạn có chắc muốn xóa phiếu đăng ký này?")) {
            try {
                dangKyChuyenService.xoaDangKy(selected.getMaPhieuChuyen());
                dangKyChuyenList.setAll(dangKyChuyenService.findAll());
                UiUtil.alert("Thông báo", "Đã xóa phiếu đăng ký thành công!");
            } catch (RuntimeException ex) {
                UiUtil.error(ex.getMessage());
            }
        }
    }

    public void show() {
        stage.show();
    }
}
