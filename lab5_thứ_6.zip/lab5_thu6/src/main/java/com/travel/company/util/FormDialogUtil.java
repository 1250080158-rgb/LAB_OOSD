package com.travel.company.util;

import javafx.geometry.Insets;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Dialog;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;

public class FormDialogUtil {

    private FormDialogUtil() {
    }

    /**
     * Hien thi dialog nhap lieu nhieu truong.
     *
     * @param title  tieu de
     * @param labels ten cac truong
     * @param values gia tri mac dinh (co the null)
     * @return gia tri nhap duoc, hoac rong neu huy
     */
    public static Optional<Map<String, String>> showForm(String title, String[] labels, String[] values) {
        Dialog<Map<String, String>> dialog = new Dialog<>();
        dialog.setTitle(title);
        dialog.setHeaderText(null);
        dialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(20, 150, 10, 10));

        TextField[] fields = new TextField[labels.length];
        for (int i = 0; i < labels.length; i++) {
            Label lbl = new Label(labels[i]);
            grid.add(lbl, 0, i);
            fields[i] = new TextField(values != null && i < values.length ? values[i] : "");
            grid.add(fields[i], 1, i);
        }

        dialog.getDialogPane().setContent(grid);
        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == ButtonType.OK) {
                Map<String, String> result = new LinkedHashMap<>();
                for (int i = 0; i < labels.length; i++) {
                    result.put(labels[i], fields[i].getText().trim());
                }
                return result;
            }
            return null;
        });
        return dialog.showAndWait();
    }
}
