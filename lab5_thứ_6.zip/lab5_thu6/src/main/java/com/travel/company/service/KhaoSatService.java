package com.travel.company.service;

import com.travel.company.data.KhaoSatDao;
import com.travel.company.model.KhaoSat;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;

public class KhaoSatService {

    private final KhaoSatDao dao = new KhaoSatDao();

    public List<KhaoSat> findAll() {
        try {
            return dao.findAll();
        } catch (SQLException e) {
            throw new RuntimeException("Lay danh sach khao sat that bai: " + e.getMessage(), e);
        }
    }

    public KhaoSat findById(String maKhaoSat) {
        try {
            return dao.findById(maKhaoSat);
        } catch (SQLException e) {
            throw new RuntimeException("Lay khao sat that bai: " + e.getMessage(), e);
        }
    }

    public String nextId() {
        try {
            return dao.nextId();
        } catch (SQLException e) {
            throw new RuntimeException("Sinh ma khao sat that bai: " + e.getMessage(), e);
        }
    }

    public void luuKhaoSat(KhaoSat ks) {
        validate(ks);
        try {
            if (dao.findById(ks.getMaKhaoSat()) != null) {
                throw new IllegalArgumentException("Ma khao sat da ton tai!");
            }
            dao.insert(ks);
        } catch (SQLException e) {
            throw new RuntimeException("Luu khao sat that bai: " + e.getMessage(), e);
        }
    }

    public void suaKhaoSat(KhaoSat ks) {
        validate(ks);
        try {
            dao.update(ks);
        } catch (SQLException e) {
            throw new RuntimeException("Sua khao sat that bai: " + e.getMessage(), e);
        }
    }

    public void xoaKhaoSat(String maKhaoSat) {
        try {
            dao.delete(maKhaoSat);
        } catch (SQLException e) {
            throw new RuntimeException("Xoa khao sat that bai: " + e.getMessage(), e);
        }
    }

    private void validate(KhaoSat ks) {
        if (ks.getMaKhaoSat() == null || ks.getMaKhaoSat().trim().isEmpty()) {
            throw new IllegalArgumentException("Chua nhap ma khao sat!");
        }
        if (ks.getLoaiKhaoSat() == null || ks.getLoaiKhaoSat().trim().isEmpty()) {
            throw new IllegalArgumentException("Chua chon loai khao sat!");
        }
        if (ks.getMaDoanHoacChuyen() == null || ks.getMaDoanHoacChuyen().trim().isEmpty()) {
            throw new IllegalArgumentException("Chua chon doan/chuyen!");
        }
        if (ks.getNgayKhaoSat() == null) {
            throw new IllegalArgumentException("Chua chon ngay khao sat!");
        }
        if (ks.getPhanHoi() == null || ks.getPhanHoi().trim().isEmpty()) {
            throw new IllegalArgumentException("Chua nhap phan hoi!");
        }
        if (ks.getDanhGia() < 1 || ks.getDanhGia() > 5) {
            throw new IllegalArgumentException("Danh gia phai tu 1 den 5 sao!");
        }
    }
}
