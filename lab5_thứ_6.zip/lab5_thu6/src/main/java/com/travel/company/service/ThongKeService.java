package com.travel.company.service;

import com.travel.company.data.JdbcUtil;

import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Thong ke du lieu bang SQL truy van truc tiep tren CSDL.
 */
public class ThongKeService {

    /**
     * Doanh thu theo tour: tien coc cua cac doan "Da ket thuc"
     * + thanh tien cua cac dang ky chuyen "Da thanh toan".
     */
    public Map<String, Double> doanhThuTour() {
        Map<String, Double> ketQua = new LinkedHashMap<>();
        try {
            List<String> tours = JdbcUtil.query(
                    "SELECT MaTour, TenTour FROM TOUR ORDER BY MaTour",
                    rs -> rs.getString("MaTour") + "|" + rs.getString("TenTour"));
            for (String t : tours) {
                String[] parts = t.split("\\|", 2);
                String maTour = parts[0];
                String tenTour = parts[1];
                Double doanhThu = JdbcUtil.queryOne(
                        "SELECT COALESCE((SELECT SUM(TienCoc) FROM DANG_KY_DOAN WHERE MaTour = ? AND TrangThai = N'Đã kết thúc'), 0) + " +
                        "COALESCE((SELECT SUM(dkc.ThanhTien) FROM DANG_KY_CHUYEN dkc JOIN CHUYEN_DU_LICH cdl ON dkc.MaChuyen = cdl.MaChuyen " +
                        "WHERE cdl.MaTour = ? AND dkc.TrangThai = N'Đã thanh toán'), 0) AS doanh_thu",
                        rs -> rs.getDouble("doanh_thu"), maTour, maTour);
                ketQua.put(tenTour, doanhThu != null ? doanhThu : 0.0);
            }
        } catch (SQLException e) {
            throw new RuntimeException("Thong ke doanh thu that bai: " + e.getMessage(), e);
        }
        return ketQua;
    }

    /**
     * Thong ke so khach tham gia theo tour (doan + chuyen).
     */
    public Map<String, Integer> thamGiaTour() {
        Map<String, Integer> ketQua = new LinkedHashMap<>();
        try {
            List<String> tours = JdbcUtil.query(
                    "SELECT MaTour, TenTour FROM TOUR ORDER BY MaTour",
                    rs -> rs.getString("MaTour") + "|" + rs.getString("TenTour"));
            for (String t : tours) {
                String[] parts = t.split("\\|", 2);
                String maTour = parts[0];
                String tenTour = parts[1];
                Integer soKhach = JdbcUtil.queryOne(
                        "SELECT COALESCE((SELECT SUM(SoNguoiDi) FROM DANG_KY_DOAN WHERE MaTour = ?), 0) + " +
                        "COALESCE((SELECT SUM(SoNguoiDaDangKy) FROM CHUYEN_DU_LICH WHERE MaTour = ?), 0) AS so_khach",
                        rs -> rs.getInt("so_khach"), maTour, maTour);
                ketQua.put(tenTour, soKhach != null ? soKhach : 0);
            }
        } catch (SQLException e) {
            throw new RuntimeException("Thong ke tham gia tour that bai: " + e.getMessage(), e);
        }
        return ketQua;
    }

    /**
     * Thong ke khach hang: tong so, da di tour, chua di tour.
     */
    public int[] thongKeKhachHang() {
        try {
            int tong = JdbcUtil.queryOne("SELECT COUNT(*) AS c FROM KHACH_HANG", rs -> rs.getInt("c"));
            int daDi = JdbcUtil.queryOne(
                    "SELECT COUNT(DISTINCT kh.MaKhachHang) AS c FROM KHACH_HANG kh " +
                    "WHERE EXISTS (SELECT 1 FROM DANG_KY_CHUYEN dkc WHERE dkc.MaKhachHang = kh.MaKhachHang) " +
                    "OR EXISTS (SELECT 1 FROM DANG_KY_DOAN dkd WHERE dkd.NguoiDaiDien = kh.HoTen)",
                    rs -> rs.getInt("c"));
            return new int[]{tong, daDi, tong - daDi};
        } catch (SQLException e) {
            throw new RuntimeException("Thong ke khach hang that bai: " + e.getMessage(), e);
        }
    }

    /**
     * Hieu suat nhan vien: so tour da dan, luong tour, tong luong.
     */
    public List<Object[]> hieuSuatNhanVien() {
        try {
            return JdbcUtil.query(
                    "SELECT nv.MaNhanVien, nv.HoTen, nv.LuongCanBan, " +
                    "COUNT(pc.MaPhanCong) AS so_tour, COALESCE(SUM(pc.LuongTour), 0) AS luong_tour " +
                    "FROM NHAN_VIEN nv LEFT JOIN PHAN_CONG_NHAN_VIEN pc ON pc.MaNhanVien = nv.MaNhanVien " +
                    "GROUP BY nv.MaNhanVien, nv.HoTen, nv.LuongCanBan ORDER BY nv.MaNhanVien",
                    rs -> new Object[]{
                            rs.getString("MaNhanVien"),
                            rs.getString("HoTen"),
                            rs.getDouble("LuongCanBan"),
                            rs.getInt("so_tour"),
                            rs.getDouble("luong_tour")
                    });
        } catch (SQLException e) {
            throw new RuntimeException("Thong ke hieu suat nhan vien that bai: " + e.getMessage(), e);
        }
    }

    /**
     * Do pho bien diem tham quan: so tour co diem tham quan do.
     */
    public List<Object[]> doPhoBienDiemThamQuan() {
        try {
            return JdbcUtil.query(
                    "SELECT dtq.MaDiem, dtq.TenDiem, dtq.DiaDiem, COUNT(tdt.MaTour) AS so_tour " +
                    "FROM DIEM_THAM_QUAN dtq LEFT JOIN TOUR_DIEM_THAM_QUAN tdt ON tdt.MaDiem = dtq.MaDiem " +
                    "GROUP BY dtq.MaDiem, dtq.TenDiem, dtq.DiaDiem ORDER BY so_tour DESC, dtq.TenDiem",
                    rs -> new Object[]{
                            rs.getString("MaDiem"),
                            rs.getString("TenDiem"),
                            rs.getString("DiaDiem"),
                            rs.getInt("so_tour")
                    });
        } catch (SQLException e) {
            throw new RuntimeException("Thong ke do pho bien diem tham quan that bai: " + e.getMessage(), e);
        }
    }

    /**
     * Tong quan he thong: so luong tung loai.
     */
    public Map<String, Integer> tongQuan() {
        Map<String, Integer> ketQua = new LinkedHashMap<>();
        try {
            ketQua.put("Tour", dem("TOUR"));
            ketQua.put("Khach hang", dem("KHACH_HANG"));
            ketQua.put("Nhan vien", dem("NHAN_VIEN"));
            ketQua.put("Diem tham quan", dem("DIEM_THAM_QUAN"));
            ketQua.put("Phuong tien", dem("PHUONG_TIEN"));
            ketQua.put("Noi dung chan", dem("NOI_DUNG_CHAN"));
            ketQua.put("Chuyen du lich", dem("CHUYEN_DU_LICH"));
            ketQua.put("Dang ky doan", dem("DANG_KY_DOAN"));
            ketQua.put("Dang ky chuyen", dem("DANG_KY_CHUYEN"));
            ketQua.put("Phan cong nhan vien", dem("PHAN_CONG_NHAN_VIEN"));
            ketQua.put("Khao sat", dem("KHAO_SAT"));
        } catch (SQLException e) {
            throw new RuntimeException("Thong ke tong quan that bai: " + e.getMessage(), e);
        }
        return ketQua;
    }

    /**
     * Diem trung binh khao sat theo doan/chuyen.
     */
    public double diemTrungBinhKhaoSat() {
        try {
            Double tb = JdbcUtil.queryOne("SELECT AVG(DanhGia) AS tb FROM KHAO_SAT", rs -> {
                double v = rs.getDouble("tb");
                return rs.wasNull() ? null : v;
            });
            return tb != null ? tb : 0.0;
        } catch (SQLException e) {
            throw new RuntimeException("Tinh diem trung binh that bai: " + e.getMessage(), e);
        }
    }

    private int dem(String table) throws SQLException {
        Integer c = JdbcUtil.queryOne("SELECT COUNT(*) AS c FROM " + table, rs -> rs.getInt("c"));
        return c != null ? c : 0;
    }
}
