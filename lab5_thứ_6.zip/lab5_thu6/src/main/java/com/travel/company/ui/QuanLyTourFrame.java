package com.travel.company.ui;

import com.travel.company.model.*;
import com.travel.company.service.*;
import com.travel.company.util.FormDialogUtil;
import com.travel.company.util.UiUtil;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.time.LocalDate;
import java.util.Map;
import java.util.Optional;

public class QuanLyTourFrame {
    private Stage stage;
    private Tour selectedTour;

    private final TourService tourService = new TourService();
    private final ChuyenDuLichService chuyenDuLichService = new ChuyenDuLichService();
    private final NoiDungChanService noiDungChanService = new NoiDungChanService();
    private final PhuongTienService phuongTienService = new PhuongTienService();
    private final DiemThamQuanService diemThamQuanService = new DiemThamQuanService();

    private TabPane tabPane;
    private Label lblTourDetails;
    private TextArea txtTourDetails;

    public QuanLyTourFrame() {
        stage = new Stage();
        stage.setTitle("Quản lý Tour");

        VBox root = new VBox(10);
        root.setPadding(new Insets(10));

        Label label = new Label("Quản lý Tour");
        label.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;");

        ComboBox<Tour> comboTour = new ComboBox<>();
        ObservableList<Tour> tourList = FXCollections.observableArrayList(tourService.findAll());
        comboTour.setItems(tourList);
        comboTour.setPromptText("Chọn Tour");

        lblTourDetails = new Label("Chi tiết Tour:");
        lblTourDetails.setStyle("-fx-font-weight: bold;");

        txtTourDetails = new TextArea();
        txtTourDetails.setEditable(false);
        txtTourDetails.setPrefHeight(80);

        tabPane = new TabPane();

        comboTour.setOnAction(e -> {
            selectedTour = comboTour.getValue();
            if (selectedTour != null) {
                selectedTour = tourService.findById(selectedTour.getMaTour());
                String details = String.format("Mã: %s\nTên: %s\nSố ngày: %d\nSố đêm: %d\nĐơn giá: %.0f VNĐ",
                        selectedTour.getMaTour(), selectedTour.getTenTour(),
                        selectedTour.getSoNgay(), selectedTour.getSoDem(), selectedTour.getDonGia());
                txtTourDetails.setText(details);
                taiLaiTabs();
            } else {
                txtTourDetails.clear();
                tabPane.getTabs().clear();
            }
        });

        Button btnBack = new Button("Quay lại");
        btnBack.setStyle("-fx-font-size: 14px; -fx-font-family: 'Segoe UI';");
        btnBack.setOnAction(e -> stage.close());

        root.getChildren().addAll(label, comboTour, lblTourDetails, txtTourDetails, tabPane, btnBack);

        Scene scene = new Scene(root, 900, 600);
        stage.setScene(scene);
    }

    /**
     * Tai lai noi dung cac tab theo tour dang chon (sua loi tab bi tao 1 lan o constructor).
     */
    private void taiLaiTabs() {
        tabPane.getTabs().clear();

        Tab tabNoiDungChan = new Tab("Nơi dừng chân");
        tabNoiDungChan.setContent(createNoiDungChanContent());
        tabNoiDungChan.setClosable(false);

        Tab tabPhuongTien = new Tab("Phương tiện");
        tabPhuongTien.setContent(createPhuongTienContent());
        tabPhuongTien.setClosable(false);

        Tab tabDiemThamQuan = new Tab("Điểm tham quan");
        tabDiemThamQuan.setContent(createDiemThamQuanContent());
        tabDiemThamQuan.setClosable(false);

        Tab tabChuyen = new Tab("Chuyến du lịch");
        tabChuyen.setContent(createChuyenContent());
        tabChuyen.setClosable(false);

        tabPane.getTabs().addAll(tabNoiDungChan, tabPhuongTien, tabDiemThamQuan, tabChuyen);
    }

    // ===================== NOI DUNG CHAN =====================

    private VBox createNoiDungChanContent() {
        VBox content = new VBox(10);
        content.setPadding(new Insets(10));

        Label label = new Label("Nơi dừng chân của Tour");
        label.setStyle("-fx-font-weight: bold;");

        TableView<NoiDungChan> tableView = new TableView<>();
        ObservableList<NoiDungChan> list = FXCollections.observableArrayList(selectedTour.getNoiDungChans());
        tableView.setItems(list);

        TableColumn<NoiDungChan, String> colMa = new TableColumn<>("Mã");
        colMa.setCellValueFactory(new PropertyValueFactory<>("maNoiDungChan"));
        colMa.setPrefWidth(80);

        TableColumn<NoiDungChan, String> colTen = new TableColumn<>("Tên nơi");
        colTen.setCellValueFactory(new PropertyValueFactory<>("tenNoi"));
        colTen.setPrefWidth(200);

        TableColumn<NoiDungChan, String> colDiaDiem = new TableColumn<>("Địa điểm");
        colDiaDiem.setCellValueFactory(new PropertyValueFactory<>("diaDiem"));
        colDiaDiem.setPrefWidth(200);

        tableView.getColumns().addAll(colMa, colTen, colDiaDiem);

        HBox buttonBox = new HBox(10);
        Button btnThem = new Button("Thêm từ danh mục");
        Button btnXoa = new Button("Xóa");

        btnThem.setOnAction(e -> {
            NoiDungChan ndc = chonTuDanhMuc("Chọn nơi dừng chân", noiDungChanService.findAll());
            if (ndc == null) {
                return;
            }
            try {
                tourService.themNoiDungChan(selectedTour.getMaTour(), ndc);
                list.setAll(tourService.findById(selectedTour.getMaTour()).getNoiDungChans());
                UiUtil.alert("Thông báo", "Đã thêm nơi dừng chân thành công!");
            } catch (RuntimeException ex) {
                UiUtil.error(ex.getMessage());
            }
        });

        btnXoa.setOnAction(e -> {
            NoiDungChan selected = tableView.getSelectionModel().getSelectedItem();
            if (selected == null) {
                UiUtil.error("Vui lòng chọn nơi dừng chân để xóa!");
                return;
            }
            if (UiUtil.confirm("Bạn có chắc muốn xóa nơi dừng chân này khỏi tour?")) {
                try {
                    tourService.xoaNoiDungChan(selectedTour.getMaTour(), selected.getMaNoiDungChan());
                    list.setAll(tourService.findById(selectedTour.getMaTour()).getNoiDungChans());
                    UiUtil.alert("Thông báo", "Đã xóa nơi dừng chân thành công!");
                } catch (RuntimeException ex) {
                    UiUtil.error(ex.getMessage());
                }
            }
        });

        buttonBox.getChildren().addAll(btnThem, btnXoa);
        content.getChildren().addAll(label, tableView, buttonBox);
        return content;
    }

    // ===================== PHUONG TIEN =====================

    private VBox createPhuongTienContent() {
        VBox content = new VBox(10);
        content.setPadding(new Insets(10));

        Label label = new Label("Phương tiện của Tour");
        label.setStyle("-fx-font-weight: bold;");

        TableView<PhuongTien> tableView = new TableView<>();
        ObservableList<PhuongTien> list = FXCollections.observableArrayList(selectedTour.getPhuongTiens());
        tableView.setItems(list);

        TableColumn<PhuongTien, String> colMa = new TableColumn<>("Mã");
        colMa.setCellValueFactory(new PropertyValueFactory<>("maPhuongTien"));
        colMa.setPrefWidth(80);

        TableColumn<PhuongTien, String> colLoai = new TableColumn<>("Loại");
        colLoai.setCellValueFactory(new PropertyValueFactory<>("loaiPhuongTien"));
        colLoai.setPrefWidth(150);

        TableColumn<PhuongTien, String> colBienSo = new TableColumn<>("Biển số");
        colBienSo.setCellValueFactory(new PropertyValueFactory<>("bienSo"));
        colBienSo.setPrefWidth(120);

        TableColumn<PhuongTien, Integer> colSoCho = new TableColumn<>("Số chỗ");
        colSoCho.setCellValueFactory(new PropertyValueFactory<>("soCho"));
        colSoCho.setPrefWidth(80);

        tableView.getColumns().addAll(colMa, colLoai, colBienSo, colSoCho);

        HBox buttonBox = new HBox(10);
        Button btnThem = new Button("Thêm từ danh mục");
        Button btnXoa = new Button("Xóa");

        btnThem.setOnAction(e -> {
            PhuongTien pt = chonTuDanhMuc("Chọn phương tiện", phuongTienService.findAll());
            if (pt == null) {
                return;
            }
            try {
                tourService.themPhuongTien(selectedTour.getMaTour(), pt);
                list.setAll(tourService.findById(selectedTour.getMaTour()).getPhuongTiens());
                UiUtil.alert("Thông báo", "Đã thêm phương tiện thành công!");
            } catch (RuntimeException ex) {
                UiUtil.error(ex.getMessage());
            }
        });

        btnXoa.setOnAction(e -> {
            PhuongTien selected = tableView.getSelectionModel().getSelectedItem();
            if (selected == null) {
                UiUtil.error("Vui lòng chọn phương tiện để xóa!");
                return;
            }
            if (UiUtil.confirm("Bạn có chắc muốn xóa phương tiện này khỏi tour?")) {
                try {
                    tourService.xoaPhuongTien(selectedTour.getMaTour(), selected.getMaPhuongTien());
                    list.setAll(tourService.findById(selectedTour.getMaTour()).getPhuongTiens());
                    UiUtil.alert("Thông báo", "Đã xóa phương tiện thành công!");
                } catch (RuntimeException ex) {
                    UiUtil.error(ex.getMessage());
                }
            }
        });

        buttonBox.getChildren().addAll(btnThem, btnXoa);
        content.getChildren().addAll(label, tableView, buttonBox);
        return content;
    }

    // ===================== DIEM THAM QUAN =====================

    private VBox createDiemThamQuanContent() {
        VBox content = new VBox(10);
        content.setPadding(new Insets(10));

        Label label = new Label("Điểm tham quan của Tour");
        label.setStyle("-fx-font-weight: bold;");

        TableView<DiemThamQuan> tableView = new TableView<>();
        ObservableList<DiemThamQuan> list = FXCollections.observableArrayList(selectedTour.getDiemThamQuans());
        tableView.setItems(list);

        TableColumn<DiemThamQuan, String> colMa = new TableColumn<>("Mã");
        colMa.setCellValueFactory(new PropertyValueFactory<>("maDiem"));
        colMa.setPrefWidth(80);

        TableColumn<DiemThamQuan, String> colTen = new TableColumn<>("Tên điểm");
        colTen.setCellValueFactory(new PropertyValueFactory<>("tenDiem"));
        colTen.setPrefWidth(200);

        TableColumn<DiemThamQuan, String> colDiaDiem = new TableColumn<>("Địa điểm");
        colDiaDiem.setCellValueFactory(new PropertyValueFactory<>("diaDiem"));
        colDiaDiem.setPrefWidth(200);

        tableView.getColumns().addAll(colMa, colTen, colDiaDiem);

        HBox buttonBox = new HBox(10);
        Button btnThem = new Button("Thêm từ danh mục");
        Button btnXoa = new Button("Xóa");

        btnThem.setOnAction(e -> {
            DiemThamQuan dtq = chonTuDanhMuc("Chọn điểm tham quan", diemThamQuanService.findAll());
            if (dtq == null) {
                return;
            }
            try {
                tourService.themDiemThamQuan(selectedTour.getMaTour(), dtq);
                list.setAll(tourService.findById(selectedTour.getMaTour()).getDiemThamQuans());
                UiUtil.alert("Thông báo", "Đã thêm điểm tham quan thành công!");
            } catch (RuntimeException ex) {
                UiUtil.error(ex.getMessage());
            }
        });

        btnXoa.setOnAction(e -> {
            DiemThamQuan selected = tableView.getSelectionModel().getSelectedItem();
            if (selected == null) {
                UiUtil.error("Vui lòng chọn điểm tham quan để xóa!");
                return;
            }
            if (UiUtil.confirm("Bạn có chắc muốn xóa điểm tham quan này khỏi tour?")) {
                try {
                    tourService.xoaDiemThamQuan(selectedTour.getMaTour(), selected.getMaDiem());
                    list.setAll(tourService.findById(selectedTour.getMaTour()).getDiemThamQuans());
                    UiUtil.alert("Thông báo", "Đã xóa điểm tham quan thành công!");
                } catch (RuntimeException ex) {
                    UiUtil.error(ex.getMessage());
                }
            }
        });

        buttonBox.getChildren().addAll(btnThem, btnXoa);
        content.getChildren().addAll(label, tableView, buttonBox);
        return content;
    }

    // ===================== CHUYEN DU LICH =====================

    private VBox createChuyenContent() {
        VBox content = new VBox(10);
        content.setPadding(new Insets(10));

        Label label = new Label("Chuyến du lịch của Tour (lịch theo công ty)");
        label.setStyle("-fx-font-weight: bold;");

        TableView<ChuyenDuLich> tableView = new TableView<>();
        ObservableList<ChuyenDuLich> list = FXCollections.observableArrayList(
                chuyenDuLichService.findByTour(selectedTour.getMaTour()));
        tableView.setItems(list);

        TableColumn<ChuyenDuLich, String> colMa = new TableColumn<>("Mã chuyến");
        colMa.setCellValueFactory(new PropertyValueFactory<>("maChuyen"));
        colMa.setPrefWidth(100);

        TableColumn<ChuyenDuLich, LocalDate> colNgayDi = new TableColumn<>("Ngày đi");
        colNgayDi.setCellValueFactory(new PropertyValueFactory<>("ngayDi"));
        colNgayDi.setPrefWidth(120);

        TableColumn<ChuyenDuLich, LocalDate> colNgayVe = new TableColumn<>("Ngày về");
        colNgayVe.setCellValueFactory(new PropertyValueFactory<>("ngayVe"));
        colNgayVe.setPrefWidth(120);

        TableColumn<ChuyenDuLich, Integer> colMax = new TableColumn<>("Số người max");
        colMax.setCellValueFactory(new PropertyValueFactory<>("soNguoiMax"));
        colMax.setPrefWidth(100);

        TableColumn<ChuyenDuLich, Integer> colDaDk = new TableColumn<>("Đã đăng ký");
        colDaDk.setCellValueFactory(new PropertyValueFactory<>("soNguoiDaDangKy"));
        colDaDk.setPrefWidth(100);

        TableColumn<ChuyenDuLich, String> colTrangThai = new TableColumn<>("Trạng thái");
        colTrangThai.setCellValueFactory(new PropertyValueFactory<>("trangThai"));
        colTrangThai.setPrefWidth(120);

        tableView.getColumns().addAll(colMa, colNgayDi, colNgayVe, colMax, colDaDk, colTrangThai);

        HBox buttonBox = new HBox(10);
        Button btnThem = new Button("Thêm chuyến");
        Button btnSua = new Button("Sửa");
        Button btnXoa = new Button("Xóa");

        btnThem.setOnAction(e -> {
            try {
                String maMoi = chuyenDuLichService.nextId();
                Optional<Map<String, String>> ketQua = FormDialogUtil.showForm("Thêm Chuyến du lịch",
                        new String[]{"Mã chuyến", "Ngày đi (yyyy-mm-dd)", "Ngày về (yyyy-mm-dd)", "Số người tối đa"},
                        new String[]{maMoi, LocalDate.now().toString(), LocalDate.now().plusDays(3).toString(), "30"});
                if (ketQua.isPresent()) {
                    Map<String, String> v = ketQua.get();
                    ChuyenDuLich c = new ChuyenDuLich();
                    c.setMaChuyen(v.get("Mã chuyến"));
                    c.setMaTour(selectedTour.getMaTour());
                    c.setNgayDi(LocalDate.parse(v.get("Ngày đi (yyyy-mm-dd)")));
                    c.setNgayVe(LocalDate.parse(v.get("Ngày về (yyyy-mm-dd)")));
                    c.setSoNguoiMax(Integer.parseInt(v.get("Số người tối đa")));
                    chuyenDuLichService.themChuyen(c);
                    list.setAll(chuyenDuLichService.findByTour(selectedTour.getMaTour()));
                    UiUtil.alert("Thông báo", "Đã thêm chuyến thành công!");
                }
            } catch (Exception ex) {
                UiUtil.error("Dữ liệu không hợp lệ: " + ex.getMessage());
            }
        });

        btnSua.setOnAction(e -> {
            ChuyenDuLich selected = tableView.getSelectionModel().getSelectedItem();
            if (selected == null) {
                UiUtil.error("Vui lòng chọn chuyến để sửa!");
                return;
            }
            try {
                Optional<Map<String, String>> ketQua = FormDialogUtil.showForm("Sửa Chuyến du lịch",
                        new String[]{"Mã chuyến", "Ngày đi (yyyy-mm-dd)", "Ngày về (yyyy-mm-dd)", "Số người tối đa"},
                        new String[]{selected.getMaChuyen(), selected.getNgayDi().toString(),
                                selected.getNgayVe().toString(), String.valueOf(selected.getSoNguoiMax())});
                if (ketQua.isPresent()) {
                    Map<String, String> v = ketQua.get();
                    selected.setNgayDi(LocalDate.parse(v.get("Ngày đi (yyyy-mm-dd)")));
                    selected.setNgayVe(LocalDate.parse(v.get("Ngày về (yyyy-mm-dd)")));
                    selected.setSoNguoiMax(Integer.parseInt(v.get("Số người tối đa")));
                    chuyenDuLichService.suaChuyen(selected);
                    list.setAll(chuyenDuLichService.findByTour(selectedTour.getMaTour()));
                    UiUtil.alert("Thông báo", "Đã sửa chuyến thành công!");
                }
            } catch (Exception ex) {
                UiUtil.error("Dữ liệu không hợp lệ: " + ex.getMessage());
            }
        });

        btnXoa.setOnAction(e -> {
            ChuyenDuLich selected = tableView.getSelectionModel().getSelectedItem();
            if (selected == null) {
                UiUtil.error("Vui lòng chọn chuyến để xóa!");
                return;
            }
            if (UiUtil.confirm("Bạn có chắc muốn xóa chuyến này?")) {
                try {
                    chuyenDuLichService.xoaChuyen(selected.getMaChuyen());
                    list.setAll(chuyenDuLichService.findByTour(selectedTour.getMaTour()));
                    UiUtil.alert("Thông báo", "Đã xóa chuyến thành công!");
                } catch (RuntimeException ex) {
                    UiUtil.error(ex.getMessage());
                }
            }
        });

        buttonBox.getChildren().addAll(btnThem, btnSua, btnXoa);
        content.getChildren().addAll(label, tableView, buttonBox);
        return content;
    }

    /**
     * Hien thi dialog chon 1 phan tu tu danh sach (ChoiceDialog).
     */
    private <T> T chonTuDanhMuc(String tieuDe, java.util.List<T> danhSach) {
        ChoiceDialog<T> dialog = new ChoiceDialog<>(null, danhSach);
        dialog.setTitle(tieuDe);
        dialog.setHeaderText("Chọn từ danh mục");
        dialog.setContentText("Chọn:");
        return dialog.showAndWait().orElse(null);
    }

    public void show() {
        stage.show();
    }
}
