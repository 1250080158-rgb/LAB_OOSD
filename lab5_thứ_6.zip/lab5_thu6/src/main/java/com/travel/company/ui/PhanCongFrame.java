package com.travel.company.ui;

import com.travel.company.model.NhanVien;
import com.travel.company.model.PhanCongNhanVien;
import com.travel.company.service.NhanVienService;
import com.travel.company.service.PhanCongNhanVienService;
import com.travel.company.util.UiUtil;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.time.LocalDate;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Optional;

public class PhanCongFrame {
    private Stage stage;

    private final PhanCongNhanVienService phanCongService = new PhanCongNhanVienService();
    private final NhanVienService nhanVienService = new NhanVienService();
    private ObservableList<PhanCongNhanVien> phanCongList;

    public PhanCongFrame() {
        stage = new Stage();
        stage.setTitle("Phân công nhân viên");

        VBox root = new VBox(10);
        root.setPadding(new Insets(10));

        Label label = new Label("Phân công nhân viên hướng dẫn");
        label.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;");

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(10));

        TextField txtMaPhanCong = new TextField();
        txtMaPhanCong.setPromptText("Tự động nếu để trống");
        grid.add(new Label("Mã phân công:"), 0, 0);
        grid.add(txtMaPhanCong, 1, 0);

        ComboBox<NhanVien> comboNhanVien = new ComboBox<>();
        ObservableList<NhanVien> nhanVienList = FXCollections.observableArrayList(nhanVienService.findAll());
        comboNhanVien.setItems(nhanVienList);
        comboNhanVien.setPromptText("Chọn nhân viên");
        grid.add(new Label("Nhân viên:"), 0, 1);
        grid.add(comboNhanVien, 1, 1);

        ComboBox<String> comboLoaiPhanCong = new ComboBox<>();
        comboLoaiPhanCong.getItems().addAll("Doan", "Chuyen");
        comboLoaiPhanCong.setPromptText("Loại phân công");
        grid.add(new Label("Loại phân công:"), 0, 2);
        grid.add(comboLoaiPhanCong, 1, 2);

        ComboBox<String> comboDoanHoacChuyen = new ComboBox<>();
        comboDoanHoacChuyen.setPromptText("Chọn đoàn/chuyến");
        grid.add(new Label("Đoàn/Chuyến:"), 0, 3);
        grid.add(comboDoanHoacChuyen, 1, 3);

        // Cap nhat danh sach doan/chuyen theo loai phan cong
        comboLoaiPhanCong.setOnAction(e -> {
            String loai = comboLoaiPhanCong.getValue();
            comboDoanHoacChuyen.getItems().clear();
            if ("Doan".equals(loai)) {
                comboDoanHoacChuyen.getItems().addAll(phanCongService.getDangKyDoanIds());
            } else if ("Chuyen".equals(loai)) {
                comboDoanHoacChuyen.getItems().addAll(phanCongService.getChuyenDuLichIds());
            }
        });

        DatePicker datePickerBatDau = new DatePicker();
        datePickerBatDau.setPromptText("Ngày bắt đầu");
        grid.add(new Label("Ngày bắt đầu:"), 0, 4);
        grid.add(datePickerBatDau, 1, 4);

        DatePicker datePickerKetThuc = new DatePicker();
        datePickerKetThuc.setPromptText("Ngày kết thúc");
        grid.add(new Label("Ngày kết thúc:"), 0, 5);
        grid.add(datePickerKetThuc, 1, 5);

        TextField txtLuongTour = new TextField();
        txtLuongTour.setPromptText("Lương tour (VNĐ)");
        grid.add(new Label("Lương tour:"), 0, 6);
        grid.add(txtLuongTour, 1, 6);

        HBox buttonBox = new HBox(10);
        Button btnPhanCong = new Button("Phân công");
        Button btnXoaForm = new Button("Xóa form");

        btnPhanCong.setOnAction(e -> {
            try {
                String maPhanCong = txtMaPhanCong.getText().trim();
                if (maPhanCong.isEmpty()) {
                    maPhanCong = phanCongService.nextId();
                }

                NhanVien nhanVien = comboNhanVien.getValue();
                String loaiPhanCong = comboLoaiPhanCong.getValue();
                String maDoanHoacChuyen = comboDoanHoacChuyen.getValue();
                LocalDate ngayBatDau = datePickerBatDau.getValue();
                LocalDate ngayKetThuc = datePickerKetThuc.getValue();
                double luongTour = txtLuongTour.getText().trim().isEmpty()
                        ? 0 : Double.parseDouble(txtLuongTour.getText().trim());

                PhanCongNhanVien pc = new PhanCongNhanVien();
                pc.setMaPhanCong(maPhanCong);
                pc.setMaNhanVien(nhanVien != null ? nhanVien.getMaNhanVien() : null);
                pc.setLoaiPhanCong(loaiPhanCong);
                pc.setMaDoanHoacChuyen(maDoanHoacChuyen);
                pc.setNgayBatDau(ngayBatDau);
                pc.setNgayKetThuc(ngayKetThuc);
                pc.setLuongTour(luongTour);

                phanCongService.phanCong(pc);
                phanCongList.setAll(phanCongService.findAll());
                UiUtil.alert("Thông báo", "Phân công nhân viên thành công!");
                xoaForm(txtMaPhanCong, comboNhanVien, comboLoaiPhanCong, comboDoanHoacChuyen,
                        datePickerBatDau, datePickerKetThuc, txtLuongTour);
            } catch (NumberFormatException ex) {
                UiUtil.error("Lương tour phải là số!");
            } catch (IllegalArgumentException ex) {
                UiUtil.error(ex.getMessage());
            } catch (RuntimeException ex) {
                UiUtil.error(ex.getMessage());
            }
        });

        btnXoaForm.setOnAction(e -> xoaForm(txtMaPhanCong, comboNhanVien, comboLoaiPhanCong,
                comboDoanHoacChuyen, datePickerBatDau, datePickerKetThuc, txtLuongTour));

        buttonBox.getChildren().addAll(btnPhanCong, btnXoaForm);

        Label lblList = new Label("Danh sách phân công:");
        lblList.setStyle("-fx-font-weight: bold;");

        TableView<PhanCongNhanVien> tableView = new TableView<>();
        phanCongList = FXCollections.observableArrayList(phanCongService.findAll());
        tableView.setItems(phanCongList);

        TableColumn<PhanCongNhanVien, String> colMa = new TableColumn<>("Mã phân công");
        colMa.setCellValueFactory(new PropertyValueFactory<>("maPhanCong"));
        colMa.setPrefWidth(120);

        TableColumn<PhanCongNhanVien, String> colNhanVien = new TableColumn<>("Nhân viên");
        colNhanVien.setCellValueFactory(new PropertyValueFactory<>("maNhanVien"));
        colNhanVien.setPrefWidth(100);

        TableColumn<PhanCongNhanVien, String> colLoai = new TableColumn<>("Loại");
        colLoai.setCellValueFactory(new PropertyValueFactory<>("loaiPhanCong"));
        colLoai.setPrefWidth(80);

        TableColumn<PhanCongNhanVien, String> colDoanChuyen = new TableColumn<>("Đoàn/Chuyến");
        colDoanChuyen.setCellValueFactory(new PropertyValueFactory<>("maDoanHoacChuyen"));
        colDoanChuyen.setPrefWidth(120);

        TableColumn<PhanCongNhanVien, LocalDate> colNgayBatDau = new TableColumn<>("Ngày bắt đầu");
        colNgayBatDau.setCellValueFactory(new PropertyValueFactory<>("ngayBatDau"));
        colNgayBatDau.setPrefWidth(120);

        TableColumn<PhanCongNhanVien, LocalDate> colNgayKetThuc = new TableColumn<>("Ngày kết thúc");
        colNgayKetThuc.setCellValueFactory(new PropertyValueFactory<>("ngayKetThuc"));
        colNgayKetThuc.setPrefWidth(120);

        TableColumn<PhanCongNhanVien, Double> colLuong = new TableColumn<>("Lương tour");
        colLuong.setCellValueFactory(new PropertyValueFactory<>("luongTour"));
        colLuong.setPrefWidth(100);

        tableView.getColumns().addAll(colMa, colNhanVien, colLoai, colDoanChuyen,
                colNgayBatDau, colNgayKetThuc, colLuong);

        HBox listButtonBox = new HBox(10);
        Button btnXoa = new Button("Xóa");
        Button btnTinhLuong = new Button("Tính lương tháng");

        btnXoa.setOnAction(e -> xoaPhanCong(tableView));
        btnTinhLuong.setOnAction(e -> tinhLuongThang(comboNhanVien));

        listButtonBox.getChildren().addAll(btnXoa, btnTinhLuong);

        Button btnBack = new Button("Quay lại");
        btnBack.setStyle("-fx-font-size: 14px; -fx-font-family: 'Segoe UI';");
        btnBack.setOnAction(e -> stage.close());

        root.getChildren().addAll(label, grid, buttonBox, lblList, tableView, listButtonBox, btnBack);

        Scene scene = new Scene(root, 900, 700);
        stage.setScene(scene);
    }

    private void xoaForm(TextField txtMaPhanCong, ComboBox<NhanVien> comboNhanVien,
                         ComboBox<String> comboLoaiPhanCong, ComboBox<String> comboDoanHoacChuyen,
                         DatePicker datePickerBatDau, DatePicker datePickerKetThuc, TextField txtLuongTour) {
        txtMaPhanCong.clear();
        comboNhanVien.setValue(null);
        comboLoaiPhanCong.setValue(null);
        comboDoanHoacChuyen.getItems().clear();
        comboDoanHoacChuyen.setValue(null);
        datePickerBatDau.setValue(null);
        datePickerKetThuc.setValue(null);
        txtLuongTour.clear();
    }

    private void xoaPhanCong(TableView<PhanCongNhanVien> tableView) {
        PhanCongNhanVien selected = tableView.getSelectionModel().getSelectedItem();
        if (selected == null) {
            UiUtil.error("Vui lòng chọn phân công để xóa!");
            return;
        }
        if (UiUtil.confirm("Bạn có chắc muốn xóa phân công này?")) {
            try {
                phanCongService.xoaPhanCong(selected.getMaPhanCong());
                phanCongList.setAll(phanCongService.findAll());
                UiUtil.alert("Thông báo", "Đã xóa phân công thành công!");
            } catch (RuntimeException ex) {
                UiUtil.error(ex.getMessage());
            }
        }
    }

    /**
     * Tinh luong thang: luong can ban + luong tour cac phan cong trong thang.
     */
    private void tinhLuongThang(ComboBox<NhanVien> comboNhanVien) {
        NhanVien nhanVien = comboNhanVien.getValue();
        if (nhanVien == null) {
            UiUtil.error("Vui lòng chọn nhân viên để tính lương!");
            return;
        }

        TextInputDialog dialog = new TextInputDialog(YearMonth.now().format(DateTimeFormatter.ofPattern("yyyy-MM")));
        dialog.setTitle("Tính lương tháng");
        dialog.setHeaderText("Nhập tháng cần tính lương");
        dialog.setContentText("Tháng (yyyy-MM, để trống = tất cả):");
        Optional<String> ketQua = dialog.showAndWait();
        if (!ketQua.isPresent()) {
            return;
        }

        YearMonth thang = null;
        String nhap = ketQua.get().trim();
        if (!nhap.isEmpty()) {
            try {
                thang = YearMonth.parse(nhap, DateTimeFormatter.ofPattern("yyyy-MM"));
            } catch (DateTimeParseException ex) {
                UiUtil.error("Định dạng tháng không đúng! Ví dụ: 2026-11");
                return;
            }
        }

        double luongTour = phanCongService.tinhLuongTourThang(nhanVien.getMaNhanVien(), thang);
        double tongLuong = nhanVien.getLuongCanBan() + luongTour;
        String message = String.format("Nhân viên: %s\nTháng: %s\nLương căn bản: %s VNĐ\nLương theo tour: %s VNĐ\nTổng lương: %s VNĐ",
                nhanVien.getHoTen(),
                thang != null ? thang.toString() : "Tất cả",
                String.format("%,.0f", nhanVien.getLuongCanBan()),
                String.format("%,.0f", luongTour),
                String.format("%,.0f", tongLuong));
        UiUtil.alert("Lương tháng", message);
    }

    public void show() {
        stage.show();
    }
}
