package com.travel.company.data;

import com.travel.company.model.PhanCongNhanVien;

import java.sql.Date;
import java.sql.SQLException;
import java.util.List;

public class PhanCongNhanVienDao {

    private static final RowMapper<PhanCongNhanVien> MAPPER = rs -> {
        PhanCongNhanVien pc = new PhanCongNhanVien();
        pc.setMaPhanCong(rs.getString("MaPhanCong"));
        pc.setMaNhanVien(rs.getString("MaNhanVien"));
        pc.setLoaiPhanCong(rs.getString("LoaiPhanCong"));
        pc.setMaDoanHoacChuyen(rs.getString("MaDoanHoacChuyen"));
        java.sql.Date bd = rs.getDate("NgayBatDau");
        java.sql.Date kt = rs.getDate("NgayKetThuc");
        if (bd != null) {
            pc.setNgayBatDau(bd.toLocalDate());
        }
        if (kt != null) {
            pc.setNgayKetThuc(kt.toLocalDate());
        }
        pc.setLuongTour(rs.getDouble("LuongTour"));
        return pc;
    };

    public List<PhanCongNhanVien> findAll() throws SQLException {
        return JdbcUtil.query("SELECT * FROM PHAN_CONG_NHAN_VIEN ORDER BY MaPhanCong", MAPPER);
    }

    public List<PhanCongNhanVien> findByNhanVien(String maNhanVien) throws SQLException {
        return JdbcUtil.query("SELECT * FROM PHAN_CONG_NHAN_VIEN WHERE MaNhanVien = ? ORDER BY NgayBatDau", MAPPER, maNhanVien);
    }

    public PhanCongNhanVien findById(String maPhanCong) throws SQLException {
        return JdbcUtil.queryOne("SELECT * FROM PHAN_CONG_NHAN_VIEN WHERE MaPhanCong = ?", MAPPER, maPhanCong);
    }

    public void insert(PhanCongNhanVien pc) throws SQLException {
        JdbcUtil.update("INSERT INTO PHAN_CONG_NHAN_VIEN (MaPhanCong, MaNhanVien, LoaiPhanCong, MaDoanHoacChuyen, NgayBatDau, NgayKetThuc, LuongTour) VALUES (?, ?, ?, ?, ?, ?, ?)",
                pc.getMaPhanCong(), pc.getMaNhanVien(), pc.getLoaiPhanCong(), pc.getMaDoanHoacChuyen(),
                Date.valueOf(pc.getNgayBatDau()), Date.valueOf(pc.getNgayKetThuc()), pc.getLuongTour());
    }

    public void update(PhanCongNhanVien pc) throws SQLException {
        JdbcUtil.update("UPDATE PHAN_CONG_NHAN_VIEN SET MaNhanVien = ?, LoaiPhanCong = ?, MaDoanHoacChuyen = ?, NgayBatDau = ?, NgayKetThuc = ?, LuongTour = ? WHERE MaPhanCong = ?",
                pc.getMaNhanVien(), pc.getLoaiPhanCong(), pc.getMaDoanHoacChuyen(),
                Date.valueOf(pc.getNgayBatDau()), Date.valueOf(pc.getNgayKetThuc()), pc.getLuongTour(), pc.getMaPhanCong());
    }

    public void delete(String maPhanCong) throws SQLException {
        JdbcUtil.update("DELETE FROM PHAN_CONG_NHAN_VIEN WHERE MaPhanCong = ?", maPhanCong);
    }

    public String nextId() throws SQLException {
        return JdbcUtil.nextId("PHAN_CONG_NHAN_VIEN", "MaPhanCong", "PC", 3);
    }
}
