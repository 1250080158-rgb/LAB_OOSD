package com.travel.company.ui;

import com.travel.company.model.ChuyenDuLich;
import com.travel.company.model.DangKyDoan;
import com.travel.company.model.KhaoSat;
import com.travel.company.service.ChuyenDuLichService;
import com.travel.company.service.DangKyDoanService;
import com.travel.company.service.KhaoSatService;
import com.travel.company.util.UiUtil;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.time.LocalDate;

public class KhaoSatFrame {
    private Stage stage;

    private final KhaoSatService khaoSatService = new KhaoSatService();
    private final DangKyDoanService dangKyDoanService = new DangKyDoanService();
    private final ChuyenDuLichService chuyenDuLichService = new ChuyenDuLichService();
    private ObservableList<KhaoSat> khaoSatList;

    public KhaoSatFrame() {
        stage = new Stage();
        stage.setTitle("Khảo sát khách hàng");

        VBox root = new VBox(10);
        root.setPadding(new Insets(10));

        Label label = new Label("Khảo sát khách hàng");
        label.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;");

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(10));

        TextField txtMaKhaoSat = new TextField();
        txtMaKhaoSat.setPromptText("Tự động nếu để trống");
        grid.add(new Label("Mã khảo sát:"), 0, 0);
        grid.add(txtMaKhaoSat, 1, 0);

        ComboBox<String> comboLoaiKhaoSat = new ComboBox<>();
        comboLoaiKhaoSat.getItems().addAll("Doan", "Chuyen");
        comboLoaiKhaoSat.setPromptText("Loại khảo sát");
        grid.add(new Label("Loại khảo sát:"), 0, 1);
        grid.add(comboLoaiKhaoSat, 1, 1);

        ComboBox<String> comboDoanHoacChuyen = new ComboBox<>();
        comboDoanHoacChuyen.setPromptText("Chọn đoàn/chuyến đã hoàn thành");
        grid.add(new Label("Đoàn/Chuyến:"), 0, 2);
        grid.add(comboDoanHoacChuyen, 1, 2);

        // Chi hien thi doan/chuyen da ket thuc (gui phiếu khảo sát sau khi ket thuc tour)
        comboLoaiKhaoSat.setOnAction(e -> {
            String loai = comboLoaiKhaoSat.getValue();
            comboDoanHoacChuyen.getItems().clear();
            if ("Doan".equals(loai)) {
                dangKyDoanService.findAll().stream()
                        .filter(d -> "Đã kết thúc".equals(d.getTrangThai()))
                        .forEach(d -> comboDoanHoacChuyen.getItems().add(d.getMaPhieuDoan()));
            } else if ("Chuyen".equals(loai)) {
                chuyenDuLichService.findAll().stream()
                        .filter(c -> "Đã kết thúc".equals(c.getTrangThai()))
                        .forEach(c -> comboDoanHoacChuyen.getItems().add(c.getMaChuyen()));
            }
        });

        DatePicker datePicker = new DatePicker();
        datePicker.setPromptText("Ngày khảo sát");
        datePicker.setValue(LocalDate.now());
        grid.add(new Label("Ngày khảo sát:"), 0, 3);
        grid.add(datePicker, 1, 3);

        TextArea txtPhanHoi = new TextArea();
        txtPhanHoi.setPromptText("Phản hồi của khách hàng");
        txtPhanHoi.setPrefRowCount(4);
        grid.add(new Label("Phản hồi:"), 0, 4);
        grid.add(txtPhanHoi, 1, 4);

        ComboBox<Integer> comboDanhGia = new ComboBox<>();
        comboDanhGia.getItems().addAll(1, 2, 3, 4, 5);
        comboDanhGia.setPromptText("Đánh giá (1-5 sao)");
        grid.add(new Label("Đánh giá:"), 0, 5);
        grid.add(comboDanhGia, 1, 5);

        HBox buttonBox = new HBox(10);
        Button btnLuu = new Button("Lưu khảo sát");
        Button btnXoaForm = new Button("Xóa form");

        btnLuu.setOnAction(e -> {
            try {
                String maKhaoSat = txtMaKhaoSat.getText().trim();
                if (maKhaoSat.isEmpty()) {
                    maKhaoSat = khaoSatService.nextId();
                }

                String loaiKhaoSat = comboLoaiKhaoSat.getValue();
                String maDoanHoacChuyen = comboDoanHoacChuyen.getValue();
                LocalDate ngayKhaoSat = datePicker.getValue();
                String phanHoi = txtPhanHoi.getText().trim();
                Integer danhGia = comboDanhGia.getValue();

                KhaoSat ks = new KhaoSat();
                ks.setMaKhaoSat(maKhaoSat);
                ks.setMaDoanHoacChuyen(maDoanHoacChuyen);
                ks.setLoaiKhaoSat(loaiKhaoSat);
                ks.setNgayKhaoSat(ngayKhaoSat);
                ks.setPhanHoi(phanHoi);
                ks.setDanhGia(danhGia != null ? danhGia : 0);

                khaoSatService.luuKhaoSat(ks);
                khaoSatList.setAll(khaoSatService.findAll());
                UiUtil.alert("Thông báo", "Đã lưu khảo sát thành công!");
                xoaForm(txtMaKhaoSat, comboLoaiKhaoSat, comboDoanHoacChuyen, datePicker, txtPhanHoi, comboDanhGia);
            } catch (IllegalArgumentException ex) {
                UiUtil.error(ex.getMessage());
            } catch (RuntimeException ex) {
                UiUtil.error(ex.getMessage());
            }
        });

        btnXoaForm.setOnAction(e -> xoaForm(txtMaKhaoSat, comboLoaiKhaoSat, comboDoanHoacChuyen,
                datePicker, txtPhanHoi, comboDanhGia));

        buttonBox.getChildren().addAll(btnLuu, btnXoaForm);

        Label lblList = new Label("Danh sách khảo sát:");
        lblList.setStyle("-fx-font-weight: bold;");

        TableView<KhaoSat> tableView = new TableView<>();
        khaoSatList = FXCollections.observableArrayList(khaoSatService.findAll());
        tableView.setItems(khaoSatList);

        TableColumn<KhaoSat, String> colMa = new TableColumn<>("Mã khảo sát");
        colMa.setCellValueFactory(new PropertyValueFactory<>("maKhaoSat"));
        colMa.setPrefWidth(120);

        TableColumn<KhaoSat, String> colDoanChuyen = new TableColumn<>("Đoàn/Chuyến");
        colDoanChuyen.setCellValueFactory(new PropertyValueFactory<>("maDoanHoacChuyen"));
        colDoanChuyen.setPrefWidth(120);

        TableColumn<KhaoSat, String> colLoai = new TableColumn<>("Loại");
        colLoai.setCellValueFactory(new PropertyValueFactory<>("loaiKhaoSat"));
        colLoai.setPrefWidth(80);

        TableColumn<KhaoSat, LocalDate> colNgay = new TableColumn<>("Ngày khảo sát");
        colNgay.setCellValueFactory(new PropertyValueFactory<>("ngayKhaoSat"));
        colNgay.setPrefWidth(120);

        TableColumn<KhaoSat, Integer> colDanhGia = new TableColumn<>("Đánh giá");
        colDanhGia.setCellValueFactory(new PropertyValueFactory<>("danhGia"));
        colDanhGia.setPrefWidth(80);

        TableColumn<KhaoSat, String> colPhanHoi = new TableColumn<>("Phản hồi");
        colPhanHoi.setCellValueFactory(new PropertyValueFactory<>("phanHoi"));
        colPhanHoi.setPrefWidth(300);

        tableView.getColumns().addAll(colMa, colDoanChuyen, colLoai, colNgay, colDanhGia, colPhanHoi);

        HBox listButtonBox = new HBox(10);
        Button btnXoa = new Button("Xóa");
        Button btnXemChiTiet = new Button("Xem chi tiết");

        btnXoa.setOnAction(e -> xoaKhaoSat(tableView));
        btnXemChiTiet.setOnAction(e -> xemChiTiet(tableView));

        listButtonBox.getChildren().addAll(btnXoa, btnXemChiTiet);

        Button btnBack = new Button("Quay lại");
        btnBack.setStyle("-fx-font-size: 14px; -fx-font-family: 'Segoe UI';");
        btnBack.setOnAction(e -> stage.close());

        root.getChildren().addAll(label, grid, buttonBox, lblList, tableView, listButtonBox, btnBack);

        Scene scene = new Scene(root, 900, 700);
        stage.setScene(scene);
    }

    private void xoaForm(TextField txtMaKhaoSat, ComboBox<String> comboLoaiKhaoSat,
                         ComboBox<String> comboDoanHoacChuyen, DatePicker datePicker,
                         TextArea txtPhanHoi, ComboBox<Integer> comboDanhGia) {
        txtMaKhaoSat.clear();
        comboLoaiKhaoSat.setValue(null);
        comboDoanHoacChuyen.getItems().clear();
        comboDoanHoacChuyen.setValue(null);
        datePicker.setValue(LocalDate.now());
        txtPhanHoi.clear();
        comboDanhGia.setValue(null);
    }

    private void xoaKhaoSat(TableView<KhaoSat> tableView) {
        KhaoSat selected = tableView.getSelectionModel().getSelectedItem();
        if (selected == null) {
            UiUtil.error("Vui lòng chọn khảo sát để xóa!");
            return;
        }
        if (UiUtil.confirm("Bạn có chắc muốn xóa khảo sát này?")) {
            try {
                khaoSatService.xoaKhaoSat(selected.getMaKhaoSat());
                khaoSatList.setAll(khaoSatService.findAll());
                UiUtil.alert("Thông báo", "Đã xóa khảo sát thành công!");
            } catch (RuntimeException ex) {
                UiUtil.error(ex.getMessage());
            }
        }
    }

    private void xemChiTiet(TableView<KhaoSat> tableView) {
        KhaoSat selected = tableView.getSelectionModel().getSelectedItem();
        if (selected == null) {
            UiUtil.error("Vui lòng chọn khảo sát để xem chi tiết!");
            return;
        }

        String message = String.format("Mã khảo sát: %s\nLoại: %s\nĐoàn/Chuyến: %s\nNgày khảo sát: %s\nĐánh giá: %d sao\n\nPhản hồi:\n%s",
                selected.getMaKhaoSat(), selected.getLoaiKhaoSat(), selected.getMaDoanHoacChuyen(),
                selected.getNgayKhaoSat(), selected.getDanhGia(), selected.getPhanHoi());
        UiUtil.alert("Chi tiết khảo sát", message);
    }

    public void show() {
        stage.show();
    }
}
