package com.travel.company.model;

import java.io.Serializable;

public class DiemThamQuan implements Serializable {
    private String maDiem;
    private String tenDiem;
    private String diaDiem;
    private String noiDung;
    private String yNghia;

    public DiemThamQuan() {
    }

    public DiemThamQuan(String maDiem, String tenDiem, String diaDiem, String noiDung, String yNghia) {
        this.maDiem = maDiem;
        this.tenDiem = tenDiem;
        this.diaDiem = diaDiem;
        this.noiDung = noiDung;
        this.yNghia = yNghia;
    }

    // Getters and Setters
    public String getMaDiem() {
        return maDiem;
    }

    public void setMaDiem(String maDiem) {
        this.maDiem = maDiem;
    }

    public String getTenDiem() {
        return tenDiem;
    }

    public void setTenDiem(String tenDiem) {
        this.tenDiem = tenDiem;
    }

    public String getDiaDiem() {
        return diaDiem;
    }

    public void setDiaDiem(String diaDiem) {
        this.diaDiem = diaDiem;
    }

    public String getNoiDung() {
        return noiDung;
    }

    public void setNoiDung(String noiDung) {
        this.noiDung = noiDung;
    }

    public String getYNghia() {
        return yNghia;
    }

    public void setYNghia(String yNghia) {
        this.yNghia = yNghia;
    }

    @Override
    public String toString() {
        return maDiem + " - " + tenDiem;
    }
}
