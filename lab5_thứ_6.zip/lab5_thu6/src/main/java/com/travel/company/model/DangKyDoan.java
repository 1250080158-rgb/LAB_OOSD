package com.travel.company.model;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class DangKyDoan implements Serializable {
    private String maPhieuDoan;
    private String tenCoQuan;
    private String diaChiCoQuan;
    private String dienThoaiCoQuan;
    private String nguoiDaiDien;
    private int soNguoiDi;
    private boolean muaBaoHiem;
    private List<String> danhSachNguoiDi; // Nếu mua bảo hiểm
    private String diaDiemDon;
    private double tienCoc;
    private String maTour;
    private LocalDate ngayDi;
    private String trangThai; // "Chưa đi", "Đang đi", "Đã kết thúc", "Đã hủy"

    public DangKyDoan() {
        this.danhSachNguoiDi = new ArrayList<>();
        this.trangThai = "Chưa đi";
    }

    public DangKyDoan(String maPhieuDoan, String tenCoQuan, String diaChiCoQuan, String dienThoaiCoQuan,
                      String nguoiDaiDien, int soNguoiDi, boolean muaBaoHiem, String diaDiemDon,
                      double tienCoc, String maTour, LocalDate ngayDi) {
        this();
        this.maPhieuDoan = maPhieuDoan;
        this.tenCoQuan = tenCoQuan;
        this.diaChiCoQuan = diaChiCoQuan;
        this.dienThoaiCoQuan = dienThoaiCoQuan;
        this.nguoiDaiDien = nguoiDaiDien;
        this.soNguoiDi = soNguoiDi;
        this.muaBaoHiem = muaBaoHiem;
        this.diaDiemDon = diaDiemDon;
        this.tienCoc = tienCoc;
        this.maTour = maTour;
        this.ngayDi = ngayDi;
    }

    // Getters and Setters
    public String getMaPhieuDoan() {
        return maPhieuDoan;
    }

    public void setMaPhieuDoan(String maPhieuDoan) {
        this.maPhieuDoan = maPhieuDoan;
    }

    public String getTenCoQuan() {
        return tenCoQuan;
    }

    public void setTenCoQuan(String tenCoQuan) {
        this.tenCoQuan = tenCoQuan;
    }

    public String getDiaChiCoQuan() {
        return diaChiCoQuan;
    }

    public void setDiaChiCoQuan(String diaChiCoQuan) {
        this.diaChiCoQuan = diaChiCoQuan;
    }

    public String getDienThoaiCoQuan() {
        return dienThoaiCoQuan;
    }

    public void setDienThoaiCoQuan(String dienThoaiCoQuan) {
        this.dienThoaiCoQuan = dienThoaiCoQuan;
    }

    public String getNguoiDaiDien() {
        return nguoiDaiDien;
    }

    public void setNguoiDaiDien(String nguoiDaiDien) {
        this.nguoiDaiDien = nguoiDaiDien;
    }

    public int getSoNguoiDi() {
        return soNguoiDi;
    }

    public void setSoNguoiDi(int soNguoiDi) {
        this.soNguoiDi = soNguoiDi;
    }

    public boolean isMuaBaoHiem() {
        return muaBaoHiem;
    }

    public void setMuaBaoHiem(boolean muaBaoHiem) {
        this.muaBaoHiem = muaBaoHiem;
    }

    public List<String> getDanhSachNguoiDi() {
        return danhSachNguoiDi;
    }

    public void setDanhSachNguoiDi(List<String> danhSachNguoiDi) {
        this.danhSachNguoiDi = danhSachNguoiDi;
    }

    public String getDiaDiemDon() {
        return diaDiemDon;
    }

    public void setDiaDiemDon(String diaDiemDon) {
        this.diaDiemDon = diaDiemDon;
    }

    public double getTienCoc() {
        return tienCoc;
    }

    public void setTienCoc(double tienCoc) {
        this.tienCoc = tienCoc;
    }

    public String getMaTour() {
        return maTour;
    }

    public void setMaTour(String maTour) {
        this.maTour = maTour;
    }

    public LocalDate getNgayDi() {
        return ngayDi;
    }

    public void setNgayDi(LocalDate ngayDi) {
        this.ngayDi = ngayDi;
    }

    public String getTrangThai() {
        return trangThai;
    }

    public void setTrangThai(String trangThai) {
        this.trangThai = trangThai;
    }

    @Override
    public String toString() {
        return maPhieuDoan + " - " + tenCoQuan + " (" + soNguoiDi + " người)";
    }
}
