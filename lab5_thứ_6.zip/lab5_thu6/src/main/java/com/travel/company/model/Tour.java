package com.travel.company.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Tour implements Serializable {
    private String maTour;
    private String tenTour;
    private int soNgay;
    private int soDem;
    private double donGia;
    private List<NoiDungChan> noiDungChans;
    private List<PhuongTien> phuongTiens;
    private List<DiemThamQuan> diemThamQuans;

    public Tour() {
        this.noiDungChans = new ArrayList<>();
        this.phuongTiens = new ArrayList<>();
        this.diemThamQuans = new ArrayList<>();
    }

    public Tour(String maTour, String tenTour, int soNgay, int soDem, double donGia) {
        this();
        this.maTour = maTour;
        this.tenTour = tenTour;
        this.soNgay = soNgay;
        this.soDem = soDem;
        this.donGia = donGia;
    }

    // Getters and Setters
    public String getMaTour() {
        return maTour;
    }

    public void setMaTour(String maTour) {
        this.maTour = maTour;
    }

    public String getTenTour() {
        return tenTour;
    }

    public void setTenTour(String tenTour) {
        this.tenTour = tenTour;
    }

    public int getSoNgay() {
        return soNgay;
    }

    public void setSoNgay(int soNgay) {
        this.soNgay = soNgay;
    }

    public int getSoDem() {
        return soDem;
    }

    public void setSoDem(int soDem) {
        this.soDem = soDem;
    }

    public double getDonGia() {
        return donGia;
    }

    public void setDonGia(double donGia) {
        this.donGia = donGia;
    }

    public List<NoiDungChan> getNoiDungChans() {
        return noiDungChans;
    }

    public void setNoiDungChans(List<NoiDungChan> noiDungChans) {
        this.noiDungChans = noiDungChans;
    }

    public List<PhuongTien> getPhuongTiens() {
        return phuongTiens;
    }

    public void setPhuongTiens(List<PhuongTien> phuongTiens) {
        this.phuongTiens = phuongTiens;
    }

    public List<DiemThamQuan> getDiemThamQuans() {
        return diemThamQuans;
    }

    public void setDiemThamQuans(List<DiemThamQuan> diemThamQuans) {
        this.diemThamQuans = diemThamQuans;
    }

    @Override
    public String toString() {
        return maTour + " - " + tenTour + " (" + soNgay + " ngày " + soDem + " đêm)";
    }
}
