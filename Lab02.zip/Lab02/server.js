const express = require('express');
const sql = require('mssql');
const bodyParser = require('body-parser');

const app = express();
app.use(bodyParser.json());

// Cấu hình kết nối SQL Server
const config = {
    user: 'your_username', // Thay bằng tên người dùng SQL Server
    password: 'your_password', // Thay bằng mật khẩu SQL Server
    server: 'localhost', // Thay bằng địa chỉ máy chủ SQL Server
    database: 'LibraryManagement', // Tên cơ sở dữ liệu
    options: {
        trustServerCertificate: true, // Chỉ cần trong môi trường phát triển
    },
};

// Kết nối đến SQL Server
sql.connect(config, (err) => {
    if (err) {
        console.error('Kết nối không thành công:', err);
        return;
    }
    console.log('Kết nối thành công với SQL Server');
});

// Định nghĩa route để lấy dữ liệu từ cơ sở dữ liệu
app.get('/api/books', (req, res) => {
    const request = new sql.Request();
    request.query('SELECT * FROM Books', (err, result) => {
        if (err) {
            console.error('Lỗi khi truy vấn:', err);
            res.status(500).json({ error: 'Lỗi khi truy vấn' });
            return;
        }
        res.json(result.recordset);
    });
});

// Khởi động server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server đang chạy trên cổng ${PORT}`);
});
