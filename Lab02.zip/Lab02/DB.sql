-- Tạo cơ sở dữ liệu và sử dụng cơ sở dữ liệu
CREATE DATABASE LibraryManagement;
GO
USE LibraryManagement;
GO

-- Tạo bảng Độc giả
CREATE TABLE Readers (
    ReaderID NVARCHAR(10) PRIMARY KEY,
    FullName NVARCHAR(100) NOT NULL,
    ReaderType NVARCHAR(1) NOT NULL,
    DateOfBirth DATE NOT NULL,
    Address NVARCHAR(255),
    Email NVARCHAR(100) NOT NULL,
    CardIssueDate DATE NOT NULL
);
GO

-- Tạo bảng Sách
CREATE TABLE Books (
    BookID NVARCHAR(10) PRIMARY KEY,
    Title NVARCHAR(255) NOT NULL,
    Category NVARCHAR(1) NOT NULL,
    Author NVARCHAR(100) NOT NULL,
    PublicationYear INT NOT NULL,
    Publisher NVARCHAR(100),
    PurchaseDate DATE NOT NULL,
    BookValue DECIMAL(10, 2) NOT NULL
);
GO

-- Tạo bảng Phiếu Mượn
CREATE TABLE BorrowingSlips (
    BorrowingSlipID NVARCHAR(10) PRIMARY KEY,
    ReaderID NVARCHAR(10) NOT NULL,
    BorrowDate DATE NOT NULL,
    BookID NVARCHAR(10) NOT NULL,
    FOREIGN KEY (ReaderID) REFERENCES Readers(ReaderID),
    FOREIGN KEY (BookID) REFERENCES Books(BookID)
);
GO

-- Tạo bảng Trả Sách
CREATE TABLE ReturnSlips (
    ReturnSlipID NVARCHAR(10) PRIMARY KEY,
    ReaderID NVARCHAR(10) NOT NULL,
    ReturnDate DATE NOT NULL,
    BookID NVARCHAR(10) NOT NULL,
    LateFee DECIMAL(10, 2) DEFAULT 0,
    FOREIGN KEY (ReaderID) REFERENCES Readers(ReaderID),
    FOREIGN KEY (BookID) REFERENCES Books(BookID)
);
GO

-- Tạo bảng Thu Tiền Phạt
CREATE TABLE FineReceipts (
    FineReceiptID NVARCHAR(10) PRIMARY KEY,
    ReaderID NVARCHAR(10) NOT NULL,
    AmountReceived DECIMAL(10, 2) NOT NULL,
    FOREIGN KEY (ReaderID) REFERENCES Readers(ReaderID)
);
GO
