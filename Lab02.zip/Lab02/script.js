document.addEventListener('DOMContentLoaded', () => {
    fetch('http://localhost:3000/api/books')
        .then(response => response.json())
        .then(books => {
            const bookList = document.getElementById('book-list');
            books.forEach(book => {
                const li = document.createElement('li');
                li.textContent = `${book.Title} - ${book.Author}`;
                bookList.appendChild(li);
            });
        })
        .catch(error => {
            console.error('Lỗi khi tải dữ liệu:', error);
        });
});
